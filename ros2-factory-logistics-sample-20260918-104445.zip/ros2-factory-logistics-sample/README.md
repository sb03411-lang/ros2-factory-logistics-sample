# ROS 2 공장 물류 자동화 샘플

> 창고 로봇은 지름 50cm + 사방 여유 10cm를 적용했습니다. [불규칙 보행자와 통과 폭 설정](docs/PEOPLE_AND_CLEARANCE.md).

> 실시간 주행의 동적 장애물 판단은 전방 카메라와 단일 클래스 YOLO를 사용합니다. 360° 거리 센서는 운영 노드에서 사용하지 않습니다. [카메라 관측 → 대기·우회·재탐색](docs/CAMERA_ONLY.md).

> 3D 창고 샘플과 로봇 1인칭 카메라를 추가했습니다. [사용 방법과 구현 범위](docs/WAREHOUSE_3D.md).

> 실시간 주행은 전체 경로 탐색 + 10Hz 충돌 검사 + 막힘 시 재탐색으로 개선되었습니다. Codex 도면 검토는 비동기로 실행합니다. [변경 내용과 속도 분석](docs/GLOBAL_NAVIGATION.md)을 참고하세요.

가상의 로봇 한 대에 운반 작업을 요청하고, 진행 상황과 완료 결과를 받는 학습용 프로젝트다. 기본 시나리오는 **창고 → 생산라인 A → 창고**다.

**Mac에서 Colima와 Docker를 통해 실제 ROS 2 Jazzy 노드를 실행하고, Action·Topic 통신 검증까지 완료했다.** 컨테이너 환경은 Ubuntu 24.04이며, 로봇의 이동 자체는 2D 좌표 시뮬레이션이다.

- [프로젝트 구상과 공식 참고 자료](docs/PROJECT_PLAN.md)
- [검증 결과와 실행 환경의 한계](docs/VERIFICATION.md)
- [웹 관제 사용법과 API](docs/WEB_UI.md)
- [Codex 도면 해석 → ROS 이동](docs/CODEX_VISION.md)
- [통로 경로·벽 충돌 수정과 검증](docs/NAVIGATION.md)

## 웹에서 모니터링·제어하기

```bash
bash scripts/ros2.sh web
```

브라우저에서 **http://localhost:8765**를 연다. 로봇 위치·목적지·남은 거리와 작업 기록을 확인하고, 창고/생산라인 A/생산라인 B로 운반 요청 또는 현재 작업 취소를 할 수 있다. 실제 ROS 2 Action과 Topic에 연결되며, 화면의 위치는 시뮬레이터가 발행한 좌표다.

**수동 조작 켜기**를 선택하면 방향키 또는 화면 버튼을 누르는 동안 이동한다. 키를 놓거나 Space를 누르면 멈추며 자동 운반 중에는 사용할 수 없다. 하단 **ROS 원본 로그**에서 `/rosout` 원문을 레벨·노드·메시지로 필터링할 수 있다.

**도면을 읽는 Codex**에서 자연어 목표를 입력하고 도면 해석 → 목표까지 이동을 실행할 수 있다. 로그인된 로컬 Codex CLI가 샘플 도면 이미지를 실제로 읽는다. 도면의 등록된 세 목표를 인식하고 A*로 통로 경로를 계산한다. 자동 이동과 수동 조작 모두 벽 충돌을 검사한다. 임의 도면 업로드·센서 기반 동적 장애물 회피·학습형 VLA는 다음 단계다.

기존 `up` 서버가 실행 중이면 작업을 마친 후 `down` → `web` 순서로 전환한다. 웹 실행 중에도 `send`와 `state`를 사용할 수 있다. 종료는 `bash scripts/ros2.sh stop`이다. 소스를 변경했다면 `build` → `down` → `web` 순서로 적용한다.

## 1. Mac에서 실제 ROS 2 실행하기

터미널에서 이 프로젝트 폴더로 이동한 후 실행한다. 현재 Mac에는 필요한 Colima·Docker·Buildx가 설치되어 있다.

VM이 중지되어 있으면 아래 명령이 자동으로 다시 시작한다.

```bash
bash scripts/ros2.sh demo
```

전용 Linux VM을 시작하고, 이미지가 없으면 빌드한다. 로봇 서버와 작업 요청기가 실제 ROS Action으로 통신하며 `JOB-001`은 `line_a`에 도착하고 `JOB-002`는 `warehouse`로 복귀한다. 두 작업 후 컨테이너가 종료된다.

성공·거절·취소·상태 Topic을 자동 검증하려면:

```bash
bash scripts/ros2.sh test
```

검사는 성공 시 종료 코드 `0`, 실패 시 `1`을 반환한다. launch의 종료 코드가 작업 요청기의 오류를 그대로 전달하지 않을 수 있으므로 자동 검증에는 `test`를 사용한다.

## 2. 서버를 켜두고 직접 작업 요청하기

```bash
bash scripts/ros2.sh up
bash scripts/ros2.sh send --job-id JOB-101 --destination line_b --timeout 20
bash scripts/ros2.sh state
```

`up`은 백그라운드 서버를 시작하고 `/factory/transport` Action이 준비될 때까지 기다린다. `send`는 결과를 출력하며, `state`는 전체 상태 메시지 한 개를 출력하고 종료한다. `state`는 10초 안에 메시지를 받지 못하면 실패한다. 작업 옵션 없이 `send`를 실행하면 기본 두 작업을 요청한다.

위 명령으로 `line_b`에 도착한 뒤, 창고로 이동하다 1초 후 취소하는 예시:

```bash
bash scripts/ros2.sh send --job-id JOB-CANCEL --destination warehouse --cancel-after 1 --timeout 20
bash scripts/ros2.sh state
```

같은 서버에서 이미 접수한 ID는 재사용할 수 없다. 예시를 반복할 때는 새 ID를 사용한다. 로봇이 목적지에 이미 도착해 있으면 취소 요청 전에 작업이 완료될 수 있다.

상태 조회와 종료:

```bash
bash scripts/ros2.sh status
bash scripts/ros2.sh down
bash scripts/ros2.sh stop
```

`down`은 이 샘플 소유의 서버 컨테이너만 제거하고 VM은 유지한다. `stop`은 서버를 제거한 뒤 전용 VM도 중지한다. `demo`와 `up`은 필요할 때 VM을 자동으로 다시 시작한다. VM만 먼저 시작하려면 `start`, 전체 도움말은 `help`를 사용한다.

소스나 목적지 설정을 변경하면 이미지를 다시 빌드해야 한다. 실행 중인 서버에도 변경을 적용하려면 재생성한다.

```bash
bash scripts/ros2.sh build
bash scripts/ros2.sh down
bash scripts/ros2.sh up
```

### Mac 런타임 구성

전용 Colima 프로필 이름은 `ros2`이며, Apple Silicon의 VZ 가상화를 사용한다. 설정은 CPU 2개·메모리 4 GiB·데이터 디스크 20 GiB다. 현재 런타임 파일은 `/Users/igyeongseog/Documents/Codex/work/r2`에 저장한다. 셸 시작 파일, 전역 Docker 기본 context, 사용자 SSH 설정은 변경하지 않는다.

helper는 경로의 상위 폴더에서 `Codex`를 찾으면 `Codex/work/r2`, 없으면 프로젝트의 `.runtime`을 사용한다. `ROS2_SAMPLE_RUNTIME` 환경변수로 변경할 수 있다. Lima의 UNIX 소켓 길이 제한 때문에 경로가 길면 실행 전에 오류와 안내를 표시한다.

이 Mac에서는 **`scripts/ros2.sh`를 사용하는 것이 기본 실행 방법**이다. helper가 전용 Docker 소켓과 설정 경로를 선택하므로, 다른 터미널의 일반 `docker` 명령이 자동으로 이 VM을 가리키지는 않는다. 컨테이너에는 호스트 폴더를 마운트하지 않으며 소스는 이미지 빌드 시 복사한다. 외부 포트를 열지 않고 같은 컨테이너 안에서 ROS 노드끼리 통신한다.

다른 Mac에서 도구가 없다면 Homebrew 설치 후 `brew install colima docker docker-buildx`가 필요하다. helper는 도구를 자동 설치하지 않는다. 최초 이미지 빌드에는 인터넷 접속이 필요하다.

## 3. ROS 없이 Python 코어 미리보기

Python 표준 라이브러리만으로 동일한 이동 코어를 실행할 수도 있다. 이 모드는 ROS 노드 간 통신을 사용하지 않는다.

```bash
python3 scripts/local_demo.py
python3 -m unittest discover -s tests -v
```

## 4. 다른 Docker 환경에서 실행하기

Docker가 이미 실행되고 현재 context가 해당 엔진을 가리키는 환경에서는 다음 명령을 사용한다. 이미지는 arm64와 amd64를 대상으로 하며, 이번 실제 검증은 arm64에서 수행했다.

```bash
docker build -t factory-logistics:jazzy .
docker run --rm factory-logistics:jazzy
docker run --rm -it factory-logistics:jazzy ros2 launch factory_logistics demo.launch.py
```

이미지의 기본 명령은 실제 ROS 통합 검사인 `scripts/ros_smoke.py`다. 속도를 변경하려면 launch 명령 끝에 `speed:=2.0`을 추가한다. 호스트 또는 다른 기기와 ROS 통신을 연결하는 구성은 검증하지 않았다.

## 5. Ubuntu 24.04에서 직접 실행하기

[ROS 2 Jazzy 설치 안내](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)에 따라 ROS와 개발 도구를 설치한 환경에서 실행한다. `rosdep`이 초기화되어 있어야 한다.

```bash
source /opt/ros/jazzy/setup.bash
rosdep update
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
ros2 launch factory_logistics demo.launch.py
```

launch는 작업 요청기 종료 시 로봇 노드도 종료한다. 작업 요청기의 오류 종료 코드가 `ros2 launch`의 종료 코드로 그대로 전달되지는 않을 수 있다. 자동 검증에는 아래 명령을 사용한다.

```bash
python3 scripts/ros_smoke.py
```

### Ubuntu에서 노드를 나누어 실행하기

각 터미널에서 이 프로젝트 폴더를 열고 ROS와 프로젝트 설정을 불러온다.

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
```

터미널 A — 로봇 서버:

```bash
ros2 run factory_logistics simulated_robot
```

터미널 B — 기본 두 작업:

```bash
ros2 run factory_logistics task_dispatcher
```

직접 지정한 작업:

```bash
ros2 run factory_logistics task_dispatcher --job-id JOB-003 --destination line_b --timeout 20
```

1초 후 취소를 요청하는 예시:

```bash
ros2 run factory_logistics task_dispatcher --job-id JOB-CANCEL --destination warehouse --cancel-after 1 --timeout 20
```

취소 예시는 로봇이 창고에서 떨어져 있어야 취소 전에 작업이 완료되지 않는다. 먼저 `JOB-003`으로 `line_b`로 이동한 뒤 실행한다. 서버를 계속 켜둔 상태에서 같은 작업 ID를 다시 요청하면 거절되므로 새 ID를 사용한다. `--timeout`은 요청기의 대기 제한이며 시간 단위는 초다.

터미널 C — 상태 확인:

```bash
ros2 topic echo /factory/robot_state
ros2 action info /factory/transport
```

`topic echo`는 계속 실행된다. `Ctrl+C`로 종료한 후 다음 명령을 실행하거나 별도 터미널을 사용한다.

서버의 이동 속도는 m/s 단위 ROS 파라미터다.

```bash
ros2 run factory_logistics simulated_robot --ros-args -p speed:=2.0
```

## 구조와 메시지

```text
src/
  factory_interfaces/             TransportJob Action 정의
  factory_logistics/
    factory_logistics/            이동 코어와 ROS 서버·클라이언트
      stations.json              목적지 이름과 2D 좌표
    launch/demo.launch.py         기본 두 노드 실행
scripts/
  ros2.sh                        Mac용 Colima·Docker 실행 helper
  local_demo.py                   ROS 없는 코어 미리보기
  ros_smoke.py                    실제 ROS Action 통합 검사
  entrypoint.sh                   컨테이너 ROS 환경 설정
tests/                           ROS 없는 코어 테스트
docs/                            구상과 검증 기록
```

| 인터페이스 | 이름 | 내용 |
| --- | --- | --- |
| Action | `/factory/transport` | 작업 요청, 진행 피드백, 결과, 취소 |
| Topic | `/factory/robot_state` | `std_msgs/String`에 담긴 JSON 상태 |

`TransportJob.action`:

```text
string job_id
string destination
---
bool success
string message
---
string state
geometry_msgs/PoseStamped pose
float32 remaining_distance
```

상태 Topic의 JSON 필드는 `job_id`, `destination`, `state`, `x`, `y`, `remaining_distance`, `message`다. 좌표계는 `map`, 거리 단위는 m다.

기본 목적지:

| 목적지 | x | y |
| --- | ---: | ---: |
| `warehouse` | 0 | 0 |
| `line_a` | 3 | 0 |
| `line_b` | 3 | 2 |

한 번에 한 작업을 받는다. 빈 작업 ID, 알 수 없는 목적지, 이미 접수한 ID, 다른 작업 실행 중의 추가 요청은 거절한다. 취소하면 현재 위치에서 이동 갱신을 멈추고 새 ID의 다음 작업을 받을 수 있다. 접수 이력은 프로세스 메모리에 있으므로 서버를 재시작하면 초기화된다.

## 후속 개발

이 프로젝트는 ROS Action을 사용하는 작업 흐름의 출발점이다. 정적 샘플 지도에서 A* 경로 계획과 벽 충돌 검사를 구현했다. 로봇 위치 추정, 실제 주행, SLAM, 센서 기반 동적 장애물 회피, 적재·하역은 구현하지 않는다. MES·WMS·FMS 제품, MQTT, OPC UA, VDA 5050 연동도 포함하지 않는다.

다음 단계는 RViz 시각화 → Gazebo·Nav2 주행 → 외부 관제 작업 연동 → PLC 설비 인계 순서로 확장할 수 있다. 자세한 범위와 공식 자료는 [프로젝트 구상](docs/PROJECT_PLAN.md)을 참고한다.

## 사용자 도면 편집

웹 UI에서 도면 크기를 정하고 벽·장애물을 배치할 수 있습니다. [도면 편집 사용법](docs/MAP_EDITOR.md)을 참고하세요. 적용된 지도는 ROS 경로 탐색과 Codex 입력 이미지에 함께 반영되며 서버 재시작 후에도 유지됩니다.

## LLM 판단 로그

웹 하단의 **LLM 판단 로그**에서 Codex가 반환한 목표와 근거 요약, 좌표·경로 검증, ROS 실행 결과를 요청별로 볼 수 있습니다. 출처·요청 필터와 검색, 상세 데이터 펼치기를 지원합니다. 현재 서버 세션의 최근 200개를 유지합니다. [자세한 설명](docs/CODEX_VISION.md#llm-판단-로그)

## 실시간 판단 주행과 움직이는 장애물

기본 화면에서 Codex가 최신 관측을 보고 최대 0.5m의 다음 행동을 반복 선택합니다. 주황색 장애물을 드래그하거나 왕복 이동시킬 수 있습니다. [실시간 모드 사용법과 동작 제한](docs/REALTIME.md)을 참고하세요. 지도 편집, 기존 운반, 판단·ROS 로그는 각각의 탭에서 사용합니다.

YOLO 실제 영상 탐지와 표시/숨김 설정: [YOLO 안내](docs/YOLO.md).
