#!/usr/bin/env python3
"""Real service checks: new obstacle after capture, rejection, and stopping a live request."""
import json
import time
from pathlib import Path
from web_smoke import request,wait_for
initial=request('/api/state');before_ids={o['id'] for o in initial['obstacles']};extra=None
assert initial['can_submit']
try:
    request('/api/realtime/control',{'operation':'start','destination':'warehouse'})
    state=wait_for(lambda s:s['realtime'].get('phase')=='THINKING',15)
    observation=state['realtime']['observation'];pose=[state['robot']['x'],state['robot']['y']]
    assert pose[0]>2.8 and pose[1]>1.9,pose
    request('/api/jobs',{'job_id':'RT-BUSY-'+str(time.time_ns()),'destination':'line_a'},409)
    request('/api/teleop',{'x':1,'y':0,'issued_at':time.time()},409)
    request('/api/map',{'expected_id':state['navigation']['id'],'map':state['navigation']},409)
    response=request('/api/realtime/control',{'operation':'obstacle','obstacle':{'operation':'add','x':2.6,'y':2}})
    extra=next(o['id'] for o in response['obstacles'] if o['id'] not in before_ids)
    state=wait_for(lambda s:any(e['request_id']==observation['session'] and e['stage']=='행동 차단 · 재관측' for e in s['ai']['logs']),40)
    assert [state['robot']['x'],state['robot']['y']]==pose
    print('PASS obstacle inserted after capture blocks old proposed action; automatic/manual/map controls excluded',flush=True)
    request('/api/realtime/control',{'operation':'stop'})
    state=wait_for(lambda s:s['realtime']['phase']=='STOPPED')
    pose=[state['robot']['x'],state['robot']['y']]
    time.sleep(8)
    state=request('/api/state')
    assert not state['realtime']['active'] and [state['robot']['x'],state['robot']['y']]==pose
    Path('docs/evidence/realtime-guard-decisions.json').write_text(json.dumps(state['ai']['logs'],ensure_ascii=False,indent=2))
    print('PASS stop holds pose while late model responses cannot move robot',flush=True)
finally:
    if request('/api/state')['realtime'].get('active'):request('/api/realtime/control',{'operation':'stop'})
    if extra:request('/api/realtime/control',{'operation':'obstacle','obstacle':{'operation':'delete','id':extra}})
