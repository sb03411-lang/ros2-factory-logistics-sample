#!/usr/bin/env python3
"""Exercise editable maps against the running local ROS/web stack."""
import hashlib
import json
import math
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.navigation import NavigationMap
BASE='http://localhost:8765'
def get(path='/api/state'):
    with urllib.request.urlopen(BASE+path, timeout=5) as response:
        data=response.read()
        return data if path.startswith('/floorplan') else json.loads(data)
def post(path,payload,expected=200):
    request=urllib.request.Request(BASE+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Factory-Control':'1'})
    try:
        response=urllib.request.urlopen(request,timeout=8)
    except urllib.error.HTTPError as error:
        response=error
    result=json.loads(response.read())
    assert response.code==expected,(path,response.code,result)
    return result
def wait(predicate,seconds=12):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        state=get()
        if predicate(state):return state
        time.sleep(.12)
    raise AssertionError('state timeout')
def apply(data):
    result=post('/api/map',{'expected_id':get()['navigation']['id'],'map':data})
    return wait(lambda s:s['navigation']['id']==result['map_id'] and not s['map_pending'])
initial=get()['navigation']
assert get()['can_submit']
custom={'center_bounds':[0,0,5,4],'walls':[[1,.5,2,1.5]]}
try:
    state=apply(custom)
    nav=NavigationMap(state['navigation'])
    assert state['robot']['navigation']['id']==nav.data['id']
    assert hashlib.sha256(get('/floorplan.png')).hexdigest()==state['ai']['map_hash']
    assert not nav.segment_free((0,0),(3,2))
    assert len(state['preview_routes']['line_b'])>2
    old_id=nav.data['id']
    for bad in ({'center_bounds':[0,0,5,4],'walls':[[0,0,.5,.5]]},
                {'center_bounds':[0,0,5,4],'walls':[[1.4,0,1.6,4]]},
                {'center_bounds':[0,0,1000,1000],'walls':[]}):
        post('/api/map',{'expected_id':old_id,'map':bad},400)
        assert get()['navigation']['id']==old_id
    post('/api/map',{'expected_id':'stale-revision','map':custom},409)
    print('PASS map validation, blocked pose, disconnected route, stale revision, image hash',flush=True)
    job='MAPTEST-'+str(int(time.time()*1000))
    post('/api/jobs',{'job_id':job,'destination':'line_b'},202)
    wait(lambda s:s['robot']['state']=='RUNNING')
    post('/api/map',{'expected_id':old_id,'map':custom},409)
    trace=[]
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        state=get();robot=state['robot'];p=(robot['x'],robot['y']);trace.append(p)
        assert nav.point_free(p),p
        assert all(nav.segment_free(a,b) for a,b in zip(robot['path'],robot['path'][1:]))
        if robot['state']=='SUCCEEDED':break
        time.sleep(.05)
    assert state['robot']['state']=='SUCCEEDED'
    assert any(x>2.1 and y<1 for x,y in trace),trace
    print('PASS actual ROS detour and map change rejected during movement',flush=True)
    post('/api/ai/request',{'prompt':'편집된 공장 도면에서 WAREHOUSE 창고를 찾아 이동 목표로 지정해 줘.'},202)
    state=wait(lambda s:s['ai']['plan']['state'] not in ('QUEUED','READING'),210)
    plan=state['ai']['plan'];assert plan['state']=='READY',plan
    assert plan['result']['destination']=='warehouse',plan
    assert plan['result']['map_id']==old_id,plan
    print('PASS real Codex recognizes target on regenerated custom floorplan',flush=True)
    apply(dict(custom,walls=[[1,.6,2,1.5]]))
    assert get()['ai']['plan']['state']=='EXPIRED'
    post('/api/ai/execute',{'id':plan['id']},409)
    print('PASS saved map invalidates old Codex execution plan',flush=True)
finally:
    state=wait(lambda s:s['can_submit'])
    post('/api/jobs',{'job_id':'MAPRETURN-'+str(int(time.time()*1000)),'destination':'warehouse'},202)
    wait(lambda s:s['robot']['state']=='SUCCEEDED')
    apply(initial)
print('PASS original map restored; robot returned to warehouse')
