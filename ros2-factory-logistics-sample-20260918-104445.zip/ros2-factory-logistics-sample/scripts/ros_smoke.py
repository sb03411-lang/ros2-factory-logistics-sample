#!/usr/bin/env python3
"""Actual ROS integration check; requires built and sourced Jazzy workspace.

Starts its own server in a separate process on a private localhost ROS domain.
Checks actions, feedback, telemetry, rejection, cancel, and subsequent recovery.
"""
import collections
import json
import os
import random
import subprocess
import sys
import threading
import time


def main():
    os.environ['ROS_DOMAIN_ID'] = str(random.SystemRandom().randint(20, 80))
    os.environ['ROS_LOCALHOST_ONLY'] = '1'
    import rclpy
    from action_msgs.msg import GoalStatus
    from rclpy.action import ActionClient
    from rclpy.node import Node
    from std_msgs.msg import String
    from factory_interfaces.action import TransportJob
    from factory_logistics.task_dispatcher import wait_future

    server = subprocess.Popen(
        [sys.executable, '-m', 'factory_logistics.simulated_robot'],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    tail = collections.deque(maxlen=30)

    def capture():
        for line in server.stdout:
            tail.append(line.rstrip())

    reader = threading.Thread(target=capture, daemon=True)
    reader.start()
    node = None
    client = None
    code = 1
    total_deadline = time.monotonic() + 45.0
    try:
        rclpy.init()
        node = Node('factory_smoke_check')
        client = ActionClient(node, TransportJob, '/factory/transport')
        states = []
        feedback = []

        def record_state(message):
            states.append(json.loads(message.data))

        subscription = node.create_subscription(String, '/factory/robot_state', record_state, 10)

        def spin_until(predicate, seconds=3.0):
            deadline = min(total_deadline, time.monotonic() + seconds)
            while not predicate() and time.monotonic() < deadline:
                if server.poll() is not None:
                    raise RuntimeError('simulation server exited early')
                rclpy.spin_once(node, timeout_sec=0.05)
            if not predicate():
                raise TimeoutError('expected ROS event was not observed')

        def send(job_id, destination, accepted=True):
            request = TransportJob.Goal(job_id=job_id, destination=destination)
            handle = wait_future(node, client.send_goal_async(
                request, feedback_callback=lambda msg: feedback.append(msg.feedback)), 3.0)
            if handle.accepted != accepted:
                raise AssertionError('Unexpected admission for {}'.format(job_id))
            return handle

        def finish(handle, expected=GoalStatus.STATUS_SUCCEEDED, seconds=8.0):
            future = handle.get_result_async()
            spin_until(future.done, seconds)
            value = future.result()
            assert value.status == expected, value.status
            assert value.result.success == (expected == GoalStatus.STATUS_SUCCEEDED)
            return value

        if not client.wait_for_server(timeout_sec=10.0):
            raise TimeoutError('server discovery failed')
        print('ROS domain {}: real Action/Topic smoke check'.format(os.environ['ROS_DOMAIN_ID']), flush=True)
        finish(send('SMOKE-001', 'line_a'))
        finish(send('SMOKE-002', 'warehouse'))
        spin_until(lambda: states and states[-1]['job_id'] == 'SMOKE-002'
                   and states[-1]['state'] == 'SUCCEEDED')
        assert states[-1]['x'] == 0.0 and states[-1]['y'] == 0.0
        assert feedback and all(item.pose.header.frame_id == 'map' for item in feedback)
        print('PASS: warehouse -> line_a -> warehouse, feedback and state Topic', flush=True)

        send('', 'line_a', accepted=False)
        send('SMOKE-INVALID', 'missing_station', accepted=False)
        send('SMOKE-001', 'line_a', accepted=False)
        moving = send('SMOKE-CANCEL', 'line_b')
        spin_until(lambda: states and states[-1]['job_id'] == 'SMOKE-CANCEL' and states[-1]['x'] > 0.0)
        send('SMOKE-BUSY', 'warehouse', accepted=False)
        reply = wait_future(node, moving.cancel_goal_async(), 3.0)
        assert reply.goals_canceling, 'cancellation rejected'
        finish(moving, GoalStatus.STATUS_CANCELED, seconds=3.0)
        spin_until(lambda: states and states[-1]['state'] == 'CANCELED')
        stopped_position = (states[-1]['x'], states[-1]['y'])
        first_new = len(states)
        spin_until(lambda: len(states) >= first_new + 3)
        assert all((s['x'], s['y']) == stopped_position for s in states[first_new:])
        print('PASS: invalid/duplicate/busy requests rejected; cancel stops movement', flush=True)

        # A rejected ID was never admitted and may be reused after cancellation.
        finish(send('SMOKE-BUSY', 'warehouse'))
        print('PASS: new job after cancellation; all ROS checks complete', flush=True)
        node.destroy_subscription(subscription)
        code = 0
    except Exception as exc:
        print('FAIL: {}'.format(exc), file=sys.stderr)
        for line in list(tail):
            print('server: ' + line, file=sys.stderr)
    finally:
        if client is not None:
            client.destroy()
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        if server.poll() is None:
            server.terminate()
            try:
                server.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait(timeout=3.0)
        reader.join(timeout=1.0)
        if server.stdout is not None:
            server.stdout.close()
    return code


if __name__ == '__main__':
    sys.exit(main())
