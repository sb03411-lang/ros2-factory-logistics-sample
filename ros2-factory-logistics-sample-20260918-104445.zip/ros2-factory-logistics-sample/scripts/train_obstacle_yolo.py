#!/usr/bin/env python3
"""One-class camera detector. Ground-truth geometry is used ONLY offline for labels."""
import argparse,sys,math,random,json,os,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/factory_logistics'))
from factory_logistics.camera import render_camera
from factory_logistics.navigation import NavigationMap
from PIL import Image,ImageEnhance

def generate(root):
 for split,count,seed in [('train',240,91232),('val',60,1144),('test',60,86212)]:
  rng=random.Random(seed)
  for d in ['images','labels']:(root/split/d).mkdir(parents=True,exist_ok=True)
  for n in range(count):
   width=8.;walls=[[x,y,x+.8,y+1.4] for x in [1,3.6,6.2] for y in [1,3.4,5.8]]
   if n%4==0:walls=[]
   if n%5==0:walls=[[x+.15,y,x2+.15,y2] for x,y,x2,y2 in walls]
   nav=NavigationMap(dict(id='dataset',resolution=.1,robot_radius=.25,center_bounds=[0,0,8,8],outer_bounds=[-.4,-.4,8.4,8.4],walls=walls))
   # Random camera position on free aisles; include close shelves and empty negatives.
   while True:
    pose=[rng.uniform(.1,7.9),rng.uniform(.1,7.9)]
    if nav.point_free(pose):break
   yaw=rng.uniform(-math.pi,math.pi);objects=[]
   for i in range(0 if n%4==0 else rng.randint(1,4)):
    for _ in range(30):
     d=rng.uniform(.7,4.2);a=yaw+rng.uniform(-.75,.75);x=pose[0]+d*math.cos(a);y=pose[1]+d*math.sin(a)
     if nav.point_free([x,y]):break
    else:continue
    kind=rng.choice(['person','obstacle']);objects.append(dict(id=str(i),x=x,y=y,radius=.22 if kind=='person' else rng.uniform(.10,.25),kind=kind,walk_phase=rng.uniform(0,6.28)))
   png,boxes=render_camera(nav,dict(pose=pose,yaw=yaw,obstacles=objects),annotations=True)
   im=Image.open(io.BytesIO(png)).convert('RGB')
   if split=='train':im=ImageEnhance.Brightness(im).enhance(rng.uniform(.8,1.2))
   im.save(root/split/'images'/f'{n:04d}.jpg',quality=92)
   (root/split/'labels'/f'{n:04d}.txt').write_text('\n'.join(f'0 {(b["xyxy"][0]+b["xyxy"][2])/1280} {(b["xyxy"][1]+b["xyxy"][3])/720} {(b["xyxy"][2]-b["xyxy"][0])/640} {(b["xyxy"][3]-b["xyxy"][1])/360}' for b in boxes))
   if n%30==0:print(split,n,flush=True)
 (root/'data.yaml').write_text(f'path: {root.resolve()}\ntrain: train/images\nval: val/images\ntest: test/images\nnames:\n  0: obstacle\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--model',required=True);p.add_argument('--epochs',type=int,default=14);a=p.parse_args();root=Path(a.data)
 (root/'settings').mkdir(parents=True,exist_ok=True);os.environ['YOLO_CONFIG_DIR']=str(root/'settings');generate(root)
 import torch
 from ultralytics import YOLO
 torch.set_num_threads(3)
 model=YOLO(a.model)
 model.train(data=str(root/'data.yaml'),epochs=a.epochs,imgsz=416,batch=12,device='mps' if torch.backends.mps.is_available() else 'cpu',workers=0,project=str(root/'runs'),name='obstacle',exist_ok=True,patience=6,plots=False,amp=False,cache=True,seed=51,fliplr=.5,mosaic=.15,close_mosaic=4,scale=.2,translate=.05)
 result=YOLO(str(root/'runs/obstacle/weights/best.pt')).val(data=str(root/'data.yaml'),split='test',imgsz=416,device='cpu',workers=0,plots=False,conf=.35)
 (root/'test-metrics.json').write_text(json.dumps(result.results_dict,indent=2))
