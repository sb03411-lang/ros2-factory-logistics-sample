#!/usr/bin/env bash
# Project-local Docker configuration; no global context or shell changes.
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
runtime="$PROJECT_DIR/.runtime"
ancestor="$PROJECT_DIR"
while [[ "$ancestor" != / ]]; do
  if [[ "${ancestor##*/}" == Codex ]]; then runtime="$ancestor/work/r2"; break; fi
  ancestor="$(dirname "$ancestor")"
done
runtime="${ROS2_SAMPLE_RUNTIME:-$runtime}"
[[ "$runtime" == /* ]] || runtime="$PWD/$runtime"
export COLIMA_HOME="$runtime/c" DOCKER_CONFIG="$runtime/docker"
export DOCKER_HOST="unix://$COLIMA_HOME/ros2/docker.sock"
unset DOCKER_CONTEXT DOCKER_TLS_VERIFY DOCKER_CERT_PATH
IMAGE=factory-logistics:jazzy
CONTAINER=factory-logistics-sample
ENTRYPOINT=/workspace/scripts/entrypoint.sh

die() { printf '오류: %s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'HELP'
사용법: bash scripts/ros2.sh <명령> [작업 옵션]
  start   전용 Colima VM 시작 (이미 실행 중이면 유지)
  build   ROS 이미지 빌드
  test    실제 ROS Action/Topic 통합 검사 후 종료
  demo    기본 운반 작업 두 개 실행 후 종료
  up      백그라운드 로봇 서버 시작, Action 준비 확인
  web     로봇 + 웹 관제 시작 (http://localhost:8765)
  send    실행 중인 서버에 작업 요청 (dispatcher 옵션 전달)
  state   실행 중인 서버의 상태 메시지 한 개 출력
  down    이 샘플 소유의 로봇 서버 컨테이너만 중지·제거
  stop    샘플 서버 제거 후 전용 Colima VM 중지
  status  VM 및 샘플 서버 상태 조회
  help    이 도움말
예: bash scripts/ros2.sh send --job-id JOB-003 --destination line_b
ROS2_SAMPLE_RUNTIME 환경변수로 런타임 디렉터리를 지정할 수 있습니다.
HELP
}
check_tools() {
  local tool socket_path socket_bytes
  for tool in brew colima docker python3; do
    command -v "$tool" >/dev/null || die "$tool 없음. Homebrew 설치 후 brew install colima docker docker-buildx 를 실행하세요."
  done
  socket_path="$COLIMA_HOME/_lima/colima-ros2/ssh.sock.1234567890123456"
  socket_bytes="$(printf '%s' "$socket_path" | LC_ALL=C wc -c)"
  [[ "$socket_bytes" -le 103 ]] || die "UNIX 소켓 경로가 ${socket_bytes// /}바이트입니다(최대 103). ROS2_SAMPLE_RUNTIME을 더 짧은 절대경로로 지정하세요."
}
prepare_config() {
  mkdir -p "$DOCKER_CONFIG"
  python3 - "$DOCKER_CONFIG/config.json" "$(brew --prefix)/lib/docker/cli-plugins" <<'PY'
import json, os, sys, tempfile
from pathlib import Path
path, plugins = Path(sys.argv[1]), sys.argv[2]
config = json.loads(path.read_text()) if path.exists() else {}
if not isinstance(config, dict):
    raise SystemExit("Docker config.json must contain an object")
directories = config.setdefault("cliPluginsExtraDirs", [])
if not isinstance(directories, list):
    raise SystemExit("cliPluginsExtraDirs must be a list")
if plugins not in directories:
    directories.append(plugins)
if not path.exists() or json.loads(path.read_text()) != config:
    with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False) as temp:
        json.dump(config, temp, indent=2)
        temp.write("\n")
    os.replace(temp.name, path)
PY
  docker buildx version >/dev/null 2>&1 || die "Docker buildx가 필요합니다. brew install docker-buildx 를 실행하세요."
}
start_runtime() {
  prepare_config
  if colima status ros2 >/dev/null 2>&1; then return; fi
  colima start ros2 --cpus 2 --memory 4 --disk 20 --vm-type vz --mount none \
    --ssh-config=false --activate=false --template=false
}
build_image() { start_runtime; docker build -t "$IMAGE" "$PROJECT_DIR"; }
ensure_image() {
  start_runtime
  docker image inspect "$IMAGE" >/dev/null 2>&1 || docker build -t "$IMAGE" "$PROJECT_DIR"
}
container_exists() { docker container inspect "$CONTAINER" >/dev/null 2>&1; }
require_owned() {
  [[ "$(docker inspect --format '{{ index .Config.Labels "ros2.factory.sample" }}' "$CONTAINER")" == true ]] \
    || die "$CONTAINER 컨테이너가 이 샘플 소유가 아닙니다. 자동으로 변경하지 않습니다."
}
require_running() {
  container_exists || die "실행할 서버가 없습니다. 먼저 up을 실행하세요."
  require_owned
  [[ "$(docker inspect --format '{{.State.Running}}' "$CONTAINER")" == true ]] \
    || die "서버가 중지되어 있습니다. 먼저 up을 실행하세요."
}
down_server() {
  if ! docker info >/dev/null 2>&1; then printf 'Docker VM이 실행 중이지 않습니다.\n'; return; fi
  if ! container_exists; then return; fi
  require_owned
  docker stop "$CONTAINER" >/dev/null
  docker rm "$CONTAINER"
}
up_server() {
  local create_server=true
  ensure_image
  if container_exists; then
    require_owned
    if [[ "$(docker inspect --format '{{.State.Running}}' "$CONTAINER")" == true ]]; then
      printf '%s 서버가 이미 실행 중입니다.\n' "$CONTAINER"; create_server=false
    else
      docker rm "$CONTAINER" >/dev/null
    fi
  fi
  if [[ "$create_server" == true ]]; then
    docker run --detach --name "$CONTAINER" --label ros2.factory.sample=true "$IMAGE" \
    python3 -m factory_logistics.simulated_robot
  fi
  if ! docker exec "$CONTAINER" bash "$ENTRYPOINT" python3 -c \
    'import sys, rclpy; from rclpy.action import ActionClient; from factory_interfaces.action import TransportJob; rclpy.init(); node=rclpy.create_node("factory_ready_check"); client=ActionClient(node, TransportJob, "/factory/transport"); ready=client.wait_for_server(timeout_sec=10.0); client.destroy(); node.destroy_node(); rclpy.shutdown(); sys.exit(0 if ready else 1)'; then
    docker logs --tail 30 "$CONTAINER" >&2
    die "10초 안에 ROS Action 서버를 발견하지 못했습니다."
  fi
  printf '로봇 서버 준비 완료: /factory/transport\n'
}

web_server() {
  ensure_image
  if container_exists; then
    require_owned
    if [[ "$(docker inspect --format '{{.State.Running}}' "$CONTAINER")" == true ]]; then
      [[ "$(docker inspect --format '{{ index .Config.Labels "ros2.factory.web" }}' "$CONTAINER")" == true ]] \
        || die "CLI 서버가 실행 중입니다. 작업 종료 후 down을 실행하고 web을 시작하세요."
    else
      docker rm "$CONTAINER" >/dev/null
    fi
  fi
  if ! container_exists; then
    docker run --detach --name "$CONTAINER" --label ros2.factory.sample=true --label ros2.factory.web=true \
      -p 127.0.0.1:8765:8765 -v factory-logistics-map-data:/workspace/data \
      -e FACTORY_MAP_PATH=/workspace/data/map.json "$IMAGE" ros2 launch factory_logistics web.launch.py
  fi
  local attempt
  for attempt in {1..30}; do
    if curl --fail --silent http://localhost:8765/api/state | python3 -c 'import json,sys; sys.exit(0 if json.load(sys.stdin)["connected"] else 1)' 2>/dev/null; then
      mkdir -p "$runtime/ai"
      python3 - "$PROJECT_DIR/scripts/codex_worker.py" "$runtime/ai" <<'PY'
import pathlib, subprocess, sys
with (pathlib.Path(sys.argv[2]) / 'worker.log').open('a') as log:
    subprocess.Popen([sys.executable, sys.argv[1], '--runtime-dir', sys.argv[2]],
                     stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
PY
      if [[ -x "$PROJECT_DIR/../../work/yolo-venv/bin/python" ]]; then bash "$PROJECT_DIR/scripts/yolo.sh" start; fi
      printf '웹 관제 준비 완료: http://localhost:8765\n'; return
    fi
    sleep 1
  done
  docker logs --tail 30 "$CONTAINER" >&2
  die "웹 서버가 준비되지 않았습니다. 컨테이너 로그를 확인하세요."
}

operation="${1:-help}"
[[ "$#" -eq 0 ]] || shift
case "$operation" in help|-h|--help) usage; exit 0;; esac
case "$operation" in start|build|test|demo|up|web|send|state|down|stop|status) ;; *) usage; die "알 수 없는 명령: $operation";; esac
check_tools
case "$operation" in
  start) start_runtime;;
  build) build_image;;
  test) ensure_image; docker run --rm "$IMAGE";;
  demo) ensure_image; docker run --rm "$IMAGE" ros2 launch factory_logistics demo.launch.py;;
  up) up_server;;
  web) web_server;;
  send) require_running; docker exec "$CONTAINER" bash "$ENTRYPOINT" ros2 run factory_logistics task_dispatcher "$@";;
  state) require_running; docker exec "$CONTAINER" bash "$ENTRYPOINT" timeout 10s ros2 topic echo /factory/robot_state --once --full-length;;
  down) down_server;;
  stop) down_server; colima stop ros2;;
  status) printf '런타임: %s\n' "$runtime"
    if colima status ros2 >/dev/null 2>&1; then colima status ros2
    else printf 'Colima ros2가 실행 중이지 않습니다. demo 또는 up으로 시작할 수 있습니다.\n'; fi
    if docker info >/dev/null 2>&1; then docker ps -a --filter "name=^/${CONTAINER}$"; fi;;
esac
