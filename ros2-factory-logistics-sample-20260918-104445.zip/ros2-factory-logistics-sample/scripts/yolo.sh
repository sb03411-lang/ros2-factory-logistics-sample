#!/usr/bin/env bash
set -euo pipefail
project="$(cd "$(dirname "$0")/.." && pwd)"
yolo_work="${ROS2_YOLO_RUNTIME:-$project/../../work}"
yolo_python="$yolo_work/yolo-venv/bin/python"
mkdir -p "$yolo_work/yolo-models"
case "${1:-start}" in
 install)
  "${PYTHON_BIN:-python3}" -m venv "$yolo_work/yolo-venv"
  "$yolo_python" -m pip install 'ultralytics==8.4.145'
  ;;
 start)
  [[ -x "$yolo_python" ]] || { echo 'Run scripts/yolo.sh install first'; exit 1; }
  "$yolo_python" - "$project" "$yolo_work" <<'PY'
import pathlib,subprocess,sys,fcntl
project,work=map(pathlib.Path,sys.argv[1:])
model=work/'yolo-models/warehouse-obstacle.pt'
if not model.exists():model=project/'models/warehouse-obstacle.pt'
if not model.exists():
    print('Camera obstacle model missing:',model);sys.exit(1)
runtime=work/'camera-runtime';runtime.mkdir(exist_ok=True)
with (runtime/'camera-worker.lock').open('a') as guard:
    try:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:print('Camera worker already running');sys.exit(0)
with (work/'camera-worker.log').open('a') as log:
    proc=subprocess.Popen([str(work/'yolo-venv/bin/python'),str(project/'scripts/camera_worker.py'),'--model',str(model),'--runtime',str(work/'camera-runtime')],cwd=work,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
(work/'camera-worker.pid').write_text(str(proc.pid))
print('Camera worker starting; log:',work/'camera-worker.log')
PY
  ;;
 *) echo 'Usage: yolo.sh install|start'; exit 1;;
esac
