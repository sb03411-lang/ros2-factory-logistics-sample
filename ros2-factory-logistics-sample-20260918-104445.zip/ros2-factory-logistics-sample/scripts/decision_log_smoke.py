#!/usr/bin/env python3
"""Verify real Codex decisions, clarification, validators, and ROS completion logs."""
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
BASE='http://localhost:8765'
def get():
    return json.load(urllib.request.urlopen(BASE+'/api/state',timeout=5))
def post(path,payload,expected=202):
    request=urllib.request.Request(BASE+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Factory-Control':'1'})
    try:response=urllib.request.urlopen(request,timeout=8)
    except urllib.error.HTTPError as error:response=error
    result=json.load(response)
    assert response.code==expected,(response.code,result)
    return result
def wait(predicate,seconds=210):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        state=get()
        if predicate(state):return state
        time.sleep(.3)
    raise AssertionError('state timeout')
assert get()['can_submit']
post('/api/ai/request',{'prompt':'도면의 출하장 Z로 이동해 줘.'})
state=wait(lambda s:s['ai']['plan']['state'] not in ('QUEUED','READING'))
clarify=state['ai']['plan'];assert clarify['state']=='CLARIFY',clarify
logs=[row for row in state['ai']['logs'] if row['request_id']==clarify['id']]
assert any(row['source']=='LLM' and row['details']['status']=='needs_clarification' for row in logs)
assert any(row['stage']=='실행 보류' for row in logs)
assert not any(row['source']=='ROS' for row in logs)
post('/api/ai/execute',{'id':clarify['id']},409)
print('PASS real unknown target: model evidence, clarification, execution hold/rejection',flush=True)
post('/api/ai/request',{'prompt':'도면에서 생산라인 B를 찾아 이동 목표로 지정해 줘.'})
state=wait(lambda s:s['ai']['plan']['state'] not in ('QUEUED','READING'))
plan=state['ai']['plan'];assert plan['state']=='READY',plan
logs=[row for row in state['ai']['logs'] if row['request_id']==plan['id']]
assert {row['stage'] for row in logs}>={'요청 접수','Codex 해석 시작','도면 판단 결과','목표 좌표 검증 통과','통로 경로 검증 통과','실행 대기'}
model=next(row for row in logs if row['source']=='LLM')
assert model['message'] and model['details']['destination']=='line_b'
assert model['details']['target_x']==3 and model['details']['target_y']==2
print('PASS real target: LLM explanation and coordinates separate from deterministic validator',flush=True)
post('/api/ai/execute',{'id':plan['id']})
state=wait(lambda s:s['ai']['plan']['state']=='SUCCEEDED',20)
logs=state['ai']['logs']
assert sum(row['request_id']==plan['id'] and row['stage']=='이동 결과' for row in logs)==1
assert any(row['request_id']==clarify['id'] for row in logs)
assert all('token' not in row and 'token' not in row['details'] for row in logs)
Path('docs/evidence/decision-logs.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
print('PASS ROS request/completion logged once; prior request history retained; tokens excluded')
