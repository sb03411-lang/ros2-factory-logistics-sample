#!/usr/bin/env python3
"""Local pixel-only YOLO inference; never receives world coordinates or controls ROS."""
import argparse
import io
import json
import os
from pathlib import Path
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--model',required=True)
    parser.add_argument('--port',type=int,default=8768)
    args=parser.parse_args()
    # Acquire listening socket first: duplicate starts exit before loading weights.
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
    config=Path(args.model).parent/'settings'
    config.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('YOLO_CONFIG_DIR',str(config))
    import torch
    from PIL import Image
    from ultralytics import YOLO
    torch.set_num_threads(2)
    Image.MAX_IMAGE_PIXELS=1280*720
    server.model=YOLO(args.model)
    server.gate=threading.Lock()
    server.model.predict(Image.new('RGB',(640,360)),device='cpu',imgsz=640,verbose=False)
    print('YOLO26n ready on 127.0.0.1:'+str(args.port),flush=True)
    server.serve_forever()


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def allowed(self):
        return (self.headers.get('Host') in ('localhost:'+str(self.server.server_port),'127.0.0.1:'+str(self.server.server_port)) and
                self.headers.get('Origin') in ('http://localhost:8765','http://127.0.0.1:8765'))
    def reply(self,status,payload):
        body=json.dumps(payload).encode()
        self.send_response(status)
        if self.allowed():
            self.send_header('Access-Control-Allow-Origin',self.headers['Origin'])
            self.send_header('Vary','Origin')
        self.send_header('Content-Type','application/json')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        try:self.wfile.write(body)
        except (BrokenPipeError,ConnectionResetError):pass
    def do_OPTIONS(self):
        if not self.allowed():return self.reply(403,{'error':'origin'})
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin',self.headers['Origin'])
        self.send_header('Access-Control-Allow-Methods','POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type, X-Yolo-Request')
        self.send_header('Access-Control-Max-Age','600')
        self.end_headers()
    def do_POST(self):
        if self.path!='/detect':return self.reply(404,{'error':'path'})
        if not self.allowed() or self.headers.get('X-Yolo-Request')!='1':return self.reply(403,{'error':'origin'})
        try:length=int(self.headers.get('Content-Length',0))
        except ValueError:return self.reply(400,{'error':'length'})
        if self.headers.get('Content-Type')!='image/jpeg' or not 0<length<=1024*1024:return self.reply(400,{'error':'JPEG must be under 1MB'})
        if not self.server.gate.acquire(blocking=False):return self.reply(429,{'error':'inference busy'})
        try:
            from PIL import Image,UnidentifiedImageError
            self.connection.settimeout(5)
            image=Image.open(io.BytesIO(self.rfile.read(length)))
            if image.format!='JPEG' or image.size!=(640,360):return self.reply(400,{'error':'Expected 640x360 JPEG'})
            image=image.convert('RGB');start=time.perf_counter()
            result=self.server.model.predict(image,device='cpu',imgsz=640,conf=.35,max_det=30,verbose=False)[0]
            boxes=[dict(xyxy=[round(v,1) for v in box.xyxy[0].tolist()],class_id=int(box.cls.item()),label=result.names[int(box.cls.item())],confidence=round(box.conf.item(),4)) for box in result.boxes]
            self.reply(200,dict(model='YOLO26n · COCO',device='cpu',inference_ms=round((time.perf_counter()-start)*1000,1),width=640,height=360,confidence_threshold=.35,detections=boxes))
        except Exception as exc:
            print(type(exc).__name__,flush=True)
            self.reply(400,{'error':'Image inference failed'})
        finally:self.server.gate.release()

if __name__=='__main__':main()
