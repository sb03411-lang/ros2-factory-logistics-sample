"""Real HTTP/ROS manual control and rosout integration check."""
import time
from web_smoke import request, wait_for


def velocity(x, y, expected=202, age=0):
    return request('/api/teleop', {'x': x, 'y': y, 'issued_at': time.time() - age}, expected)


def main():
    wait_for(lambda s: s['can_submit'])
    prefix = 'TELEOP-' + str(time.time_ns())
    request('/api/jobs', {'job_id': prefix, 'destination': 'warehouse'}, 202)
    wait_for(lambda s: s['robot']['job_id'] == prefix and s['robot']['state'] == 'SUCCEEDED')
    velocity(2, 0, 400)
    velocity(1, 0, 400, age=2)
    for _ in range(8):
        velocity(1, 1)
        time.sleep(.1)
    moving = request('/api/state')
    assert moving['robot']['state'] == 'MANUAL' and moving['robot']['x'] > .1 and moving['robot']['y'] > .1
    request('/api/jobs', {'job_id': prefix + '-BUSY', 'destination': 'line_a'}, 409)
    # No zero command: ROS node must stop on its own watchdog.
    stopped = wait_for(lambda s: s['robot']['state'] == 'IDLE')
    time.sleep(.4)
    later = request('/api/state')
    assert (stopped['robot']['x'], stopped['robot']['y']) == (later['robot']['x'], later['robot']['y'])
    print('PASS diagonal movement, stale/invalid rejection, auto/manual exclusion, ROS watchdog stop')
    for _ in range(4):
        velocity(-1, 0)
        time.sleep(.1)
    velocity(0, 0)
    wait_for(lambda s: s['robot']['state'] == 'IDLE')
    request('/api/jobs', {'job_id': prefix + '-AUTO', 'destination': 'line_b'}, 202)
    wait_for(lambda s: s['robot']['state'] == 'RUNNING')
    velocity(1, 0, 409)
    wait_for(lambda s: s['robot']['state'] == 'SUCCEEDED')
    logs = wait_for(lambda s: any('arrived' in l['message'] for l in s['ros_logs']))['ros_logs']
    assert any(l['name'] == 'simulated_robot' and 'Manual control stopped' in l['message'] for l in logs)
    assert all({'stamp', 'level', 'name', 'message', 'file', 'function', 'line'} <= set(l) for l in logs)
    print('PASS zero stop, manual rejection during automatic action, real rosout source and message fields')
    print('TELEOP AND ROS LOG CHECKS PASSED')


if __name__ == '__main__':
    main()
