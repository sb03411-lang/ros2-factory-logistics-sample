"""Run against isolated ROS_DOMAIN_ID 67 container published on port 8766."""
import json,time,urllib.request
BASE='http://localhost:8766'
def req(path='/api/state',data=None):
    return json.load(urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json','X-Factory-Control':'1','Host':'localhost:8765'}),timeout=8))
def control(**data):return req('/api/realtime/control',data)
def wait(predicate,seconds=35):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        s=req()
        if predicate(s):return s
        time.sleep(.1)
    raise AssertionError(s['realtime'])
wait(lambda s:s['connected'])
control(operation='obstacle',obstacle=dict(operation='add',x=2.7,y=0))
control(operation='start',destination='line_a',mode='global')
s=wait(lambda s:s['realtime']['active'])
assert s['realtime']['replans']==1 and not s['sensor']['tracks']
s=wait(lambda s:s['sensor']['tracks']);assert s['robot']['x']>=.55
s=wait(lambda s:s['realtime']['replans']>=2)
assert any(p[1]>1.8 for p in s['realtime']['route'])
s=wait(lambda s:s['realtime']['phase']=='ARRIVED')
assert any(e['source']=='SENSOR' for e in s['ai']['logs'])
assert any(e['level']>=30 and '발견한 장애물' in e['message'] for e in s['ros_logs'])
print('PASS real ROS: unknown beyond range -> sensor discovery -> stop -> global detour -> arrival',flush=True)
control(operation='obstacle',obstacle=dict(operation='clear'))
req('/api/map',dict(expected_id=s['navigation']['id'],map=dict(center_bounds=[0,0,8,8],walls=[])))
wait(lambda s:s['navigation']['center_bounds']==[0,0,8,8])
control(operation='obstacle',obstacle=dict(operation='add',x=2,y=0))
control(operation='start',destination='warehouse',mode='global')
s=wait(lambda s:s['realtime'].get('local_avoids',0)>0)
assert s['realtime']['replans']==1
s=wait(lambda s:s['realtime']['phase']=='ARRIVED')
assert s['realtime']['replans']==1
print('PASS real ROS: local detour -> original route -> arrival, no global replan',flush=True)
control(operation='obstacle',obstacle=dict(operation='clear'))
control(operation='obstacle',obstacle=dict(operation='add',x=1,y=0,mode='patrol',a=[1,0],b=[1,2],speed=.2))
control(operation='start',destination='line_a',mode='global')
s=wait(lambda s:s['realtime']['phase']=='YIELDING');assert s['realtime']['actual_speed_mps']==0
s=wait(lambda s:s['realtime']['phase']=='MOVING')
control(operation='stop');s=wait(lambda s:not s['realtime']['active']);p=[s['robot']['x'],s['robot']['y']];time.sleep(.3);s=req();assert [s['robot']['x'],s['robot']['y']]==p
print('PASS real ROS: moving obstacle yield -> clear -> resume -> user stop holds',flush=True)
