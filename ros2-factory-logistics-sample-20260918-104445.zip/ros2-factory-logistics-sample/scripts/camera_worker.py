#!/usr/bin/env python3
"""Camera-only ROS perception worker. Model receives RGB, never scene objects."""
import argparse,base64,fcntl,io,json,os,time,urllib.request,urllib.error
from pathlib import Path

HOST_HEADER=None

def api(base,path,payload):
    request=urllib.request.Request(base+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-Factory-Control':'1',**({'Host':HOST_HEADER} if HOST_HEADER else {})})
    with urllib.request.urlopen(request,timeout=6) as response:return json.load(response)

def main():
    global HOST_HEADER
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--base',default='http://localhost:8765');p.add_argument('--runtime',required=True);p.add_argument('--host-header');a=p.parse_args();HOST_HEADER=a.host_header
    runtime=Path(a.runtime);runtime.mkdir(parents=True,exist_ok=True)
    lock=(runtime/'camera-worker.lock').open('w')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:print('Camera worker already running',flush=True);return
    config=runtime/'settings';config.mkdir(exist_ok=True);os.environ['YOLO_CONFIG_DIR']=str(config)
    import torch
    from PIL import Image
    from ultralytics import YOLO
    torch.set_num_threads(2);model=YOLO(a.model)
    if model.names!={0:'obstacle'}:raise RuntimeError('Camera driving requires the single-class obstacle model')
    model.predict(Image.new('RGB',(640,360)),imgsz=416,device='cpu',verbose=False)
    print('Camera-only worker ready: '+a.model,flush=True)
    last_error=0.;count=0
    while True:
        try:
            cycle=time.perf_counter()
            job=api(a.base,'/api/vision/claim',{})
            if not job.get('id'):time.sleep(.1);continue
            rgb=Image.open(io.BytesIO(base64.b64decode(job['image']))).convert('RGB')
            before=time.perf_counter();result=model.predict(rgb,imgsz=416,device='cpu',conf=.35,max_det=30,verbose=False)[0]
            boxes=[dict(xyxy=[max(0,round(v,2)) for v in box.xyxy[0].tolist()],label='obstacle',class_id=0,confidence=round(box.conf.item(),4)) for box in result.boxes]
            elapsed=round((time.perf_counter()-before)*1000,1)
            api(a.base,'/api/vision/result',dict(id=job['id'],detections=boxes,model='YOLO26n · warehouse-obstacle',inference_ms=elapsed))
            count+=1
            (runtime/'camera-worker-status.json').write_text(json.dumps(dict(at=time.time(),frames=count,inference_ms=elapsed,cycle_ms=round((time.perf_counter()-cycle)*1000,1),detections=len(boxes))))
            if count%40==1:print(f'frame {count}: {len(boxes)} obstacles, {elapsed}ms',flush=True)
            time.sleep(.05)
        except Exception as exc:
            if time.monotonic()-last_error>5:
                detail=exc.read().decode() if isinstance(exc,urllib.error.HTTPError) else str(exc)
                print(type(exc).__name__+': '+detail[:240],flush=True);last_error=time.monotonic()
            time.sleep(.4)
if __name__=='__main__':main()
