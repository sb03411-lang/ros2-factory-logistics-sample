"""Fixed confidence/IoU held-out evaluation, separate from training validation."""
import argparse,json,time,os
from pathlib import Path

def iou(a,b):
    i=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    return i/max(1e-9,(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-i)

def evaluate(model_path,root,out,imgsz=640):
    config=root/'settings';config.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('YOLO_CONFIG_DIR',str(config.resolve()))
    import torch
    from ultralytics import YOLO
    torch.set_num_threads(2);model=YOLO(model_path)
    import yaml
    names=yaml.safe_load((root/'data.yaml').read_text())['names']
    names=list(names.values()) if isinstance(names,dict) else names
    counts={k:dict(tp=0,fp=0,fn=0) for k in names};results=[]
    for image in sorted((root/'test/images').glob('*.jpg')):
        truth=[]
        for line in (root/'test/labels'/(image.stem+'.txt')).read_text().splitlines():
            cl,x,y,w,h=map(float,line.split());truth.append(dict(label=names[int(cl)],box=[(x-w/2)*640,(y-h/2)*360,(x+w/2)*640,(y+h/2)*360]))
        predictions=model.predict(str(image),conf=.35,imgsz=imgsz,device='cpu',verbose=False)[0]
        used=set();det=[]
        for box in predictions.boxes:
            name=predictions.names[int(box.cls.item())];rect=box.xyxy[0].tolist();confidence=box.conf.item();det.append(dict(label=name,confidence=confidence,xyxy=rect))
            if name not in counts:continue
            candidates=[(iou(rect,t['box']),i) for i,t in enumerate(truth) if t['label']==name and i not in used]
            score,index=max(candidates,default=(0,None))
            if score>=.5:counts[name]['tp']+=1;used.add(index)
            else:counts[name]['fp']+=1
        for i,t in enumerate(truth):
            if i not in used:counts[t['label']]['fn']+=1
        results.append(dict(image=image.name,detections=det,truth=truth))
    for c in counts.values():
        c['precision']=c['tp']/max(1,c['tp']+c['fp']);c['recall']=c['tp']/max(1,c['tp']+c['fn'])
    data=dict(model=model_path,confidence=.35,iou=.5,test_images=len(results),counts=counts,results=results)
    Path(out).write_text(json.dumps(data,indent=2));print(json.dumps(counts),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--data',required=True);p.add_argument('--out',required=True);p.add_argument('--imgsz',type=int,default=640);a=p.parse_args();evaluate(a.model,Path(a.data),a.out,a.imgsz)
