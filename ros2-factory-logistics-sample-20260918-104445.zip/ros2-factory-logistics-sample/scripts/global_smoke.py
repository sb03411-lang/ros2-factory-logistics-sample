"""Isolated HTTP/ROS global navigation regression (default port 8766)."""
import json, math, sys, time, urllib.request
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://localhost:8766'
def request(path='/api/state',data=None):
    req=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Host':'localhost:8765','Content-Type':'application/json','X-Factory-Control':'1'})
    return json.load(urllib.request.urlopen(req,timeout=5))
def control(**payload):return request('/api/realtime/control',payload)
def wait(predicate,timeout=35):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        s=request()
        if predicate(s):return s
        time.sleep(.1)
    raise AssertionError('timed out: '+str(s.get('realtime')))
wait(lambda s:s['connected'])
control(operation='start',destination='line_a',mode='global',speed=.5)
wait(lambda s:s['robot']['x']>.3)
control(operation='obstacle',obstacle=dict(operation='add',x=1,y=0))
s=wait(lambda s:s['realtime']['replans']>=2)
assert any(p[1]>1.8 for p in s['realtime']['route']),s
start=time.monotonic();samples=[]
while time.monotonic()-start<35:
    s=request();r=s['robot'];samples.append([r['x'],r['y']])
    assert 0<=r['x']<=3 and 0<=r['y']<=2
    assert math.dist([r['x'],r['y']],[1,0])>.22
    if not s['realtime']['active']:break
    time.sleep(.1)
assert s['realtime']['phase']=='ARRIVED',s['realtime']
assert any(l['level']>=30 and '경로 막힘' in l['message'] for l in s['ros_logs'])
print(json.dumps(dict(result='PASS',scenario='live blocker -> stop -> global detour -> arrival without LLM',elapsed_after_replan=round(time.monotonic()-start,2),replans=s['realtime']['replans'],planning_ms=s['realtime']['planning_ms'],samples=len(samples)),ensure_ascii=False))
control(operation='start',destination='warehouse',mode='global')
wait(lambda s:s['realtime']['active'])
control(operation='stop');s=wait(lambda s:not s['realtime']['active']);pose=(s['robot']['x'],s['robot']['y']);time.sleep(.5);s=request();assert pose==(s['robot']['x'],s['robot']['y'])
print('PASS stop holds position; ROS WARN logs preserved')
