"""Check real ROS trajectories and held manual wall commands through HTTP."""
import json
import sys
import time
from pathlib import Path
from web_smoke import request, wait_for
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'))
from factory_logistics.navigation import NavigationMap


def main():
    nav = NavigationMap()
    assert not nav.segment_free((0,0),(3,2))
    prefix = 'NAV-' + str(time.time_ns())
    trace = []
    for index, target in enumerate(('warehouse','line_b','warehouse')):
        wait_for(lambda s: s['can_submit'])
        request('/api/jobs', {'job_id': prefix+str(index), 'destination': target}, 202)
        end = time.monotonic()+15
        previous = None
        observed = []
        while time.monotonic()<end:
            state = request('/api/state')
            robot = state['robot']
            if robot['job_id'] == prefix+str(index):
                point = (robot['x'],robot['y'])
                assert nav.point_free(point), robot
                # Sampling may skip a waypoint, so validate actual remaining route as well.
                assert all(nav.segment_free(a,b) for a,b in zip(robot['path'],robot['path'][1:])), robot
                observed.append(point)
                if robot['state']=='SUCCEEDED':
                    break
            time.sleep(.035)
        else:
            raise AssertionError('Navigation did not complete')
        assert observed
        if target=='line_b':
            assert any(x>2.82 and y<.3 or x<.18 and y>1.82 for x,y in observed), observed
        trace.append({'target':target,'poses':observed})
    print('PASS real warehouse -> line_b -> warehouse paths detour around wall', flush=True)
    # Move diagonally toward the inner wall from the warehouse for longer than contact time.
    blocked = False
    for _ in range(22):
        request('/api/teleop',{'x':1,'y':1,'issued_at':time.time()},202)
        time.sleep(.09)
        state = request('/api/state')['robot']
        assert nav.point_free((state['x'],state['y']))
        blocked = blocked or state['collision_blocked']
    assert blocked
    assert state['x'] < .18 and state['y'] < .18, state
    request('/api/teleop',{'x':0,'y':0,'issued_at':time.time()},202)
    wait_for(lambda s: s['robot']['state']=='IDLE')
    Path('docs/evidence/navigation-trace.json').write_text(json.dumps(trace,indent=2))
    print('PASS held diagonal manual input blocked at inflated wall, no penetration', flush=True)
    print('NAVIGATION / COLLISION CHECKS PASSED', flush=True)


if __name__=='__main__':
    main()
