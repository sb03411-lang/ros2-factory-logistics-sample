#!/usr/bin/env python3
"""Preview the transport core with deterministic time steps, without ROS."""

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src" / "factory_logistics"))

from factory_logistics.core import TransportCore  # noqa: E402
from factory_logistics.navigation import NavigationMap


def main() -> None:
    print("ROS 미사용: 이동 코어 미리보기")
    print("위치 단위: m | 시간: 시뮬레이션 초 | 실제 ROS Action 통신은 수행하지 않습니다.")
    core = TransportCore(speed=1.0, navigation=NavigationMap())
    elapsed = 0.0
    for job_id, destination in (("JOB-001", "line_a"), ("JOB-002", "warehouse")):
        core.start(job_id, destination)
        print("접수: {} → {}".format(job_id, destination))
        while core.busy:
            core.step(0.5)
            elapsed += 0.5
            status = core.snapshot()
            print(
                "t={:4.1f}s {} {:9s} 위치=({:.1f}, {:.1f}) 남은 거리={:.1f}".format(
                    elapsed,
                    status["job_id"],
                    status["state"],
                    status["x"],
                    status["y"],
                    status["remaining_distance"],
                )
            )
        assert core.snapshot()["state"] == "SUCCEEDED"
    final = core.snapshot()
    assert (final["x"], final["y"]) == (0.0, 0.0)
    print("완료: 두 작업 성공, warehouse 복귀 확인.")


if __name__ == "__main__":
    main()
