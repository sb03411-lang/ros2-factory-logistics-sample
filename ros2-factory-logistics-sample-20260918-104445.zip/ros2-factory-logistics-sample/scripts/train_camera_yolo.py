#!/usr/bin/env python3
"""Generate visible-pixel training labels offline; train actual RGB detector."""
import argparse,sys,random,math,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.camera import render_camera
from PIL import Image,ImageEnhance,ImageFilter
import io

def generate(root):
    rng=random.Random(71633)
    for split,count in [('train',180),('val',40),('test',40)]:
        for folder in ['images','labels']:(root/split/folder).mkdir(parents=True,exist_ok=True)
        for n in range(count):
            if (root/split/'images'/f'{n:04d}.jpg').exists():continue
            yaw=rng.uniform(-math.pi,math.pi);pose=[4,4]
            walls=[]
            # Random shelves outside the camera's near corridor, varied map layout.
            for _ in range(rng.randint(0,9)):
                x,y=rng.uniform(.3,7),rng.uniform(.3,7)
                if math.dist((x,y),pose)>2.5:walls.append([x,y,x+rng.uniform(.3,.8),y+rng.uniform(.4,1)])
            nav=NavigationMap(dict(id='training',resolution=.1,robot_radius=.25,center_bounds=[0,0,8,8],outer_bounds=[-.4,-.4,8.4,8.4],walls=walls))
            objects=[]
            for i in range(rng.randint(0,4)):
                distance=rng.uniform(.65,4.2);angle=yaw+rng.uniform(-.85,.85);kind=rng.choice(['person','person','obstacle']);x=4+math.cos(angle)*distance;y=4+math.sin(angle)*distance
                objects.append(dict(id=str(i),x=x,y=y,radius=.22 if kind=='person' else rng.uniform(.08,.25),kind=kind,walk_phase=rng.uniform(0,6.28)))
            png,boxes=render_camera(nav,dict(pose=pose,yaw=yaw,obstacles=objects),annotations=True)
            image=Image.open(io.BytesIO(png)).convert('RGB')
            if split=='train':
                image=ImageEnhance.Brightness(image).enhance(rng.uniform(.7,1.3));image=ImageEnhance.Color(image).enhance(rng.uniform(.65,1.2))
                if rng.random()<.2:image=image.filter(ImageFilter.GaussianBlur(.4))
            image.save(root/split/'images'/f'{n:04d}.jpg',quality=90)
            lines=[]
            for b in boxes:
                x,y,x2,y2=b['xyxy'];lines.append(f"{0 if b['kind']=='person' else 1} {(x+x2)/1280} {(y+y2)/720} {(x2-x)/640} {(y2-y)/360}")
            (root/split/'labels'/f'{n:04d}.txt').write_text('\n'.join(lines))
            if n%20==0:print(split,n,flush=True)
    (root/'data.yaml').write_text(f'path: {root.resolve()}\ntrain: train/images\nval: val/images\ntest: test/images\nnames:\n  0: person\n  1: obstacle\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--model',required=True);p.add_argument('--epochs',type=int,default=30);a=p.parse_args()
    root=Path(a.data);generate(root)
    import torch
    from ultralytics import YOLO
    torch.set_num_threads(4)
    model=YOLO(a.model)
    model.train(data=str(root/'data.yaml'),epochs=a.epochs,imgsz=416,batch=12,device='mps' if torch.backends.mps.is_available() else 'cpu',workers=0,project=str(root/'runs'),name='camera',exist_ok=True,patience=10,plots=False,amp=False,cache=True,seed=42,fliplr=.5,mosaic=.4,close_mosaic=5)
    result=YOLO(str(root/'runs/camera/weights/best.pt')).val(data=str(root/'data.yaml'),split='test',imgsz=640,device='cpu',workers=0,plots=False)
    (root/'heldout-metrics.json').write_text(json.dumps(result.results_dict,indent=2))
