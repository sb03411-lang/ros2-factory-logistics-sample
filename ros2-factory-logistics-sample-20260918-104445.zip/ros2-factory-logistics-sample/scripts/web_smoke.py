#!/usr/bin/env python3
"""Exercise the running local web -> ROS stack. Moves the simulated robot."""
import json
import time
import urllib.error
import urllib.request

BASE = 'http://localhost:8765'


def request(path, payload=None, expected=200, headers=None):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(BASE + path, data=data, headers=headers or {
        'Content-Type': 'application/json', 'X-Factory-Control': '1'})
    try:
        response = urllib.request.urlopen(req, timeout=8)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        result = json.load(response)
        assert response.status == expected, (response.status, expected, result)
        return result


def wait_for(predicate, timeout=12):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        state = request('/api/state')
        if predicate(state):
            return state
        time.sleep(.08)
    raise AssertionError('State condition timed out: {}'.format(state))


def main():
    state = wait_for(lambda s: s['connected'])
    assert state['can_submit'], 'Finish the current job before running this test.'
    prefix = 'HTTP-' + str(time.time_ns())
    request('/api/jobs', {'job_id': prefix, 'destination': 'unknown'}, 400)
    request('/api/jobs', {'job_id': prefix, 'destination': 'line_b'}, 403,
            {'Content-Type': 'application/json', 'Origin': 'http://example.com', 'X-Factory-Control': '1'})
    request('/api/jobs', {'job_id': prefix, 'destination': 'line_b'}, 403,
            {'Content-Type': 'application/json'})
    print('PASS invalid destination and foreign/missing control header rejected')
    # Start from a known station to make movement/cancellation checks meaningful.
    request('/api/jobs', {'job_id': prefix + '-HOME', 'destination': 'warehouse'}, 202)
    wait_for(lambda s: s['robot']['job_id'] == prefix + '-HOME' and s['robot']['state'] == 'SUCCEEDED')
    job_id = prefix + '-MOVE'
    request('/api/jobs', {'job_id': job_id, 'destination': 'line_b'}, 202)
    moving = wait_for(lambda s: s['can_cancel'] and s['robot']['x'] > .1)
    assert 0 < moving['robot']['remaining_distance'] < 6.0
    assert len(moving['robot']['path']) >= 2
    request('/api/jobs', {'job_id': prefix + '-BUSY', 'destination': 'line_a'}, 409)
    request('/api/cancel', {'job_id': 'wrong-job'}, 409)
    request('/api/cancel', {'job_id': job_id}, 202)
    stopped = wait_for(lambda s: s['robot']['state'] == 'CANCELED')
    time.sleep(.4)
    later = request('/api/state')
    assert (stopped['robot']['x'], stopped['robot']['y']) == (later['robot']['x'], later['robot']['y'])
    print('PASS real motion, busy rejection, exact-goal cancel, no motion after cancellation')
    request('/api/jobs', {'job_id': job_id, 'destination': 'line_b'}, 409)
    final_id = prefix + '-DONE'
    request('/api/jobs', {'job_id': final_id, 'destination': 'line_a'}, 202)
    final = wait_for(lambda s: s['robot']['job_id'] == final_id and s['robot']['state'] == 'SUCCEEDED')
    assert final['robot']['x'] == 3 and final['robot']['y'] == 0
    assert any(j['job_id'] == job_id and j['state'] == 'CANCELED' for j in final['jobs'])
    print('PASS duplicate rejection, follow-up completion, actual pose, retained history')
    print('WEB / ROS INTEGRATION PASSED')


if __name__ == '__main__':
    main()
