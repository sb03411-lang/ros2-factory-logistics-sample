#!/usr/bin/env python3
"""Observe an already-started real Codex loop and validate its live trajectory."""
import json
import math
import time
import urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
records=[];last_cycle=-1;started=time.monotonic();previous_thinking=None
while time.monotonic()-started<360:
    state=json.load(urllib.request.urlopen('http://localhost:8765/api/state',timeout=5))
    rt=state['realtime'];robot=state['robot'];pose=[robot['x'],robot['y']]
    if rt['phase']=='THINKING':
        key=rt['observation']['id']
        if previous_thinking and previous_thinking[0]==key:assert math.dist(previous_thinking[1],pose)<1e-6,'movement while thinking'
        previous_thinking=(key,pose)
    else:previous_thinking=None
    for o in state['obstacles']:
        assert math.dist(pose,[o['x'],o['y']])>o['radius']+.12,('collision',pose,o)
    if rt['cycle']!=last_cycle:
        last_cycle=rt['cycle'];print('observation',last_cycle,'pose',pose,'phase',rt['phase'],flush=True)
    records.append(dict(phase=rt['phase'],cycle=rt['cycle'],pose=pose,obstacles=state['obstacles']))
    if not rt['active']:
        print('terminal',rt['phase'],rt['message'],flush=True)
        break
    time.sleep(.15)
else:raise AssertionError('real Codex loop did not finish within six minutes')
(ROOT/'docs/evidence/realtime-trace.json').write_text(json.dumps(records,ensure_ascii=False))
(ROOT/'docs/evidence/realtime-decisions.json').write_text(json.dumps(state['ai']['logs'],ensure_ascii=False,indent=2))
assert rt['phase']=='ARRIVED',rt
assert rt['cycle']>=2
assert any(o for entry in records for o in entry['obstacles'])
assert any(row['source']=='LLM' and row['request_id']==rt['session'] for row in state['ai']['logs'])
print('PASS actual repeated Codex observation/actions, stationary while thinking, dynamic collision clearance, goal arrival')
