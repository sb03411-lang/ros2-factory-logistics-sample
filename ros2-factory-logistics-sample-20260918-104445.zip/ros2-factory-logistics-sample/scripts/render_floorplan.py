#!/usr/bin/env python3
"""Regenerate the bundled default map using the same renderer as the ROS server."""
import json
import sys
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'
sys.path.insert(0, str(root))
from factory_logistics.map_store import validate_map
from factory_logistics.floorplan import render_floorplan
package = root / 'factory_logistics'
nav = validate_map(json.loads((package/'navigation_map.json').read_text()))
positions = json.loads((package/'stations.json').read_text())
stations = [dict(id=key,x=value[0],y=value[1]) for key,value in positions.items()]
(package/'web'/'floorplan.png').write_bytes(render_floorplan(nav,stations))
print('Generated default floorplan.png; runtime maps are rendered on each apply.')
