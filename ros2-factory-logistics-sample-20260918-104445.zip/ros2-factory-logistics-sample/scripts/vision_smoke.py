"""Uses authenticated Codex and moves the simulated robot. No mock AI results."""
import json
import time
from pathlib import Path
from web_smoke import request, wait_for


def main():
    wait_for(lambda s: s['connected'] and s['ai']['worker_connected'], timeout=20)
    plan = request('/api/ai/request', {'prompt': '도면에서 생산라인 B를 찾아 이동해 줘'}, 202)
    state = wait_for(lambda s: s['ai']['plan']['state'] not in ('QUEUED', 'READING'), timeout=200)
    interpreted = state['ai']['plan']
    assert interpreted['state'] == 'READY', interpreted
    assert interpreted['result']['destination'] == 'line_b', interpreted
    assert (interpreted['result']['x'], interpreted['result']['y']) == (3, 2)
    print('PASS actual Codex image input -> LINE B -> validated (3.0, 2.0)m', flush=True)
    request('/api/ai/execute', {'id': plan['id']}, 202)
    request('/api/ai/execute', {'id': plan['id']}, 409)
    arrived = wait_for(lambda s: s['ai']['plan']['state'] == 'SUCCEEDED')
    assert (arrived['robot']['x'], arrived['robot']['y']) == (3, 2)
    assert any(j['job_id'] == plan['id'] and j['source'] == 'CODEX' for j in arrived['jobs'])
    Path('docs/evidence/codex-vision-result.json').write_text(json.dumps(interpreted, ensure_ascii=False, indent=2))
    print('PASS validated target -> real ROS action -> final position and Codex job history', flush=True)
    request('/api/ai/request', {'prompt': '도면에 없는 출하장 Z로 이동해 줘'}, 202)
    unclear = wait_for(lambda s: s['ai']['plan']['state'] not in ('QUEUED', 'READING'), timeout=200)
    assert unclear['ai']['plan']['state'] == 'CLARIFY', unclear['ai']['plan']
    request('/api/ai/execute', {'id': unclear['ai']['plan']['id']}, 409)
    assert (unclear['robot']['x'], unclear['robot']['y']) == (3, 2)
    print('PASS unknown drawing target requests clarification and cannot execute', flush=True)
    print('CODEX VISION / ROS CHECKS PASSED', flush=True)


if __name__ == '__main__':
    main()
