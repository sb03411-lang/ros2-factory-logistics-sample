"""Isolated ROS validation for larger footprint and random walking people."""
import json,math,time,urllib.request,sys
BASE='http://localhost:8766'
def req(path='/api/state',data=None):
 return json.load(urllib.request.urlopen(urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers={'Host':'localhost:8765','Content-Type':'application/json','X-Factory-Control':'1'}),timeout=8))
def control(**data):return req('/api/realtime/control',data)
def wait(fn):
 for _ in range(100):
  s=req()
  if fn(s):return s
  time.sleep(.1)
 raise AssertionError(s['realtime'])
s=wait(lambda s:s['connected']);m=json.load(open(sys.argv[1]));req('/api/map',dict(expected_id=s['navigation']['id'],map=m));s=wait(lambda s:s['navigation']['robot_radius']==.25)
control(operation='obstacle',obstacle=dict(operation='people',count=4));s=wait(lambda s:len(s['obstacles'])==4)
start={o['id']:[o['x'],o['y']] for o in s['obstacles']};headings=set();paused=False
control(operation='start',destination='line_b',mode='global')
for _ in range(80):
 s=req();p=[s['robot']['x'],s['robot']['y']]
 for o in s['obstacles']:
  assert o['kind']=='person' and o['mode']=='wander'
  assert math.dist(p,[o['x'],o['y']])>.35+o['radius']
  for other in s['obstacles']:
   if o['id']!=other['id']:assert math.dist([o['x'],o['y']],[other['x'],other['y']])>o['radius']+other['radius']
  headings.add(round(o.get('walk_heading',0),2));paused|=o.get('walk_speed')==0
 time.sleep(.1)
control(operation='stop')
assert len(headings)>6
assert sum(math.dist(start[o['id']],[o['x'],o['y']])>.1 for o in s['obstacles'])>=3
print(json.dumps(dict(result='PASS',people=4,distinct_headings=len(headings),pause_observed=paused,robot_pose=p,body_diameter=.5,effective_diameter=.7),ensure_ascii=False))
