import unittest,sys,math,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
try:
    from PIL import Image
    from factory_logistics.camera import render_camera,cast_ray
    PIL=True
except ImportError:PIL=False
from factory_logistics.map_store import validate_map
from factory_logistics.core import TransportCore
from factory_logistics.realtime_world import RealtimeWorld

def warehouse():
    return validate_map(dict(center_bounds=[0,0,8,8],walls=[[x,y,x+.8,y+1.4] for x in [1,3.6,6.2] for y in [1,3.4,5.8]],stations=dict(warehouse=[0,0],line_a=[7.6,.3],line_b=[7.6,7.6])))
class WarehouseTests(unittest.TestCase):
    def test_custom_goals_persist_and_reach(self):
        nav=warehouse();self.assertEqual(validate_map(nav.data).data,nav.data)
        core=TransportCore(navigation=nav);self.assertEqual(core._stations['line_b'],(7.6,7.6))
        world=RealtimeWorld(core);world.start('line_b','global')
        for _ in range(450):world.tick(.1)
        self.assertEqual(world.rt['phase'],'ARRIVED')
    def test_replace_map_updates_goals(self):
        c=TransportCore(navigation=warehouse());from factory_logistics.navigation import NavigationMap
        c.replace_navigation(NavigationMap());self.assertEqual(c._stations['line_b'],(3,2))
    def test_invalid_station_rejected(self):
        d=warehouse().data;d['stations']['line_b']=[1.2,1.2]
        with self.assertRaises(ValueError):validate_map(d)
    @unittest.skipUnless(PIL,'Pillow required')
    def test_shelf_occludes_hidden_obstacle(self):
        hit=cast_ray([0,1.5],[1,0],[[1,1,2,2]],[dict(x=3,y=1.5,radius=.2)],[-.3,-.3,8.3,8.3])
        self.assertEqual(hit[1],'rack')
        nav=warehouse();scene=dict(pose=[.1,1.5],yaw=0,obstacles=[])
        a=render_camera(nav,scene);scene['obstacles']=[dict(x=2.5,y=1.5,radius=.1)]
        self.assertEqual(a,render_camera(nav,scene))
    @unittest.skipUnless(PIL,'Pillow required')
    def test_camera_direction_and_visible_obstacle(self):
        nav=warehouse();scene=dict(pose=[2.6,.6],yaw=math.pi/2,obstacles=[])
        a=render_camera(nav,scene);scene['yaw']=0;b=render_camera(nav,scene)
        self.assertNotEqual(a,b);self.assertEqual(Image.open(io.BytesIO(a)).size,(640,360))
        scene['obstacles']=[dict(x=3,y=.6,radius=.12)]
        self.assertNotEqual(b,render_camera(nav,scene))
    def test_observation_is_first_person(self):
        w=RealtimeWorld(TransportCore(navigation=warehouse()));w.start('line_b','global');o=w.observe()
        self.assertEqual(o['camera']['type'],'synthetic_first_person');self.assertIn('yaw',o)
