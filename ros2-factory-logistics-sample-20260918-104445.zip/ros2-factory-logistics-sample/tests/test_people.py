import unittest,sys,math,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.map_store import validate_map
from factory_logistics.core import TransportCore
from factory_logistics.realtime_world import RealtimeWorld,LiveNavigation

def large_map():return validate_map(dict(center_bounds=[0,0,8,8],walls=[[x,y,x+.8,y+1.4] for x in [1,3.6,6.2] for y in [1,3.4,5.8]],robot_radius=.25,robot_clearance=.1,stations=dict(warehouse=[0,0],line_a=[7.6,.3],line_b=[7.6,7.6])))
class PeopleTests(unittest.TestCase):
    def test_body_and_clearance_preserved(self):
        nav=large_map();self.assertAlmostEqual(nav.radius,.35);self.assertEqual(nav.body_radius,.25)
        self.assertEqual(validate_map(nav.data).data,nav.data)
        for p in nav.data['stations'].values():self.assertTrue(nav.plan([0,0],p))
    def test_gap_passed_by_old_robot_blocked_by_new_robot(self):
        data=dict(id='gap',resolution=.1,robot_radius=.12,center_bounds=[0,0,3,2],outer_bounds=[-.5,-.5,3.5,2.5],walls=[[1,0,2,.7],[1,1.3,2,2]])
        self.assertTrue(NavigationMap(data).segment_free([0,1],[3,1]))
        data.update(robot_radius=.25,robot_clearance=.1)
        self.assertFalse(NavigationMap(data).segment_free([0,1],[3,1]))
    def test_dynamic_gap_blocked_too(self):
        n=large_map();obs={'a':dict(x=2.7,y=2.7,radius=.1),'b':dict(x=2.7,y=3.3,radius=.1)}
        self.assertFalse(LiveNavigation(n,obs).segment_free([2,3],[3.1,3]))
    def test_four_people_change_direction_pause_and_never_overlap(self):
        w=RealtimeWorld(TransportCore(navigation=large_map()));w.rng=random.Random(41);w.obstacle(dict(operation='people',count=4))
        self.assertEqual(len(w.obstacles),4);start={k:(o['x'],o['y']) for k,o in w.obstacles.items()};headings=set();paused=False
        for _ in range(600):
            w.tick(.1)
            for o in w.obstacles.values():
                self.assertEqual(o['kind'],'person');self.assertTrue(w.free_obstacle(o,(o['x'],o['y']),(o['x'],o['y'])))
                headings.add(round(o.get('walk_heading',0),2));paused|=o.get('walk_speed')==0
        self.assertGreater(len(headings),12);self.assertTrue(paused)
        self.assertTrue(all(math.dist(start[k],(o['x'],o['y']))>.1 for k,o in w.obstacles.items()))
    def test_capacity_rejection_is_atomic(self):
        w=RealtimeWorld(TransportCore(navigation=large_map()));w.obstacle(dict(operation='people',count=6));ids=set(w.obstacles)
        with self.assertRaises(ValueError):w.obstacle(dict(operation='people',count=4))
        self.assertEqual(set(w.obstacles),ids)
    def test_robot_driving_preserves_clearance_to_wandering_people(self):
        now=[0.];w=RealtimeWorld(TransportCore(navigation=large_map()),lambda:now[0]);w.rng=random.Random(17)
        w.obstacle(dict(operation='people',count=4));w.start('line_b','global')
        for _ in range(500):
            now[0]+=.1;w.tick(.1)
            self.assertTrue(w.core.navigation.point_free(w.pose()))
            for o in w.obstacles.values():self.assertGreater(math.dist(w.pose(),(o['x'],o['y'])),o['radius']+.35)
    def test_invalid_sizes_rejected(self):
        for radius,clearance in [(0,0),(.25,-.1),(.25,float('nan')),(True,0)]:
            with self.assertRaises(ValueError):validate_map(dict(center_bounds=[0,0,8,8],walls=[],robot_radius=radius,robot_clearance=clearance))
