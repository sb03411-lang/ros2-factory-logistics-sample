"""Behavioral checks runnable with Python's standard-library unittest runner."""

import math
import sys
import unittest
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src" / "factory_logistics"))

from factory_logistics.core import TransportCore  # noqa: E402


class TransportCoreTests(unittest.TestCase):
    def test_default_initial_pose_and_detached_snapshot(self):
        core = TransportCore()
        state = core.snapshot()
        self.assertEqual(
            set(state),
            {"job_id", "destination", "state", "x", "y", "remaining_distance", "message"},
        )
        self.assertEqual((state["x"], state["y"]), (0.0, 0.0))
        self.assertEqual(state["state"], "IDLE")
        self.assertEqual(state["job_id"], "")
        self.assertFalse(core.busy)
        state["state"] = "RUNNING"
        self.assertFalse(core.busy)

    def test_sequential_delivery_and_return(self):
        core = TransportCore()
        core.start("JOB-001", "line_a")
        core.step(1.0)
        moving = core.snapshot()
        self.assertEqual(moving["state"], "RUNNING")
        self.assertEqual((moving["x"], moving["y"]), (1.0, 0.0))
        self.assertEqual(moving["remaining_distance"], 2.0)
        core.step(2.0)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")
        core.start("JOB-002", "warehouse")
        core.step(3.0)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")
        self.assertEqual((core.snapshot()["x"], core.snapshot()["y"]), (0.0, 0.0))

    def test_diagonal_speed_and_no_overshoot(self):
        core = TransportCore(stations={"warehouse": [0, 0], "target": [3, 4]}, speed=2)
        core.start("diagonal", "target")
        core.step(1.0)
        state = core.snapshot()
        self.assertAlmostEqual(state["x"], 1.2)
        self.assertAlmostEqual(state["y"], 1.6)
        self.assertAlmostEqual(state["remaining_distance"], 3.0)
        core.step(100)
        final = core.snapshot()
        self.assertEqual((final["x"], final["y"]), (3.0, 4.0))
        self.assertEqual(final["remaining_distance"], 0.0)
        self.assertEqual(final["state"], "SUCCEEDED")
        core.step(100)
        self.assertEqual(core.snapshot(), final)

    def test_same_station_requires_positive_step(self):
        core = TransportCore()
        core.start("already-there", "warehouse")
        accepted = core.snapshot()
        self.assertTrue(core.busy)
        core.step(0)
        self.assertEqual(core.snapshot(), accepted)
        core.step(0.1)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")

    def test_invalid_requests_do_not_change_state_or_reserve_id(self):
        core = TransportCore()
        initial = core.snapshot()
        invalid_requests = [
            ("", "line_a"), ("   ", "line_a"), (" job", "line_a"),
            ("job ", "line_a"), (None, "line_a"), (1, "line_a"),
            ("valid", "missing"), ("valid", " line_a"), ("valid", None),
        ]
        for request in invalid_requests:
            with self.subTest(request=request):
                with self.assertRaises(ValueError):
                    core.start(*request)
                self.assertEqual(core.snapshot(), initial)
        core.start("valid", "line_a")
        self.assertTrue(core.busy)

    def test_busy_rejection_preserves_running_job_and_rejected_id(self):
        core = TransportCore()
        core.start("first", "line_a")
        core.step(1)
        moving = core.snapshot()
        with self.assertRaises(ValueError):
            core.start("second", "warehouse")
        self.assertEqual(core.snapshot(), moving)
        core.step(2)
        core.start("second", "warehouse")
        self.assertEqual(core.snapshot()["job_id"], "second")

    def test_cancel_retains_pose_and_allows_new_job(self):
        core = TransportCore()
        self.assertFalse(core.cancel())
        core.start("outbound", "line_a")
        core.step(1.25)
        self.assertTrue(core.cancel())
        canceled = core.snapshot()
        self.assertEqual(canceled["state"], "CANCELED")
        self.assertEqual(canceled["x"], 1.25)
        self.assertEqual(canceled["remaining_distance"], 1.75)
        core.step(10)
        self.assertEqual(core.snapshot(), canceled)
        self.assertFalse(core.cancel())
        core.start("return", "warehouse")
        core.step(1.25)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")
        self.assertEqual(core.snapshot()["x"], 0.0)

    def test_failure_retains_pose_and_allows_recovery(self):
        core = TransportCore()
        idle = core.snapshot()
        core.fail("no job")
        self.assertEqual(core.snapshot(), idle)
        core.start("outbound", "line_b")
        core.step(0.5)
        moving = core.snapshot()
        core.fail("adapter timer error")
        failed = core.snapshot()
        self.assertEqual(failed["state"], "FAILED")
        self.assertEqual(failed["message"], "adapter timer error")
        self.assertEqual((failed["x"], failed["y"]), (moving["x"], moving["y"]))
        core.step(10)
        core.fail("late error")
        self.assertEqual(core.snapshot(), failed)
        core.start("recovery", "warehouse")
        core.step(10)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")

    def test_accepted_ids_cannot_be_reused_after_any_terminal_state(self):
        for terminal in ("SUCCEEDED", "CANCELED", "FAILED"):
            with self.subTest(terminal=terminal):
                core = TransportCore()
                core.start("same-id", "line_a")
                if terminal == "SUCCEEDED":
                    core.step(10)
                elif terminal == "CANCELED":
                    core.cancel()
                else:
                    core.fail("error")
                before = core.snapshot()
                with self.assertRaises(ValueError):
                    core.start("same-id", "warehouse")
                self.assertEqual(core.snapshot(), before)

    def test_invalid_time_step_leaves_active_job_unchanged(self):
        core = TransportCore()
        core.start("job", "line_a")
        before = core.snapshot()
        for dt in (-1, math.nan, math.inf, -math.inf, True, "1", None):
            with self.subTest(dt=dt):
                with self.assertRaises(ValueError):
                    core.step(dt)
                self.assertEqual(core.snapshot(), before)
        core.step(0.0)
        self.assertEqual(core.snapshot(), before)

    def test_invalid_speed_configuration(self):
        for speed in (0, -1, math.nan, math.inf, -math.inf, True, "1", None):
            with self.subTest(speed=speed):
                with self.assertRaises(ValueError):
                    TransportCore(speed=speed)

    def test_invalid_station_configuration(self):
        invalid_stations = [
            {}, [], {"line_a": [0, 0]}, {"warehouse": [0]},
            {"warehouse": "00"}, {"warehouse": [0, 0, 0]},
            {"warehouse": [math.nan, 0]}, {"warehouse": [0, math.inf]},
            {"warehouse": [True, 0]}, {"warehouse": ["0", 0]},
            {"warehouse": [0, 0], " bad": [1, 1]},
            {"warehouse": [-1e308, 0], "far": [1e308, 0]},
        ]
        for stations in invalid_stations:
            with self.subTest(stations=stations):
                with self.assertRaises(ValueError):
                    TransportCore(stations=stations)

    def test_configuration_is_copied_and_custom_warehouse_sets_initial_pose(self):
        config = {"warehouse": [4, 5], "target": [7, 5]}
        core = TransportCore(stations=config)
        self.assertEqual((core.snapshot()["x"], core.snapshot()["y"]), (4.0, 5.0))
        config["target"][0] = 100
        core.start("custom", "target")
        core.step(3)
        self.assertEqual(core.snapshot()["x"], 7.0)
        self.assertEqual(core.snapshot()["state"], "SUCCEEDED")


if __name__ == "__main__":
    unittest.main()
