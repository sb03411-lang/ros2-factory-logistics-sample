import sys, unittest, math, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.core import TransportCore
from factory_logistics.navigation import NavigationMap
from factory_logistics.realtime_world import RealtimeWorld

class GlobalTests(unittest.TestCase):
    def setUp(self):
        self.now=0
        self.core=TransportCore(navigation=NavigationMap())
        self.world=RealtimeWorld(self.core,lambda:self.now)
    def tick(self,n=1):
        for _ in range(n):
            self.now+=.1;self.world.tick(.1)
            self.assertTrue(self.core.navigation.point_free(self.world.pose()))
    def test_continuous_arrival_without_llm_and_pending_review(self):
        self.world.start('line_b','global')
        obs=self.world.observe()
        self.tick(20)
        self.assertGreater(math.dist(self.world.pose(),obs['pose']),.5)
        self.tick(180)
        self.assertEqual(self.world.rt['phase'],'ARRIVED')
    def test_replan_from_reported_pose_uses_upper_corridor(self):
        self.core.manual_step(.5,0,3.98)
        self.world.obstacle(dict(operation='add',x=2.337,y=0))
        self.world.start('line_a','global');self.tick(5)
        self.assertTrue(any(p[1]>1.8 for p in self.world.rt['route']))
        self.tick(250)
        self.assertEqual(self.world.rt['phase'],'ARRIVED')
    def test_new_blocker_stops_before_motion_then_replans(self):
        self.world.start('line_a','global');self.tick(10)
        self.world.obstacle(dict(operation='add',x=1,y=0))
        before=self.world.pose();self.tick()
        self.assertEqual(before,self.world.pose())
        self.assertEqual(self.world.rt['phase'],'ASSESSING');self.tick(4)
        self.assertEqual(self.world.rt['replans'],2)
        self.assertTrue(any(p[1]>1.8 for p in self.world.rt['route']))
        self.tick(220);self.assertEqual(self.world.rt['phase'],'ARRIVED')
    def test_no_route_waits_then_recovers(self):
        self.world.obstacle(dict(operation='add',x=1,y=0))
        self.world.obstacle(dict(operation='add',x=0,y=1))
        self.world.start('line_a','global');self.tick(20)
        self.assertEqual(self.world.rt['phase'],'WAITING');self.assertEqual(self.world.pose(),[0,0])
        self.world.obstacle(dict(operation='clear'));self.tick(100)
        self.assertEqual(self.world.rt['phase'],'ARRIVED')
    def test_advisory_never_overrides_route_and_late_result_rejected(self):
        self.world.start('line_a','global');obs=self.world.observe();self.tick(10)
        self.world.action(dict(session=obs['session'],observation_id=obs['id'],action=dict(action='move',x=2,y=-1,explanation='invalid suggestion')))
        self.assertEqual(self.world.rt['phase'],'MOVING')
        self.world.stop()
        with self.assertRaises(ValueError):self.world.action(dict(session=obs['session'],observation_id=obs['id']))
    def test_speed_validation_and_distance(self):
        with self.assertRaises(ValueError):self.world.start('line_a','global',2)
        self.world.start('line_a','global',.5);self.tick(10)
        self.assertAlmostEqual(self.world.pose()[0],.5)
    def test_review_timeout_does_not_stop_motion(self):
        self.world.start('line_b','global');self.world.observe();self.now=36;self.tick()
        self.assertFalse(self.world.rt['review_pending']);self.assertEqual(self.world.rt['phase'],'MOVING')
