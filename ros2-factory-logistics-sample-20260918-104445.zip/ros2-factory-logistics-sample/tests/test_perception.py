import unittest,sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.core import TransportCore
from factory_logistics.perception import RangeSensor
from factory_logistics.realtime_world import RealtimeWorld

def nav(walls=None):return NavigationMap(dict(id='sensor-test',resolution=.1,robot_radius=.12,center_bounds=[0,0,8,8],outer_bounds=[-.3,-.3,8.3,8.3],walls=walls or []))
def obstacle(id,x,y):return dict(id=id,x=x,y=y,radius=.1)
class SensorTests(unittest.TestCase):
    def test_range_and_wall_occlusion(self):
        sensor=RangeSensor(nav([[1,0,1.2,2]]));objects={'near':obstacle('near',.5,.5),'hidden':obstacle('hidden',1.5,.5),'far':obstacle('far',0,5)}
        sensor.scan([0,.5],objects,0)
        self.assertEqual(set(sensor.tracks),{'near'})
        sensor.scan([1.6,2.3],objects,1);self.assertIn('hidden',sensor.tracks)
    def test_memory_does_not_follow_hidden_object_or_hidden_deletion(self):
        sensor=RangeSensor(nav());objects={'o':obstacle('o',1,0)};sensor.scan([0,0],objects,0)
        objects['o']['x']=6;sensor.scan([0,5],objects,1)
        self.assertEqual(sensor.tracks['o']['x'],1)
        sensor.scan([0,5],{},2);self.assertIn('o',sensor.tracks)
        sensor.scan([0,0],{},3);self.assertNotIn('o',sensor.tracks)
    def test_front_obstacle_occludes_rear(self):
        sensor=RangeSensor(nav());sensor.scan([0,0],{'a':obstacle('a',.5,0),'b':obstacle('b',1,0)},0)
        self.assertEqual(set(sensor.tracks),{'a'})
    def test_motion_inferred_from_observations(self):
        sensor=RangeSensor(nav());objects={'o':obstacle('o',1,0)};sensor.scan([0,0],objects,0)
        self.assertFalse(sensor.tracks['o']['moving']);objects['o']['y']=.1;sensor.scan([0,0],objects,.1)
        self.assertTrue(sensor.tracks['o']['moving'])
class ProcessTests(unittest.TestCase):
    def setUp(self):
        self.now=0.;self.core=TransportCore(navigation=nav());self.w=RealtimeWorld(self.core,lambda:self.now)
    def tick(self,n=1):
        for _ in range(n):self.now+=.1;self.w.tick(.1);self.assertTrue(self.core.navigation.point_free(self.w.pose()))
    def test_unseen_obstacle_not_used_for_initial_plan(self):
        self.w.obstacle(dict(operation='add',x=2.7,y=0));self.w.start('line_a','global')
        self.assertEqual(self.w.rt['route'],[[3.,0.]])
        self.tick();self.assertEqual(self.w.sensor.tracks,{})
        self.tick(18);self.assertTrue(self.w.sensor.tracks)
    def test_local_detour_then_original_route_arrival(self):
        self.w.obstacle(dict(operation='add',x=1,y=0));self.w.start('line_a','global');self.tick()
        self.assertEqual(self.w.rt['phase'],'ASSESSING');self.assertEqual(self.w.pose(),[0,0])
        self.tick(150)
        self.assertEqual(self.w.rt['phase'],'ARRIVED');self.assertEqual(self.w.rt['replans'],1)
        self.assertGreater(self.w.rt['local_avoids'],0)
        self.assertTrue(any(e['stage']=='기존 경로 복귀' for e in self.w.events))
    def test_moving_obstacle_yields_then_resumes(self):
        self.w.obstacle(dict(operation='add',x=1,y=0,mode='patrol',a=[1,0],b=[1,2],speed=.6))
        self.w.start('line_a','global');self.tick(3)
        self.assertEqual(self.w.rt['phase'],'YIELDING')
        self.tick(15);self.assertEqual(self.w.rt['phase'],'MOVING')
        self.assertEqual(self.w.rt['replans'],1)
    def test_blocked_corridor_requires_global_replan(self):
        self.core=TransportCore(navigation=NavigationMap());self.w=RealtimeWorld(self.core,lambda:self.now)
        self.w.obstacle(dict(operation='add',x=1,y=0));self.w.start('line_a','global');self.tick(5)
        self.assertEqual(self.w.rt['replans'],2);self.assertTrue(any(p[1]>1.8 for p in self.w.rt['route']))
    def test_all_routes_blocked_wait_then_free_observation_recovers(self):
        self.core=TransportCore(navigation=NavigationMap());self.w=RealtimeWorld(self.core,lambda:self.now)
        for x,y in [(1,0),(0,1)]:self.w.obstacle(dict(operation='add',x=x,y=y))
        self.w.start('line_a','global');self.tick(8);self.assertEqual(self.w.rt['phase'],'WAITING')
        self.w.obstacle(dict(operation='clear'));self.tick(100);self.assertEqual(self.w.rt['phase'],'ARRIVED')
    def test_stop_during_assessment_holds_position(self):
        self.w.obstacle(dict(operation='add',x=1,y=0));self.w.start('line_a','global');self.tick();self.w.stop();p=self.w.pose();self.tick(30);self.assertEqual(self.w.pose(),p)

    def test_physical_guard_does_not_supply_hidden_coordinates(self):
        self.w.obstacle(dict(operation='add',x=.6,y=0));self.w.start('line_a','global');self.w.sensor.RANGE=0
        self.tick(30)
        self.assertEqual(self.w.sensor.tracks,{})
        self.assertEqual(self.w.rt['replans'],1)
        self.assertLess(self.w.pose()[0],.38)
        self.assertTrue(any(e['stage']=='안전장치 · 충돌 차단' for e in self.w.events))
    def test_yield_timeout_falls_back_to_local_detour(self):
        self.w.obstacle(dict(operation='add',x=1,y=0,mode='patrol',a=[1,0],b=[1.5,0],speed=.2))
        self.w.start('line_a','global');self.tick(3)
        self.assertEqual(self.w.rt['phase'],'YIELDING')
        self.tick(18);self.assertGreater(self.w.rt['local_avoids'],0)
