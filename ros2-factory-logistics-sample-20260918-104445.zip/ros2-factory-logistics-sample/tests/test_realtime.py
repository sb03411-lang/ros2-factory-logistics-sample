import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.core import TransportCore
from factory_logistics.navigation import NavigationMap
from factory_logistics.realtime_world import RealtimeWorld

class RealtimeTests(unittest.TestCase):
    def setUp(self):
        self.now=100.
        self.core=TransportCore(navigation=NavigationMap())
        self.world=RealtimeWorld(self.core,lambda:self.now)
    def start(self):
        self.world.start('line_b');return self.world.observe()
    def act(self,obs,x=.5,y=0,kind='move'):
        self.world.action(dict(session=obs['session'],observation_id=obs['id'],action=dict(action=kind,x=x,y=y,explanation='관측된 밝은 통로로 이동')))
    def test_one_segment_then_stop_and_reobserve(self):
        obs=self.start();self.act(obs)
        for _ in range(30):self.world.tick(.1)
        self.assertAlmostEqual(self.core.snapshot()['x'],.5)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
        for _ in range(20):self.world.tick(.1)
        self.assertAlmostEqual(self.core.snapshot()['x'],.5)
        with self.assertRaises(ValueError):self.act(obs)
    def test_stale_and_long_and_wall_crossing_actions_rejected(self):
        obs=self.start();self.now+=31;self.act(obs)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
        obs=self.world.observe();self.act(obs,x=3)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
        obs=self.world.observe();self.act(obs,x=.3,y=.3)
        self.assertEqual(self.core.snapshot()['x'],0)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
    def test_obstacle_added_after_observation_blocks_action(self):
        obs=self.start()
        self.world.obstacle(dict(operation='add',x=.35,y=0))
        self.act(obs)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
        self.assertEqual(self.world.pose(),[0,0])
    def test_movement_interrupted_by_new_obstacle(self):
        obs=self.start();self.act(obs);self.world.tick(.1)
        self.world.obstacle(dict(operation='add',x=.32,y=0))
        for _ in range(20):self.world.tick(.1)
        self.assertLess(self.world.pose()[0],.1)
        self.assertEqual(self.world.rt['phase'],'OBSERVING')
        self.assertTrue(any(e['stage']=='이동 중 충돌 차단' for e in self.world.events))
    def test_stop_rejects_late_result_and_new_session(self):
        obs=self.start();self.world.stop()
        with self.assertRaises(ValueError):self.act(obs)
        self.world.start('line_a');self.world.observe()
        with self.assertRaises(ValueError):self.act(obs)
    def test_patrol_moves_but_never_crosses_robot_or_wall(self):
        self.world.obstacle(dict(operation='add',x=1,y=0,mode='patrol',a=[1,0],b=[2,0],speed=.6))
        for _ in range(200):
            self.world.tick(.1)
            o=list(self.world.obstacles.values())[0]
            self.assertGreaterEqual(o['x'],1-.001);self.assertLessEqual(o['x'],2+.001)
        o=list(self.world.obstacles.values())[0]
        with self.assertRaises(ValueError):self.world.obstacle(dict(operation='update',id=o['id'],x=0,y=0,mode='manual'))
        with self.assertRaises(ValueError):self.world.obstacle(dict(operation='update',id=o['id'],x=1,y=2,mode='manual'))
    def test_manual_mode_checks_dynamic_collision_and_obstacle_limit(self):
        self.world.obstacle(dict(operation='add',x=.35,y=0))
        self.core.manual_step(.5,0,1)
        self.assertEqual(self.world.pose(),[0,0])
        self.assertTrue(self.core.navigation_state()['collision_blocked'])
        for bad in (dict(operation='add',x=float('nan'),y=0),dict(operation='add',x=1,y=0,radius=100)):
            with self.assertRaises(ValueError):self.world.obstacle(bad)
    def test_observation_is_detached_and_wait_is_bounded(self):
        obs=self.start();detached=self.world.snapshot();detached['realtime']['observation']['pose'][0]=99
        self.assertEqual(self.world.rt['observation']['pose'],[0,0])
        self.act(obs,kind='wait');self.assertEqual(self.world.rt['phase'],'WAITING')
        self.now+=1.1;self.world.tick(.1);self.assertEqual(self.world.rt['phase'],'OBSERVING')
    def test_repeated_invalid_actions_stop_and_arrival_ends_loop(self):
        self.start()
        for _ in range(6):
            obs=self.world.rt['observation'];self.act(obs,x=8)
            if self.world.rt['active']:self.world.observe()
        self.assertFalse(self.world.rt['active'])
        self.world.start('warehouse');self.world.tick(.1)
        self.assertEqual(self.world.rt['phase'],'ARRIVED')

    def test_fortieth_observation_can_execute_before_limit(self):
        self.world.start('line_b');self.world.rt['cycle']=39
        obs=self.world.observe();self.world.tick(.1)
        self.assertTrue(self.world.rt['active'])
        self.act(obs)
        for _ in range(30):self.world.tick(.1)
        self.assertAlmostEqual(self.world.pose()[0],.5)
        self.assertEqual(self.world.rt['phase'],'LIMIT')

    def test_new_realtime_session_does_not_relabel_completed_action(self):
        self.core.start('PREVIOUS','warehouse');self.core.step(.1)
        self.world.start('line_b')
        self.assertEqual(self.core.snapshot()['job_id'],'')
