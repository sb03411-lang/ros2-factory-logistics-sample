import unittest, tempfile, json, sys, os
from pathlib import Path
from unittest.mock import patch, MagicMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/factory_logistics'))
from factory_logistics.llm_provider import Settings,complete,prompt_for
from factory_logistics.vision_planner import PlanError
class LLMTests(unittest.TestCase):
 def test_secret_persistence_redaction_and_clear(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'llm.json';s=Settings(p)
   s.save(dict(provider='openrouter',model='test/vision',api_key='test-secret'))
   self.assertNotIn('test-secret',json.dumps(s.public()));self.assertEqual(p.stat().st_mode&0o777,0o600)
   s.save(dict(model='test/next',api_key=''));self.assertEqual(Settings(p).data['api_key'],'test-secret')
   s.save(dict(provider='codex',clear_key=True));self.assertFalse(Settings(p).public()['has_key'])
 def test_missing_key_invalid_config_does_not_persist(self):
  with tempfile.TemporaryDirectory() as d:
   s=Settings(Path(d)/'settings')
   with self.assertRaises(PlanError):s.save(dict(provider='openrouter',model='test/vision'))
   self.assertEqual(s.public()['provider'],'codex')
 def test_image_request_and_json(self):
  response=MagicMock();response.__enter__.return_value.read.return_value=json.dumps({'choices':[{'message':{'content':'```json\n{"ok":true}\n```'}}]}).encode()
  with patch('urllib.request.urlopen',return_value=response) as call:
   self.assertTrue(complete(dict(model='test/vision',api_key='secret'),'review',b'png')['ok'])
   req=call.call_args.args[0];self.assertEqual(req.full_url,'https://openrouter.ai/api/v1/chat/completions')
   body=json.loads(req.data);self.assertTrue(body['messages'][0]['content'][1]['image_url']['url'].startswith('data:image/png;base64,'))
 def test_errors_do_not_echo_secret(self):
  with patch('urllib.request.urlopen',side_effect=ValueError('secret')):
   with self.assertRaises(PlanError) as cm:complete(dict(model='test',api_key='secret'),'test',b'png')
   self.assertNotIn('secret',str(cm.exception))
 def test_hidden_obstacles_excluded(self):
  prompt=prompt_for(dict(kind='realtime',observation=dict(pose=[1,2],obstacles=[{'hidden':'SECRET_WORLD'}],navigation={'hidden':'SECRET_WORLD'})))
  self.assertNotIn('SECRET_WORLD',prompt);self.assertIn('advisory only',prompt)
