import unittest,json,sys,math,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.core import TransportCore
from factory_logistics.realtime_world import RealtimeWorld,LiveNavigation

def setup():
 s=json.loads((Path(__file__).parent/'fixtures/stale-memory.json').read_text());n=NavigationMap(s['navigation']);c=TransportCore(navigation=n);c._x,c._y=s['pose'];t=[1000.];w=RealtimeWorld(c,lambda:t[0],camera_only=True);w.start('line_a','global',.3)
 w.sensor.tracks={o['id']:dict(o,last_seen=t[0]-o['age_seconds']) for o in s['tracks']};w.sensor.sequence=100
 return w,t

class ReobservationTests(unittest.TestCase):
 def test_stuck_case_gets_safe_viewpoint_without_deleting_memory(self):
  w,t=setup();before=copy.deepcopy(w.sensor.tracks)
  with self.assertRaises(ValueError):LiveNavigation(w.base,w.sensor.tracks).plan(w.pose(),[7.6,.3])
  w.replan('regression');self.assertEqual(w.rt['behavior'],'REOBSERVE_TRAVEL');self.assertEqual(w.sensor.tracks,before)
  nav=LiveNavigation(w.base,w.sensor.tracks);path=[w.pose()]+w.rt['route']
  self.assertTrue(all(nav.segment_free(a,b) for a,b in zip(path,path[1:])))
  r=w.reobserve;self.assertTrue(w.sensor._empty_visible(w.sensor.tracks[r['id']],path[-1],math.atan2(r['point'][1]-path[-1][1],r['point'][0]-path[-1][0]),[]))
 def test_fresh_tracks_are_not_treated_as_old(self):
  w,t=setup()
  for o in w.sensor.tracks.values():o['last_seen']=t[0]
  w.replan('fresh');self.assertIsNone(w.reobserve);self.assertEqual(w.rt['phase'],'WAITING')
  t[0]+=21;self.assertTrue(w.plan_reobservation())
 def test_inspection_waits_for_new_image_and_timeout_keeps_memory(self):
  w,t=setup();w.replan('test');r=w.reobserve;identifier=r['id'];w.core._x,w.core._y=w.rt['route'][-1];w.rt['route']=[]
  w.inspect_memory(.1);self.assertEqual(w.rt['phase'],'INSPECTING');t[0]+=2.1;w.inspect_memory(.1);self.assertIs(w.reobserve,r)
  t[0]+=7;w.inspect_memory(.1);self.assertIn(identifier,w.sensor.tracks);self.assertEqual(w.reobserve_visits[identifier],t[0])
 def test_camera_can_clear_missing_target_at_viewpoint(self):
  w,t=setup();w.replan('test');identifier=w.reobserve['id'];w.core._x,w.core._y=w.rt['route'][-1];w.rt['route']=[];w.inspect_memory(.1)
  for _ in range(7):
   t[0]+=.35;f=w.camera_capture();w.camera_result(dict(id=f['id'],detections=[],model='empty test image',inference_ms=0));w.inspect_memory(.1)
   if identifier not in w.sensor.tracks:break
  self.assertNotIn(identifier,w.sensor.tracks)
 def test_unknown_world_never_used_to_pick_viewpoint(self):
  w,t=setup()
  class Forbidden(dict):
   def values(self):raise AssertionError('world coordinates read')
  w.obstacles=Forbidden();self.assertTrue(w.plan_reobservation())
