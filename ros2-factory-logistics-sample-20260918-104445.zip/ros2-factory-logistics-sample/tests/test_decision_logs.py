import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'/'factory_logistics'))
from factory_logistics.vision_planner import VisionPlanner


class DecisionLogTests(unittest.TestCase):
    def setUp(self):
        self.planner=VisionPlanner([dict(id='line_b',label='Line B',x=3,y=2)],b'image')
        self.planner.heartbeat({})
        self.planner.request({'prompt':'생산라인 B로 이동'},(0,0))
        self.job=self.planner.claim({})[1]['job']

    def result(self, **changes):
        data=dict(status='ready',destination='line_b',target_x=3.,target_y=2.,
                  observed_label='LINE B',explanation='도면 오른쪽 위 LINE B 표기와 (3, 2) 좌표를 확인했습니다.')
        data.update(changes)
        self.planner.result(dict(id=self.job['id'],token=self.job['token'],map_hash=self.job['map_hash'],result=data))

    def test_model_and_validator_decisions_are_distinct_and_no_token_is_exposed(self):
        self.result()
        logs=list(reversed(self.planner.snapshot()['logs']))
        self.assertEqual([row['source'] for row in logs],['SYSTEM','SYSTEM','LLM','VALIDATOR','VALIDATOR','SYSTEM'])
        self.assertEqual(logs[2]['details']['target_x'],3.)
        self.assertEqual(logs[3]['details']['registered_coordinates'],[3,2])
        self.assertGreater(logs[4]['details']['length_m'],4)
        self.assertNotIn(self.job['token'],json.dumps(logs))
        self.assertEqual({row['request_id'] for row in logs},{self.job['id']})
        logs[2]['message']='changed'
        self.assertNotEqual(self.planner.snapshot()['logs'][3]['message'],'changed')

    def test_failed_validation_keeps_the_model_output_and_reason(self):
        self.result(target_x=99)
        logs=self.planner.snapshot()['logs']
        self.assertEqual(logs[0]['level'],'ERROR')
        self.assertIn('일치하지',logs[0]['message'])
        self.assertEqual(logs[1]['source'],'LLM')
        self.assertEqual(logs[1]['details']['target_x'],99)

    def test_clarification_never_claims_execution(self):
        self.result(status='needs_clarification',explanation='도면에 출하장 Z가 없습니다.')
        logs=self.planner.snapshot()['logs']
        self.assertEqual(logs[0]['stage'],'실행 보류')
        self.assertFalse(any(row['source']=='ROS' for row in logs))

    def test_execution_result_is_logged_only_once(self):
        self.result()
        self.planner.prepare_execution({'id':self.job['id']},(0,0))
        self.planner.execution_state('SUCCEEDED','Arrived')
        self.planner.execution_state('SUCCEEDED','Arrived')
        logs=self.planner.snapshot()['logs']
        self.assertEqual(sum(row['stage']=='이동 결과' for row in logs),1)
        self.assertEqual(logs[0]['details']['state'],'SUCCEEDED')

    def test_bounded_log_retention(self):
        for index in range(250):
            self.planner.record('SYSTEM','test',str(index))
        logs=self.planner.snapshot()['logs']
        self.assertEqual(len(logs),200)
        self.assertEqual(logs[0]['message'],'249')
