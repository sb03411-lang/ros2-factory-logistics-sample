import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'))
from factory_logistics.map_store import validate_map, save_map, load_map
from factory_logistics.core import TransportCore
from factory_logistics.vision_planner import VisionPlanner, PlanError


class EditableMapTests(unittest.TestCase):
    def setUp(self):
        self.data = {'center_bounds': [0, 0, 5, 4], 'walls': [[1, .5, 2, 1.5]]}

    def test_bad_shapes_nonfinite_and_unbounded_input(self):
        for data in (None, {}, {'center_bounds':[0,0,999,999], 'walls':[]},
                     dict(self.data, walls=[[0,0,float('nan'),1]]),
                     dict(self.data, walls=[[0,0,1]]),
                     dict(self.data, walls=self.data['walls']*33),
                     dict(self.data, walls=[[1,1,1.01,2]])):
            with self.subTest(data=data), self.assertRaises(ValueError):
                validate_map(data)

    def test_protect_robot_destinations_and_connectivity(self):
        for walls, pose in (([[2.8,1.8,3.2,2.2]],(0,0)),
                            ([[.5,.5,1.5,1.5]],(1,1)),
                            ([[1.4,0,1.6,4]],(0,0))):
            with self.subTest(walls=walls), self.assertRaises(ValueError):
                validate_map(dict(self.data,walls=walls), pose)

    def test_geometry_and_id_are_server_owned_and_detached(self):
        self.data.update(id='user-id', robot_radius=.15, resolution=.000000001)
        nav = validate_map(self.data)
        self.assertEqual(nav.radius,.15)
        self.assertEqual(nav.resolution,.1)
        self.assertTrue(nav.data['id'].startswith('map-'))
        self.data['walls'].clear()
        self.assertEqual(len(nav.walls),1)

    def test_saved_map_survives_reload_and_failed_replace(self):
        nav = validate_map(self.data)
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, FACTORY_MAP_PATH=folder+'/map.json'):
            save_map(nav)
            self.assertEqual(load_map().data, nav.data)
            other = validate_map(dict(self.data,walls=[]))
            with patch('factory_logistics.map_store.os.replace',side_effect=OSError('disk failed')):
                with self.assertRaises(OSError):
                    save_map(other)
            self.assertEqual(load_map().data, nav.data)
            self.assertEqual(len(list(Path(folder).iterdir())),1)

    def test_manual_motion_uses_expanded_bounds(self):
        core = TransportCore(navigation=validate_map(dict(self.data,walls=[])))
        core.manual_step(.5,0,9)
        self.assertEqual(core.snapshot()['x'],4.5)
        core.manual_step(.5,0,10)
        self.assertEqual(core.snapshot()['x'],5)

    def test_map_change_expires_ready_plan_and_rejects_old_response(self):
        planner=VisionPlanner([dict(id='line_b',label='Line B',x=3,y=2)],b'old')
        planner.heartbeat({})
        planner.request({'prompt':'Line B'},(0,0))
        job=planner.claim({})[1]['job']
        planner.update_map(validate_map(self.data),b'new')
        self.assertEqual(planner.snapshot()['plan']['state'],'EXPIRED')
        self.assertTrue(planner.snapshot()['worker_connected'])
        with self.assertRaises(PlanError):
            planner.result(dict(id=job['id'],token=job['token'],map_hash=job['map_hash']))
        with self.assertRaises(PlanError):
            planner.prepare_execution({'id':job['id']},(0,0))
