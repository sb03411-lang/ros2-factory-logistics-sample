import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.core import TransportCore


class NavigationTests(unittest.TestCase):
    def setUp(self):
        self.nav = NavigationMap()

    def test_direct_diagonal_is_blocked_and_route_detours(self):
        self.assertFalse(self.nav.segment_free((0,0),(3,2)))
        path = self.nav.plan((0,0),(3,2))
        self.assertGreater(len(path), 2)
        self.assertGreater(self.nav.length(path), math.hypot(3,2))
        self.assertTrue(all(self.nav.segment_free(a,b) for a,b in zip(path,path[1:])))

    def test_footprint_clearance_and_swept_collision(self):
        self.assertFalse(self.nav.point_free((.2,1)))  # Center outside wall, footprint overlaps.
        self.assertTrue(self.nav.point_free((.1,1)))
        self.assertFalse(self.nav.segment_free((0,1),(3,1)))  # Both endpoints free, middle blocked.
        self.assertFalse(self.nav.segment_free((0,0),(2,.2)))  # Corner clipping.

    def test_automatic_trajectory_never_crosses_wall(self):
        core = TransportCore(navigation=self.nav)
        for index, target in enumerate(('line_b','warehouse','line_a','line_b','warehouse')):
            core.start(str(index), target)
            old_remaining = core.snapshot()['remaining_distance']
            for _ in range(150):
                before = core.snapshot()
                core.step(.05)
                after = core.snapshot()
                self.assertTrue(self.nav.segment_free((before['x'],before['y']),(after['x'],after['y'])))
                self.assertLessEqual(after['remaining_distance'], old_remaining+1e-8)
                old_remaining = after['remaining_distance']
                if after['state'] == 'SUCCEEDED':
                    break
            self.assertEqual(core.snapshot()['state'], 'SUCCEEDED')

    def test_manual_cannot_tunnel_through_wall(self):
        core = TransportCore(navigation=self.nav)
        core.manual_step(0,.5,2)
        self.assertEqual((core.snapshot()['x'],core.snapshot()['y']),(0,1))
        core.manual_step(.5,0,6)
        self.assertEqual((core.snapshot()['x'],core.snapshot()['y']),(0,1))
        self.assertTrue(core.navigation_state()['collision_blocked'])
        core.manual_step(0,-.5,1)
        self.assertEqual(core.snapshot()['y'], .5)
        self.assertFalse(core.navigation_state()['collision_blocked'])

    def test_unreachable_goal_and_blocked_start_fail_closed(self):
        data = dict(self.nav.data, walls=[[1.4,-.3,1.6,2.3]])
        divided = NavigationMap(data)
        with self.assertRaises(ValueError):
            divided.plan((0,0),(3,2))
        with self.assertRaises(ValueError):
            self.nav.plan((1,1),(3,2))

    def test_large_dt_follows_waypoints_without_shortcut(self):
        core = TransportCore(navigation=self.nav)
        core.start('large-dt','line_b')
        core.step(100)
        self.assertEqual(core.snapshot()['state'], 'SUCCEEDED')
        self.assertEqual((core.snapshot()['x'],core.snapshot()['y']),(3,2))
