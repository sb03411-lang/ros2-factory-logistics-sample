import unittest,sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/factory_logistics'))
from factory_logistics.navigation import NavigationMap
from factory_logistics.core import TransportCore
from factory_logistics.realtime_world import RealtimeWorld, LiveNavigation
from factory_logistics.camera_perception import CameraPerception


def world():
    nav=NavigationMap(dict(id='test-camera',resolution=.1,robot_radius=.25,robot_clearance=.1,center_bounds=[0,0,8,8],outer_bounds=[-.4,-.4,8.4,8.4],walls=[],stations=dict(warehouse=[0,0],line_a=[7,0],line_b=[7,7])))
    now=[0.];w=RealtimeWorld(TransportCore(navigation=nav),lambda:now[0],camera_only=True);return w,now

def observe(w,boxes=[]):
    frame=w.camera_capture();w.camera_result(dict(id=frame['id'],detections=boxes,model='test-obstacle',inference_ms=20));return frame

class CameraNavigationTests(unittest.TestCase):
 def test_legacy_start_cannot_bypass_camera_guard(self):
    w,t=world();w.start("line_a","reactive");w.tick(.1)
    self.assertEqual(w.rt["mode"],"global");self.assertEqual(w.pose(),[0,0])
 def test_without_camera_frames_robot_stays_still(self):
    w,t=world();w.start('line_a','global')
    for _ in range(20):t[0]+=.1;w.tick(.1)
    self.assertEqual(w.pose(),[0,0]);self.assertIn('관측 대기',w.rt['camera_wait'])
 def test_no_range_scan_or_hidden_obstacle_track(self):
    w,t=world();w.obstacle(dict(operation='add',x=0,y=1.5,radius=.1));w.sensor.scan=lambda *a:(_ for _ in ()).throw(AssertionError('range scan called'))
    w.sense();self.assertFalse(w.sensor.tracks)
    w.start('line_a','global');observe(w,[]);t[0]+=.1;w.tick(.1)
    self.assertFalse(w.sensor.tracks);self.assertGreater(w.pose()[0],0)
 def test_stale_frames_stop_movement(self):
    w,t=world();w.start('line_a','global');observe(w);w.tick(.1);p=w.pose();t[0]=1.3;w.tick(.1)
    self.assertEqual(w.pose(),p)
 def test_boxes_create_tracks_without_world_object(self):
    w,t=world();w.start('line_a','global');observe(w,[dict(label='obstacle',confidence=.9,xyxy=[290,100,350,280])])
    self.assertEqual(len(w.sensor.tracks),1);self.assertFalse(w.obstacles)
    track=next(iter(w.sensor.tracks.values()));self.assertGreater(track['x'],2);self.assertAlmostEqual(track['y'],0)
 def test_expired_wrong_id_and_previous_session_rejected(self):
    w,t=world();f=w.camera_capture();w.start('line_a','global')
    with self.assertRaises(ValueError):w.camera_result(dict(id=f['id'],detections=[]))
    f=w.camera_capture();t[0]=2
    with self.assertRaises(ValueError):w.camera_result(dict(id=f['id'],detections=[]))
 def test_turn_waits_for_new_camera_heading(self):
    w,t=world();w.start('line_b','global');observe(w);w.tick(.1)
    self.assertEqual(w.pose(),[0,0]);t[0]+=.1;observe(w);w.tick(.1);self.assertGreater(math.dist(w.pose(),[0,0]),0)
 def test_only_visible_input_boxes_used(self):
    w,t=world();observe(w,[]);s=w.sensor.snapshot(t[0]);self.assertEqual(s['type'],'camera_yolo');self.assertEqual(s['fov_deg'],80);self.assertEqual(s['tracks'],[])
 def test_near_bottom_inset_box_is_conservative(self):
    w,t=world();observe(w,[dict(label="obstacle",confidence=.97,xyxy=[355,29,523,327])])
    track=next(iter(w.sensor.tracks.values()));self.assertLess(track["x"],1.65);self.assertLess(track["radius"],.4)
 def test_impossible_box_rejected(self):
    w,t=world()
    with self.assertRaises(ValueError):observe(w,[dict(label='obstacle',confidence=.9,xyxy=[0,0,float('nan'),50])])
 def test_collision_guard_never_injects_hidden_coordinates(self):
    w,t=world();w.obstacle(dict(operation='add',x=1,y=0,radius=.1));w.start('line_a','global')
    for _ in range(40):observe(w,[]);t[0]+=.1;w.tick(.1);w.snapshot()
    self.assertLess(w.pose()[0],.56);self.assertFalse(w.sensor.tracks)

class CameraStabilityTests(unittest.TestCase):
 def box(self,bottom=270,width=90):return dict(label='obstacle',confidence=.95,xyxy=[320-width/2,30,320+width/2,bottom])
 def test_one_pixel_does_not_duplicate_obstacle(self):
    w,t=world();observe(w,[self.box(314,120)]);a=next(iter(w.sensor.tracks.values()))['x']
    t[0]=.2;observe(w,[self.box(315,120)]);self.assertEqual(len(w.sensor.tracks),1)
    self.assertLess(abs(next(iter(w.sensor.tracks.values()))['x']-a),.05)
 def test_stationary_memory_survives_turn_and_long_detour(self):
    w,t=world();observe(w,[self.box()]);t[0]=.3;observe(w,[self.box()]);w.yaw=math.pi
    t[0]=50;observe(w,[]);self.assertEqual(len(w.sensor.tracks),1)
 def test_clear_requires_multiple_empty_observations(self):
    w,t=world();observe(w,[self.box()]);t[0]=.2;observe(w,[self.box()])
    t[0]=1;observe(w,[]);self.assertEqual(len(w.sensor.tracks),1)
    for dt in (1.4,1.8,2.3):t[0]=dt;observe(w,[])
    self.assertFalse(w.sensor.tracks)
 def test_shelf_occlusion_does_not_clear_memory(self):
    w,t=world();observe(w,[self.box()]);t[0]=.2;observe(w,[self.box()]);w.sensor.sight.walls=[[1,-1,1.5,1]];w.sensor.sight.inflated=w.sensor.sight.walls
    for dt in (1,2,3,4):t[0]=dt;observe(w,[])
    self.assertEqual(len(w.sensor.tracks),1)
 def test_other_detected_box_does_not_prove_free_space(self):
    w,t=world();observe(w,[self.box()]);t[0]=.2;observe(w,[self.box()])
    old=next(iter(w.sensor.tracks.values()))
    self.assertFalse(w.sensor._empty_visible(old,[0,0],0,[self.box(330,150)]))
 def test_pending_detection_stops_before_replan(self):
    w,t=world();w.start('line_a','global');observe(w,[self.box()]);w.tick(.1)
    self.assertEqual(w.pose(),[0,0]);self.assertEqual(w.rt['replans'],1)
 def test_repeated_route_enters_observation_wait(self):
    w,t=world();w.start('line_a','global');w.replan('test');w.replan('test')
    self.assertEqual(w.rt['behavior'],'REOBSERVE');self.assertFalse(w.rt['route'])
    n=w.rt['replans'];t[0]=5;observe(w,[]);w.tick(.1);self.assertEqual(w.rt['replans'],n)
 def test_route_distance_matches_path(self):
    w,t=world();w.start('line_a','global');self.assertAlmostEqual(w.snapshot()['realtime']['remaining_route_m'],7.)

 def test_deleted_near_obstacle_can_be_cleared(self):
    w,t=world();observe(w,[self.box(330,110)]);t[0]=.2;observe(w,[self.box(330,110)])
    for dt in (1,1.4,1.8,2.3):t[0]=dt;observe(w,[])
    self.assertFalse(w.sensor.tracks)
 def test_waiting_reobserves_remembered_obstacle_with_camera(self):
    w,t=world();w.start('line_a','global');observe(w,[self.box()]);t[0]=.2;observe(w,[self.box()])
    w.rt.update(phase='WAITING',route=[]);w.yaw=math.pi;t[0]=.3;w.tick(.1)
    self.assertAlmostEqual(w.yaw,0.);self.assertEqual(w.pose(),[0,0])

 def test_reobservation_does_not_starve_other_tracks(self):
    w,t=world();w.start('line_a','global');observe(w,[self.box()]);t[0]=.2;observe(w,[self.box()])
    first=next(iter(w.sensor.tracks.values()));second=dict(first,id='V-extra',x=0,y=3)
    w.sensor.tracks['V-extra']=second;w.rt.update(phase='WAITING',route=[]);w.wait_revision=w.sensor.revision
    t[0]=.3;w.tick(.1);self.assertAlmostEqual(w.yaw,0.)
    t[0]=2.4;w.tick(.1);self.assertAlmostEqual(w.yaw,math.pi/2)

 def test_planner_and_motion_use_same_circular_clearance(self):
    w,t=world();nav=LiveNavigation(w.base,{'o':dict(x=3.5,y=3.5,radius=.22)})
    goal=[3,3];self.assertTrue(nav.point_free(goal))
    path=nav.plan([2,3],goal);self.assertEqual(path[-1],goal)
    self.assertTrue(all(nav.segment_free(a,b) for a,b in zip(path,path[1:])))
 def test_planner_still_rejects_goal_inside_clearance(self):
    w,t=world();nav=LiveNavigation(w.base,{'o':dict(x=3.2,y=3.2,radius=.22)})
    with self.assertRaises(ValueError):nav.plan([2,3],[3,3])

class RecoveryAndPeopleTests(unittest.TestCase):
 def test_collision_does_not_resume_without_fresh_scan(self):
    w,t=world();w.obstacle(dict(operation='add',x=.62,y=0,radius=.25));w.start('line_a','global',.3)
    observe(w,[])
    for _ in range(5):t[0]+=.1;w.tick(.1)
    self.assertEqual(w.rt['phase'],'RECOVERING');p=w.pose()
    for _ in range(4):t[0]+=.1;w.tick(.1)
    self.assertEqual(w.pose(),p);self.assertEqual(w.recovery['index'],0)
    for _ in range(4):
      t[0]+=.1;observe(w,[]);w.tick(.1)
    self.assertEqual(w.rt['phase'],'BLOCKED');self.assertFalse(w.rt['active']);self.assertEqual(w.pose(),p)
    self.assertEqual(sum(e['stage']=='안전장치 · 충돌 차단' for e in w.events),1)
 def test_recovery_camera_timeout_stops(self):
    w,t=world();w.obstacle(dict(operation='add',x=.62,y=0,radius=.25));w.start('line_a','global',.3);observe(w,[])
    t[0]+=.1;w.tick(.1);t[0]+=13;w.tick(.1)
    self.assertEqual(w.rt['phase'],'BLOCKED');self.assertFalse(w.rt['active'])
 def test_people_off_on_preserves_objects_and_camera_memory(self):
    w,t=world();w.obstacle(dict(operation='add',x=3,y=3));w.obstacle(dict(operation='people',count=2))
    ids=set(w.obstacles);objects={k for k,o in w.obstacles.items() if o['kind']!='person'}
    w.sensor.tracks['remembered']={'id':'remembered'}
    w.obstacle(dict(operation='people_toggle',enabled=False))
    self.assertEqual(set(w.obstacles),objects);self.assertEqual(len(w.disabled_people),2);self.assertIn('remembered',w.sensor.tracks)
    w.obstacle(dict(operation='people_toggle',enabled=True));self.assertEqual(set(w.obstacles),ids);self.assertFalse(w.disabled_people)
 def test_people_enable_relocates_if_robot_occupies_previous_spot(self):
    w,t=world();w.obstacle(dict(operation='people',count=1));o=next(iter(w.obstacles.values())).copy()
    w.obstacle(dict(operation='people_toggle',enabled=False));w.core._x,w.core._y=o['x'],o['y']
    w.obstacle(dict(operation='people_toggle',enabled=True));new=w.obstacles[o['id']]
    self.assertGreater(math.dist(w.pose(),[new['x'],new['y']]),new['radius']+w.base.radius)
 def test_clear_removes_saved_people(self):
    w,t=world();w.obstacle(dict(operation='people',count=2));w.obstacle(dict(operation='people_toggle',enabled=False));w.obstacle(dict(operation='clear'))
    self.assertFalse(w.disabled_people)


def make_box(depth, side=0., width_m=0.3):
    f = 320. / math.tan(math.radians(40))
    y2 = min(355, max(155, int(145 + 0.85 * f / depth)))
    cx = 320 + side * f / depth
    w_px = max(20, width_m * f / depth)
    x1 = max(0, cx - w_px / 2)
    x2 = min(640, cx + w_px / 2)
    return dict(label='obstacle', confidence=0.95, xyxy=[x1, 30, x2, y2])


def yielding_world():
    nav = NavigationMap(dict(
        id='test-yield-map', resolution=.1, robot_radius=.25, robot_clearance=.1,
        center_bounds=[0, 0, 8, 8], outer_bounds=[-.4, -.4, 8.4, 8.4],
        walls=[], stations=dict(warehouse=[1.0, 4.0], line_a=[7.0, 4.0])
    ))
    now = [100.0]
    core = TransportCore(navigation=nav)
    core._x, core._y = 1.0, 4.0
    w = RealtimeWorld(core, lambda: now[0], camera_only=True)
    return w, now


class CameraYieldingTests(unittest.TestCase):
    def test_crossing_obstacle_yields_then_resumes_after_clearance_and_two_fresh_frames(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.5)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.3)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=-0.1)])
        t[0] = 100.9; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        self.assertEqual(w.rt['behavior'], 'YIELD')
        self.assertEqual(w.pose(), [1.0, 4.0])
        self.assertIn('양보', w.rt['message'])

        for _ in range(5):
            t[0] += 0.2; observe(w, [make_box(2.0, side=0.0)]); w.tick(0.1)
            self.assertEqual(w.rt['phase'], 'YIELDING')
            self.assertEqual(w.pose(), [1.0, 4.0])

        # 4 empty frames over 1.2s to clear from memory
        t[0] = 102.0; observe(w, [])
        t[0] = 102.4; observe(w, [])
        t[0] = 102.8; observe(w, [])
        t[0] = 103.3; observe(w, [])
        self.assertEqual(len(w.sensor.tracks), 0)
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        self.assertEqual(w.yield_episode['clear_confirmations'], 1)

        # 2nd fresh empty frame at t=103.6 (now >= base_until 103.4 and 2 fresh frames)
        t[0] = 103.6; observe(w, []); w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'MOVING')
        self.assertEqual(w.rt['behavior'], 'GLOBAL_ROUTE')
        self.assertTrue(any('통로 확보 · 이동 재개' in e['stage'] for e in w.events))

    def test_first_empty_frame_path_no_type_error(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        t[0] = 100.8; observe(w, []); w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')

    def test_single_missed_detection_does_not_resume_early(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')

        w.sensor.tracks.clear()
        t[0] = 103.5; observe(w, []); w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        self.assertEqual(w.yield_episode['clear_confirmations'], 1)

        t[0] = 103.7; observe(w, [make_box(2.0, side=0.0)]); w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        self.assertEqual(w.yield_episode['clear_confirmations'], 0)
        self.assertEqual(w.pose(), [1.0, 4.0])

    def test_same_frame_reuse_does_not_increment_clear_count(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')

        w.sensor.tracks.clear()
        t[0] = 103.5; observe(w, []); w.tick(0.1)
        self.assertEqual(w.yield_episode['clear_confirmations'], 1)

        for _ in range(5):
            t[0] += 0.05
            w.tick(0.05)
            self.assertEqual(w.rt['phase'], 'YIELDING')
            self.assertEqual(w.yield_episode['clear_confirmations'], 1)

    def test_crossing_obstacle_blocks_over_5s_transitions_to_detour(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')

        for step in range(25):
            t[0] += 0.2
            observe(w, [make_box(2.0, side=0.0)])
            w.tick(0.1)
            if w.rt['phase'] != 'YIELDING':
                break

        self.assertIn(w.rt['behavior'], ('LOCAL_AVOID', 'REPLAN', 'NO_ROUTE'))
        self.assertTrue(any('양보 한도 초과' in e['stage'] for e in w.events))

    def test_stationary_obstacle_no_5s_wait(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.1; observe(w, [make_box(2.0, side=0.0)])
        t[0] = 100.95; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        t[0] += 0.3; w.tick(0.1)
        self.assertNotEqual(w.rt['phase'], 'YIELDING')
        self.assertTrue(any('우회' in e['stage'] for e in w.events))

    def test_approaching_obstacle_stops_and_ego_motion_does_not_trigger_approaching(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        observe(w, [])
        w.tick(0.1)
        self.assertGreater(w.pose()[0], 1.0)
        t[0] = 100.2; observe(w, [make_box(3.0, side=0.0)]); w.tick(0.1)
        t[0] = 100.5; observe(w, [make_box(2.9, side=0.0)]); w.tick(0.1)
        track = next(iter(w.sensor.tracks.values()))
        self.assertFalse(track.get('approaching', False))

        w2, t2 = yielding_world()
        w2.start('line_a', 'global', 0.3)
        t2[0] = 100.0; observe(w2, [make_box(3.0, side=0.0)])
        t2[0] = 100.4; observe(w2, [make_box(2.5, side=0.0)])
        track2 = next(iter(w2.sensor.tracks.values()))
        self.assertTrue(track2.get('approaching', False))
        w2.tick(0.1)
        self.assertEqual(w2.rt['phase'], 'YIELDING')

    def test_camera_latency_and_id_switch_preserves_5s_episode_deadline(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')
        original_max_until = w.yield_episode['max_until']

        t[0] += 1.8
        w.sensor.tracks.clear()
        observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertAlmostEqual(w.yield_episode['max_until'], original_max_until, places=2)

    def test_failed_detour_replan_does_not_repeat_yielding_wait_at_same_spot(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'YIELDING')

        t[0] = 105.7
        observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertTrue(w.yield_episode.get('exhausted'))

        w.replan('test detour failure')
        self.assertIsNotNone(w.yield_episode)
        self.assertTrue(w.yield_episode.get('exhausted'))

        t[0] = 105.9
        observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        self.assertNotEqual(w.rt['phase'], 'YIELDING')

    def test_stale_or_misaligned_frame_halts_immediately_even_if_yield_expired(self):
        w, t = yielding_world()
        w.start('line_a', 'global', 0.3)
        t[0] = 100.0; observe(w, [make_box(2.0, side=-0.4)])
        t[0] = 100.3; observe(w, [make_box(2.0, side=-0.2)])
        t[0] = 100.6; observe(w, [make_box(2.0, side=0.0)])
        w.tick(0.1)
        t[0] = 107.0
        w.tick(0.1)
        self.assertEqual(w.pose(), [1.0, 4.0])
        self.assertIn('관측 대기', w.rt.get('camera_wait', ''))

    def test_interaction_with_collision_recovery_and_yielding(self):
        w, t = yielding_world()
        w.obstacle(dict(operation='add', x=1.62, y=4.0, radius=0.25))
        w.start('line_a', 'global', 0.3)
        observe(w, [])
        for _ in range(5): t[0] += 0.1; w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'RECOVERING')
        self.assertEqual(w.recovery['index'], 0)
        for _ in range(4):
            t[0] += 0.1; observe(w, []); w.tick(0.1)
        self.assertEqual(w.rt['phase'], 'BLOCKED')
        self.assertFalse(w.rt['active'])
