import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'))
from factory_logistics.vision_planner import VisionPlanner, PlanError


class VisionTests(unittest.TestCase):
    def setUp(self):
        self.planner = VisionPlanner([{'id': 'line_b', 'label': 'Line B', 'x': 3., 'y': 2.}], b'image')
        self.planner.heartbeat({})

    def claimed(self):
        self.planner.request({'prompt': 'Line B'}, (0., 0.))
        return self.planner.claim({})[1]['job']

    def result(self, job, **changes):
        result = dict(status='ready', destination='line_b', target_x=3.02, target_y=2.,
                      observed_label='LINE B', explanation='Image evidence')
        result.update(changes)
        return self.planner.result(dict(id=job['id'], token=job['token'], map_hash=job['map_hash'], result=result))

    def test_validated_coordinates_and_one_execution(self):
        job = self.claimed()
        self.result(job)
        self.assertEqual(self.planner.snapshot()['plan']['result']['x'], 3.)
        self.assertEqual(self.planner.prepare_execution({'id': job['id']}, (0., 0.))['destination'], 'line_b')
        with self.assertRaises(PlanError):
            self.planner.prepare_execution({'id': job['id']}, (0., 0.))

    def test_mismatched_coordinate_does_not_become_executable(self):
        job = self.claimed()
        self.result(job, target_x=99)
        self.assertEqual(self.planner.snapshot()['plan']['state'], 'FAILED')
        with self.assertRaises(PlanError):
            self.planner.prepare_execution({'id': job['id']}, (0., 0.))

    def test_ambiguous_request_never_executes(self):
        job = self.claimed()
        self.result(job, status='needs_clarification')
        self.assertEqual(self.planner.snapshot()['plan']['state'], 'CLARIFY')

    def test_moved_robot_requires_new_plan(self):
        job = self.claimed()
        self.result(job)
        with self.assertRaises(PlanError):
            self.planner.prepare_execution({'id': job['id']}, (1., 0.))
        self.assertEqual(self.planner.snapshot()['plan']['state'], 'EXPIRED')

    def test_bad_claim_and_duplicate_requests(self):
        job = self.claimed()
        with self.assertRaises(PlanError):
            self.planner.request({'prompt': 'Line B'}, (0., 0.))
        with self.assertRaises(PlanError):
            self.planner.result(dict(id=job['id'], token='bad', map_hash=job['map_hash']))
        self.assertEqual(self.planner.snapshot()['plan']['state'], 'READING')
