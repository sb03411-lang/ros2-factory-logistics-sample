import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'factory_logistics'))
from factory_logistics.core import TransportCore


class ManualTests(unittest.TestCase):
    def test_bounds_stop_and_return_to_auto(self):
        core = TransportCore()
        core.manual_step(.3, .4, 100)
        self.assertEqual((core.snapshot()['x'], core.snapshot()['y']), (3., 2.))
        core.manual_step(-.3, -.4, 100)
        self.assertEqual((core.snapshot()['x'], core.snapshot()['y']), (0., 0.))
        core.manual_step(0, 0, .1)
        self.assertEqual(core.snapshot()['state'], 'IDLE')
        core.start('AFTER-MANUAL', 'line_a')
        with self.assertRaises(ValueError):
            core.manual_step(.5, 0, .1)
        core.step(4)
        self.assertEqual(core.snapshot()['state'], 'SUCCEEDED')

    def test_reject_nonfinite_and_excess_speed_without_moving(self):
        core = TransportCore()
        original = core.snapshot()
        for vx, vy, dt in [(float('nan'), 0, .1), (.5, .5, .1), (0, 0, -1)]:
            with self.assertRaises(ValueError):
                core.manual_step(vx, vy, dt)
            self.assertEqual(core.snapshot(), original)
