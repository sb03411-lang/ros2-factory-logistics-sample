# 카메라 관측 동적 장애물 양보 및 재판단 동작 개선 핸드오프 보고서

본 문서는 카메라로 관측한 움직이는 장애물에 대해 즉각적인 우회보다 잠시 양보한 뒤 통로 열림을 확인하고 주행을 재개하거나, 지속 차단 시 우회/재탐색으로 전환하는 기능 개선 작업의 구현 및 검증 결과를 기록합니다.

---

## 1. 변경 파일 목록

| 파일 경로 | 주요 변경 내용 |
| :--- | :--- |
| [`src/factory_logistics/factory_logistics/camera_perception.py`](file:///Users/igyeongseog/Documents/Codex/2026-09-16/new-chat/outputs/ros2-factory-logistics-sample/src/factory_logistics/factory_logistics/camera_perception.py) | - 카메라 단안 바닥 투영 기반 관측 이력(`history`), 속도 추정(`vx`, `vy`, `speed`), 움직임 판정(`moving`, `moving_until`) 추가<br>- **자차 이동 영향 배제**: 현재 로봇 위치 기준 객체 속도의 방사 성분(`radial_speed`)으로만 접근(`approaching`) 판정 및 정지 후 즉시 해제<br>- 단안 거리 추정 흔들림(`disp > 0.12m`, `speed >= 0.10m/s`) 및 ID 전환 순간 점프(`> 1.8m/s`) 필터링<br>- 고정 장애물(`disp < 0.08m`, `dt >= 0.8s`) 식별 및 기존 4프레임/1.2초 빈 공간 해제 조건 엄격 보존<br>- `snapshot` 시 `history` 필드 제외하여 직렬화 최적화 |
| [`src/factory_logistics/factory_logistics/realtime_world.py`](file:///Users/igyeongseog/Documents/Codex/2026-09-16/new-chat/outputs/ros2-factory-logistics-sample/src/factory_logistics/factory_logistics/realtime_world.py) | - 선분 교차 알고리즘(`ccw`, `intersect_segments`) 및 경로 교차 판정(`obstacle_crosses_route`) 구현<br>- **대기 에피소드(`yield_episode`) 관리**: 약 2.5초 기본 양보, 에피소드 총 대기 최대 5.0초 상한 엄격 적용<br>- **타이머 리셋 방지**: 동일 위치(`dist < 0.20m`) 대기 중 카메라 지연, 관측 보류, 장애물 ID 변경에도 원래 5.0초 마감 시각 고정 유지<br>- **우회/재계획 실패 후 반복 대기 방지**: 5초 만료 후 `exhausted=True` 플래그 유지로 동일 위치에서 5초 대기 루프 재진입 차단<br>- **`last_confirmed_frame` TypeError 수정**: 첫 빈 프레임 안전 비교 (`is_new_frame = last_f is None or frame_time > last_f`)<br>- **탐지 1회 누락 조기 출발 방지**: 경로 차단(`blocked is not None`) 시 `hits < 2` 대기 중이어도 `clear_confirmations` 즉시 0 리셋<br>- **통로 열림 연속 확인**: 트랙 기억 해제 후 서로 다른 최신 영상 2회 이상 연속 확인 + 기본 양보 시간 경과 시 출발<br>- 고정 장애물 즉시 우회(0.2초 평가 후 대기 없이 우회/재탐색)<br>- 영상 지연/방향 불일치 시 5초 경과 여부와 무관하게 즉시 안전 정지(`camera_wait`) 유지<br>- 기존 충돌 복구(`RECOVERING`/`BLOCKED`), 오래된 기억 재관측, 사람 켜기/끄기 100% 보존<br>- 0.8초 이내 동일 이벤트 중복 로깅 억제 |
| [`src/factory_logistics/factory_logistics/web/realtime.js`](file:///Users/igyeongseog/Documents/Codex/2026-09-16/new-chat/outputs/ros2-factory-logistics-sample/src/factory_logistics/factory_logistics/web/realtime.js) | - `phaseNames`: `YIELDING: '지나가는 장애물 양보 중'`으로 갱신<br>- `behaviorNames`: `YIELD: '진로 양보 대기'`로 갱신<br>- `rt.message`의 대기 경과 시간 및 최대 대기 시간 표시 지원 |
| [`tests/test_camera_navigation.py`](file:///Users/igyeongseog/Documents/Codex/2026-09-16/new-chat/outputs/ros2-factory-logistics-sample/tests/test_camera_navigation.py) | - 양보 전용 지도 내부 테스트 픽스처 `yielding_world()` 추가 (지도 경계 False 문제 원천 방지)<br>- 신규 테스트 클래스 `CameraYieldingTests` 추가 (11개 정밀 시나리오 검증, 총 130개 테스트 완료) |

---

## 2. 상태 전환 및 타이머 설계

```mermaid
stateDiagram-v2
    [*] --> MOVING: start(destination, 'global')
    MOVING --> ASSESSING: 장애물 발견 (blocked is not None)
    
    state ASSESSING {
        [*] --> CheckDynamic
        CheckDynamic --> DynamicBlocker: 진로 교차 / 이동 / 접근 중
        CheckDynamic --> StationaryBlocker: 고정 장애물
        StationaryBlocker --> ImmediateDetour: 0.2초 평가 후 대기 없이 우회/재탐색
    }
    
    ASSESSING --> YIELDING: 동적 장애물 확인 (yield_episode 시작)
    
    state YIELDING {
        [*] --> WaitingPassage: 정지 유지 (2.5s 기본 양보, 최대 5.0s)
        WaitingPassage --> MemoryClearing: 장애물 통과 (4프레임·1.2s 빈 공간 확인)
        MemoryClearing --> ConfirmingClear: 기억 해제 후 서로 다른 최신 2프레임 연속 확인
    }

    YIELDING --> MOVING: 통로 확인 완료 (2프레임 연속 + 2.5s 경과)
    YIELDING --> LOCAL_AVOID: 5.0초 만료 (양보 한도 초과) → 가까운 우회
    YIELDING --> REPLAN: 가까운 우회 불가 시 전체 재탐색
    REPLAN --> WAITING: 통로 없음 (NO_ROUTE) → 재관측/안전대기
    
    MOVING --> RECOVERING: 물리 충돌 가드 작동 (0.575m 한계)
    RECOVERING --> BLOCKED: 좌우 회전 관측 후 원인 미확인 시 안전 정지
```

### 1) 대기 에피소드 (`yield_episode`) 데이터 구조
```python
{
    'started_at': now,           # 대기 시작 시각 (기준 시각)
    'base_until': now + 2.5,     # 기본 양보 시간 (약 2~3초)
    'max_until': now + 5.0,      # 에피소드 총 대기 상한 (최대 5초)
    'robot_pose': list(pose),    # 에피소드 시작 시 로봇 좌표
    'clear_confirmations': 0,    # 기억 해제 후 통로 열림 연속 확인 횟수
    'last_confirmed_frame': None,# 마지막으로 확인한 카메라 프레임 시각
    'last_active': now,          # 최근 제어 주기 갱신 시각
    'is_dynamic': is_dynamic,    # 교차/이동/접근 여부
    'logged_yield': False,       # 중복 로그 방지 플래그
    'exhausted': False,          # 5초 한도 소진 여부 (재계획 후 반복 대기 방지)
}
```

### 2) 타이머 리셋 방지 및 우회 실패 후 반복 대기 방지
- **타이머 리셋 방지**: 로봇이 제자리(`math.dist(pose, ep['robot_pose']) < 0.20m`)에 머무는 한, 카메라 지연이나 관측 보류(`camera_wait`), 장애물 ID 교체(`V-1` → `V-2`)가 발생해도 원래의 `max_until = started_at + 5.0` 마감 시각이 유지됩니다.
- **반복 대기 방지**: 5초가 경과하여 `ep['exhausted'] = True`로 표시되면, 우회(`local_detour`) 또는 재탐색(`replan`)이 실패하여 동일 위치에 머물러도 다시 5초 양보 대기에 들어가지 않고 즉시 우회/재탐색 모드를 유지합니다. 로봇이 실제로 0.20m 이상 이동했을 때만 새 에피소드가 생성됩니다.

### 3) 자차 이동 배제 및 접근(`approaching`) 판정
- 로봇의 전진으로 인해 정지된 장애물의 상대 거리가 줄어드는 현상을 방지하기 위해, **현재 로봇 위치 기준 장애물 속도의 방사 성분(`radial_speed = vx * ux + vy * uy`)**을 계산합니다.
- 장애물의 절대 속도가 0.10m/s 이상이고 로봇 쪽 방사 성분이 0.08m/s 이상일 때만 `approaching=True`로 판정합니다. 장애물이 정지하면 즉시 `approaching=False`로 해제됩니다.

### 4) 통로 열림 연속 확인 및 오출발 방지
- 장애물 기억 해제는 기존의 엄격한 4프레임·1.2초 빈 공간 확인 규칙을 그대로 유지합니다.
- 장애물 기억이 해제되어 경로가 열린(`blocked is None`) 시점부터, 서로 다른 최신 프레임(`frame_time > last_confirmed_frame`)에서 2프레임 연속 확인되고 기본 양보 시간(2.5초)이 지나야 비로소 출발합니다.
- 중간에 장애물이 1회라도 다시 감지되면(`blocked is not None`), `hits < 2` 대기 상태라도 `clear_confirmations`가 즉시 0으로 리셋되어 1회 누락으로 인한 조기 출발을 원천 방지합니다.

---

## 3. 실제 실행한 테스트 및 결과

### 실행 명령
```bash
/Users/igyeongseog/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s tests
```

### 테스트 결과 요약
- **총 테스트 수**: 130개 (기존 119개 + 신규 11개)
- **결과**: **130 tests passed, 0 failures, 0 errors (OK)**
- **소요 시간**: 약 8.6초

### 신규 추가된 `CameraYieldingTests` 11개 상세
1. `test_crossing_obstacle_yields_then_resumes_after_clearance_and_two_fresh_frames`: 진로 교차 장애물 양보(2.5초 정지), 4프레임 빈 공간 기억 해제 후 서로 다른 최신 2프레임 확인 및 주행 재개 검증.
2. `test_first_empty_frame_path_no_type_error`: `last_confirmed_frame=None` 상태에서 첫 빈 프레임 검사 시 TypeError 없이 안전하게 실행됨 검증 (GPT 피드백 1 반영).
3. `test_single_missed_detection_does_not_resume_early`: 1프레임 누락 후 다음 프레임 재탐지 시 `clear_confirmations`가 즉시 0으로 리셋되어 조기 출발하지 않음 검증.
4. `test_same_frame_reuse_does_not_increment_clear_count`: 새 카메라 프레임 없이 동일 프레임 시간으로 제어 주기가 돌아도 확인 카운트가 증가하지 않음 검증.
5. `test_crossing_obstacle_blocks_over_5s_transitions_to_detour`: 장애물이 5초 이상 계속 막고 있을 때 최대 5초 시점에 우회(`LOCAL_AVOID` 또는 `REPLAN`)로 전환됨 검증.
6. `test_stationary_obstacle_no_5s_wait`: 고정 장애물은 5초 대기하지 않고 0.2초 짧은 평가 후 즉시 우회 경로를 탐색함 검증.
7. `test_approaching_obstacle_stops_and_ego_motion_does_not_trigger_approaching`: 자차 전진 시 고정 장애물이 접근 중으로 오인되지 않으며, 실제 다가오는 객체만 접근 중으로 감지하여 정지함 검증 (GPT 피드백 2 반영).
8. `test_camera_latency_and_id_switch_preserves_5s_episode_deadline`: 1.8초 카메라 지연 및 장애물 ID 교체 시에도 원래의 5.0초 마감 시각이 유지됨 검증 (GPT 피드백 3 반영).
9. `test_failed_detour_replan_does_not_repeat_yielding_wait_at_same_spot`: 우회 실패 및 실제 `replan()` 호출 후 동일 위치에서 5초 대기 루프가 반복되지 않고 즉시 우회/재탐색 상태를 유지함 검증 (GPT 피드백 3 반영).
10. `test_stale_or_misaligned_frame_halts_immediately_even_if_yield_expired`: 5초 양보 시간이 지났어도 영상이 지연(stale)되었거나 방향이 불일치하면 즉시 정지 유지 검증.
11. `test_interaction_with_collision_recovery_and_yielding`: 물리 충돌 가드 작동 시 `RECOVERING` 회전 관측 및 `BLOCKED` 안전 정지가 정상 작동함 검증.

---

## 4. 설계 가정 및 보수적 결정 사항

1. **단안 카메라 거리 노이즈 허용 한계**: 단안 바닥 투영의 y2 좌표 픽셀 떨림으로 인한 거리 오차를 흡수하기 위해 변위 `disp > 0.12m` 및 속도 `speed >= 0.10m/s`를 유의미한 움직임 임계값으로 적용했습니다.
2. **기본 양보 시간 2.5초 & 최대 대기 5.0초**: 사람의 일반 보행 속도(약 0.4~0.6m/s)에서 폭 1.5m 통로를 가로지르는 데 약 2~3초가 소요되므로, 기본 양보 대기 시간을 2.5초로 설정하고 복잡한 상황에서도 최대 5.0초를 초과하지 않도록 제한했습니다.
3. **기존 기억 해제 조건(4프레임·1.2초) 유지**: 사용자의 지침에 따라 기존 `CameraPerception`의 안정적인 빈 공간 확인 규칙(4프레임·1.2초)을 약화하지 않고 온전히 보존했습니다.
4. **시뮬레이션 숨은 정답 좌표 미사용**: 주행 판단, 장애물 추정, 진로 교차, 양보 타이머 등 모든 판단 로직에서 시뮬레이션 실제 객체(`world.obstacles`)의 좌표나 속도, kind를 전혀 사용하지 않았으며, 오직 카메라 YOLO 탐지 결과와 타임스탬프만 사용했습니다.

---

## 5. 남은 한계 및 GPT 세션 검토 포인트

1. **복잡한 군집 장애물 시나리오 (8개 동적 장애물)**: 여러 명의 사람이 좁은 교차로에서 서로 엉키는 경우 단안 거리 추정 오차와 가림(occlusion)으로 인해 트랙 ID가 교체되거나 거리가 튈 수 있습니다. 현재는 5초 상한 타이머로 안전하게 우회/재탐색으로 빠지도록 설계되어 있으나, 통로가 완전히 없는 극단적 배치에서는 ARRIVED 도달에 추가 재관측 시간이 소요될 수 있습니다.
2. **우회 복귀 지점과의 기하학적 상호작용**: `local_detour`는 기존 경로로 2.25m 이내에 복귀하는 짧은 우회를 시도합니다. 만약 가로지르던 장애물이 우회 복귀 지점 부근에 멈춰 서 있는 경우, 우회 후 다시 새 양보 에피소드가 시작될 수 있습니다. (이것은 안전상 의도된 동작이나 검토가 필요합니다.)
3. **카메라 FPS 및 지연 시간과의 동기화**: 단위 테스트는 타임스탬프를 명시적으로 제어하여 검증했으나, 실제 하드웨어/ROS 운영 시 카메라 추론 속도(YOLO 약 20~50ms)와 제어 주기(10Hz)의 지연 시간에 따라 2프레임 확인에 약 0.2~0.3초가 소요됩니다.
