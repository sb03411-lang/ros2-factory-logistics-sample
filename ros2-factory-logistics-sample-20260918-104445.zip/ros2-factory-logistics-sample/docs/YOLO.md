# YOLO 카메라 탐지와 주행

현재 모델은 창고 합성 영상으로 추가 학습한 YOLO26n이며, 클래스는 `obstacle` 하나다. 사람과 물체 모두 ‘장애물’로 표시한다. COCO 사전 학습 모델만 사용하던 초기 구현은 교체했다.

ROS가 발급한 전방 RGB 프레임을 호스트의 `camera_worker.py`가 분석한다. 모델 입력에 세계의 장애물 좌표나 정답 박스를 넣지 않는다. 반환된 박스만으로 장애물 위치를 추정하고, ROS의 대기·우회·재탐색에 반영한다. 브라우저를 닫아도 분석은 계속된다.

## 표시

- 로봇의 눈 화면에 초록색 ‘장애물 xx%’ 박스를 표시한다.
- ‘YOLO 탐지 표시’는 화면만 숨긴다. 숨겨도 주행 판단은 계속된다. 설정은 localStorage에 저장된다.
- ‘최근 YOLO 분석 프레임 보기’에서 실제 분석 원본과 결과를 확인한다.
- 최신 프레임을 라이브 화면에 투영할 때 카메라 자세와 박스 하단만 사용한다. 움직이는 물체에는 시간차가 있을 수 있다.
- 촬영 후 1.2초가 지난 결과는 라이브 박스에서 제외하며, ROS도 오래된 관측으로 이동하지 않는다.
- 화면 렌더링 목표는 30FPS이며 YOLO 분석 빈도와 별개다.

## 시작

```bash
bash scripts/yolo.sh install  # 최초 의존성 설치
bash scripts/yolo.sh start
```

학습된 단일 클래스 모델 `../../work/yolo-models/warehouse-obstacle.pt`가 필요하다. 설치된 환경에서 `bash scripts/ros2.sh web`도 분석기 실행을 시도한다. `ROS2_YOLO_RUNTIME`으로 작업 경로를 변경할 수 있다. 로그는 `../../work/camera-worker.log`다. 모델이 없거나 분석이 끊기면 자율 주행은 카메라 대기 상태가 된다.

새 UI는 과거 8768 `/detect` 서버를 사용하지 않는다. 웹 서버의 `/api/vision/claim`, `/api/vision/result`, `/api/vision/status`로 ROS와 분석기·화면을 연결한다.

설계와 한계: [카메라 전용 주행](CAMERA_ONLY.md). 초기 모델의 검증 기록: [YOLO 적용 가능성 검토](YOLO_FEASIBILITY.md).

배포용 학습 가중치는 `models/warehouse-obstacle.pt`에도 포함한다. 작업 경로의 모델이 없으면 이 파일을 사용한다.
