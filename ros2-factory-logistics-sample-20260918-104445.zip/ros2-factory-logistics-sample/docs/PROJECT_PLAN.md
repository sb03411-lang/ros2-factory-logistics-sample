# ROS 2 Factory Logistics Sample — 프로젝트 구상

## 목표

가상의 물류 로봇 한 대가 창고와 생산라인 사이를 이동하는 샘플이다. 공장 관제에서 내려오는 작업이 ROS 2 Action의 목표·진행 상황·결과로 어떻게 표현되는지 배우는 것이 목적이다.

**시나리오:** `warehouse`에서 시작 → 작업 `JOB-001`로 `line_a` 이동 → 완료 보고 → 작업 `JOB-002`로 `warehouse` 복귀.

물건을 실제로 싣거나 내리는 동작은 구현하지 않는다. 2D 좌표를 일정 속도로 갱신하는 이동 모형이며, 센서 기반 주행·장애물 회피는 후속 단계다.

**현재 상태(2026-09-17):** Mac arm64에 전용 Colima·Docker 환경을 구성하고, Ubuntu 24.04/ROS 2 Jazzy에서 두 패키지를 실제 빌드했다. Action 목표·피드백·결과·취소, 요청 거절, 상태 Topic 수신, 취소 후 새 작업의 통합 검사를 통과했다. 세부 환경과 확인 범위는 [검증 기록](VERIFICATION.md)에 정리한다.

## 개발 범위

| 구성 | 책임 |
| --- | --- |
| `factory_interfaces` | `TransportJob.action`으로 작업 요청·피드백·결과 정의 |
| `factory_logistics`의 `task_dispatcher` | 순차 작업 요청, 접수 여부와 진행·완료 출력 |
| `factory_logistics`의 `simulated_robot` | 요청 검증, 이동 시뮬레이션, Action 결과와 상태 Topic 발행 |
| ROS 독립 Python 코어 | 좌표 계산, 작업 상태, 취소, 중복 ID와 동시 작업 처리 |
| 공용 station 설정 | 창고·생산라인 이름과 좌표 |

```mermaid
flowchart LR
    A[task_dispatcher] -->|TransportJob Action 목표| B[simulated_robot]
    B -->|피드백 · 결과| A
    B --> C[ROS 독립 이동 코어]
    D[station 설정] --> C
    B -->|상태 Topic| E[ros2 topic echo]
```

이 구조에서 dispatcher는 학습용 상위 작업 요청기다. 실제 MES·WMS·FMS 제품이나 VDA 5050 관제를 구현한 것은 아니다.

## 기술 선택

- 실제 ROS 실행 환경: **Ubuntu 24.04 + ROS 2 Jazzy + Python/rclpy**. Jazzy를 고정해 실행 지침을 일관되게 유지한다. 최신 배포판이라는 의미는 아니다.
- Mac 기본 실행 방법: `scripts/ros2.sh`로 전용 Colima VM과 공식 `ros:jazzy-ros-base-noble` 기반 컨테이너 실행. Ubuntu 직접 설치 방법도 제공한다.
- macOS 미리보기: Python 표준 라이브러리만으로 동일 이동 코어 실행. ROS 통신을 검증하는 모드는 아니다.
- 장시간 작업: ROS 2 **Action**. goal 접수, 주기적 feedback, 완료 result, 취소를 다룬다.
- 지속적인 위치·상태 관찰: ROS 2 **Topic**.
- MQTT·OPC UA·Nav2·Gazebo·웹 화면은 초기 범위에 포함하지 않는다.

## 동작 정책

1. 한 번에 한 작업만 실행한다. 실행 중 추가 요청은 거절한다.
2. 등록되지 않은 목적지와 빈 작업 ID는 거절한다.
3. 접수한 작업 ID를 프로세스 메모리에 보관해 같은 ID의 재실행을 거절한다. 프로세스 재시작 이후의 영속적인 중복 방지는 후속 범위다.
4. 취소는 현재 위치에서 시뮬레이터의 이동 갱신을 멈추고 취소 결과를 돌려준다. 새 ID의 다음 작업을 받을 수 있다.
5. 좌표계는 `map`, 거리 단위는 m로 통일한다.

## 완료 기준

- 창고 → 생산라인 → 창고의 두 작업이 순차 완료된다.
- 이동 중 위치와 진행 상태를 확인할 수 있다.
- 잘못된 목적지·빈 ID·중복 ID·실행 중 추가 요청을 처리해 기존 작업을 훼손하지 않는다.
- 취소 후 이동이 멈추고 새 작업이 실행된다.
- ROS 없는 코어 검증과 실제 ROS 빌드·통신 검증을 구분해 기록한다.

## 다음 확장 단계

| 단계 | 확장 | 확인할 결과 |
| --- | --- | --- |
| 1 — 완료 | 현재 샘플의 ROS Action 실행 | 실제 노드 간 목표·피드백·결과·취소 및 상태 Topic 검증 |
| 2 | RViz 시각화 | 지도 좌표에서 이동 확인 |
| 3 | Gazebo + Nav2 | 센서 기반 위치 추정·경로 계획·장애물 회피 |
| 4 | MQTT 작업 연동 | 외부 작업 ID와 ROS Action 연결, 연결 복구와 중복 정책 |
| 5 | 가상 PLC/OPC UA | 설비 준비 상태 확인 후 인계 절차 |
| 6 | 여러 로봇·영속 작업 저장 | 배차·작업 재개·교통 관리 정책 |

2~6단계는 별도 구현·검증이 필요하다. 실제 장비로 확장할 때는 구동기 인터페이스와 현장 안전 제어를 별도로 설계한다.

## 공식 참고 자료

- [ROS 2 Jazzy Ubuntu 지원 환경](https://docs.ros.org/en/jazzy/Installation/Alternatives/Ubuntu-Install-Binary.html)
- [Topic·Service·Action 선택](https://docs.ros.org/en/jazzy/How-To-Guides/Topics-Services-Actions.html)
- [공식 ROS Docker 이미지와 지원 아키텍처](https://github.com/docker-library/official-images/blob/master/library/ros)
- [Nav2](https://nav2.org/)

작성 기준: 2026-09-17.
