# 웹 관제

## 실행

프로젝트 루트에서 `bash scripts/ros2.sh web`을 실행하고 http://localhost:8765 를 연다. 현재 빌드에는 웹 UI가 포함되어 있다. 처음 빌드하거나 소스를 변경한 경우 `bash scripts/ros2.sh build`로 갱신한다.

- 시작: `bash scripts/ros2.sh web`
- 종료: `bash scripts/ros2.sh stop`
- 서버만 종료: `bash scripts/ros2.sh down`
- 실제 통합 검사: `python3 scripts/web_smoke.py` (실행 중인 시뮬레이터를 이동시킨다)

`web`은 로봇과 웹 브리지를 같은 컨테이너에서 실행한다. 기존 CLI 전용 서버가 있으면 진행 중인 작업을 끝낸 뒤 `down` → `web`으로 전환한다. `up`으로 별도 로봇을 중복 실행하지 않는다.

## 화면과 제어

1. 녹색 **ROS 연결됨** 표시를 확인한다.
2. 목적지와 작업 ID를 선택하고 **이동 시작**을 누른다. ID는 자동 생성되며 직접 수정할 수 있다.
3. 지도의 로봇 위치와 남은 거리가 실제 상태 Topic에 따라 갱신된다.
4. **현재 작업 취소**는 해당 ROS Goal UUID를 취소한다. `취소` 상태가 수신되어야 취소 완료다.
5. 작업 기록에서 완료·취소·실패를 필터링할 수 있다. CLI에서 제출한 작업도 감지하여 표시한다.

한 번에 로봇 한 대, 작업 하나를 처리한다. 이미 접수된 작업 ID는 로봇 프로세스가 재시작되기 전까지 재사용할 수 없다. 현재 위치와 같은 목적지를 선택하면 즉시 완료될 수 있다.

지도는 실제 A* 통로 경로를 표시한다. `navigation_map.json`의 벽/통로 데이터를 도면 이미지, 웹 지도, 경로 계획, 자동/수동 충돌 검사가 공유한다. 로봇 반경 0.12m만큼 벽을 확장하고 이동 선분 전체를 검사한다. 수동 입력으로 벽에 접근하면 위치를 유지하고 충돌 차단 상태와 ROS 경고를 표시한다. Nav2·센서·동적 장애물·물리 시뮬레이션은 아직 없으며 실제 설비의 비상 정지 기능이 아니다.

## 구성

### 방향키 수동 조작

**수동 조작 켜기**를 선택한 뒤 방향키를 누르고 있으면 지도 좌표 기준으로 이동한다. ↑/↓는 Y축, ←/→는 X축이다. 회전·전진을 사용하는 차동구동 모델이 아닌 2D 평면 이동이며, 대각선도 총 속도 0.5 m/s를 유지한다. 화면의 방향 버튼은 마우스·터치로 누르고 있는 동안 동작한다.

키 해제, 중앙 정지 버튼, Space, 브라우저 포커스 이탈, 탭 숨김에 정지를 요청한다. 입력창에서는 방향키를 가로채지 않는다. ROS 노드가 0.35초 동안 새 명령을 받지 못하면 독립적으로 정지한다. 이동 범위는 X 0~3m, Y 0~2m다. 자동 운반 중 수동 명령은 거절하며, 수동 이동 중 자동 운반도 거절한다. 자동 작업을 다시 요청하려면 수동 조작 체크를 해제한다.

브라우저는 `POST /api/teleop`에 `x`, `y`(-1/0/1), `issued_at`(Unix 초)을 보내며 브리지는 `/factory/cmd_vel`에 `geometry_msgs/TwistStamped`를 발행한다. 브리지에서 오래된 HTTP 입력을 거절하고, 로봇에서도 오래된 ROS 메시지와 과속 명령을 거절한다. 로컬 호스트와 VM 시각 차이는 최대 0.5초를 허용한다.

### ROS 원본 로그

하단 **ROS 원본 로그**는 실제 `/rosout`의 `rcl_interfaces/Log`를 구독한다. 노드가 발행한 시각, 레벨, 노드 이름, 원문을 표시하며 행 위에 마우스를 놓으면 소스 파일·행·함수를 확인할 수 있다. 레벨 필터, 노드/메시지 검색, 표시 일시정지를 지원한다. 표시를 일시정지해도 백엔드는 최근 300개를 계속 수집한다. 기존 이벤트 로그와 별도로 유지한다.

모든 콘솔 출력이 `/rosout`인 것은 아니다. 이 패널에는 일반 stdout/stderr, launch 자체의 출력, rosout을 비활성화한 노드의 출력은 포함하지 않는다. ROS 기본 INFO 설정에서는 DEBUG가 발행되지 않을 수 있다. 로그와 기록은 서버 재시작 시 초기화된다.

동작 로그는 `simulated_robot`의 INFO 레벨이다. 수동 시작·방향 변경에는 방향과 속도, 정지에는 마지막 좌표를 남기고, 자동/수동 이동 중에는 1초 간격으로 좌표와 남은 거리를 기록한다. 자동 운반 접수·도착·취소도 기록한다. WARN 이상 필터에서는 이 로그들이 숨겨지므로 **전체 로그 보기**를 누르면 검색·레벨 필터·표시 일시정지가 해제된다. 패널 위에 현재 수신·필터·일시정지 상태가 표시된다.

```text
브라우저 HTML/CSS/JS
  ├─ GET /api/state (응답 후 350ms 간격)
  ├─ POST /api/jobs
  └─ POST /api/cancel
            ↓
Python HTTP 서버 + ROS WebBridge
  ├─ ActionClient /factory/transport
  ├─ CancelGoal /factory/transport/_action/cancel_goal
  └─ Topic 구독 /factory/robot_state
            ↓
SimulatedRobot (ROS 2 Jazzy)
```

추가 웹 프레임워크나 npm 설치가 필요 없다. Python 표준 HTTP 서버와 기존 rclpy를 사용한다. 정적 파일은 ROS Python 패키지에 함께 설치된다.

| API | 내용 |
|---|---|
| `GET /api/state` | 연결 상태, 로봇, 목적지, 제어 가능 여부, 최근 작업·이벤트 |
| `POST /api/jobs` | `{"job_id":"WEB-001","destination":"line_a"}` |
| `POST /api/cancel` | `{"job_id":"WEB-001"}` |
| `GET /health` | HTTP 서버 생존 여부. ROS 연결은 `/api/state.connected` 확인 |

POST는 `Content-Type: application/json`, `X-Factory-Control: 1` 헤더가 필요하다. 상태 코드: 접수 `202`, 입력 오류 `400`, 중복·실행 중·취소 대상 변경 `409`, ROS 연결 끊김 `503`. `202`는 작업 완료가 아니며, `pending: true`이면 접수 응답도 아직 대기 중이다. 결과는 상태·작업 기록으로 확인한다.

로봇 상태를 2초 이상 받지 못하거나 Action 서버가 사라지면 제어를 비활성화한다. HTTP 연결이 끊겨도 마지막 수신 위치를 보존하고 연결 끊김 경고를 표시한다. 작업 기록은 브리지 메모리의 최근 100개, 이벤트는 최근 50개이며 서버 재시작 시 초기화된다.

포트는 호스트 `127.0.0.1:8765`에만 공개된다. Host 및 Origin 검증, JSON 전용 POST, 제어 헤더, CSP가 적용된다. 인증·DB·여러 사용자 권한 관리가 없는 로컬 학습용 서버다.

## 검증

2026-09-17, macOS + Colima arm64 / Ubuntu 24.04 / ROS 2 Jazzy에서 실행했다.

- 실제 HTTP → ROS 작업 접수, 좌표 변화, 도착 확인
- 잘못된 목적지, 중복 ID, 이동 중 추가 요청 거절
- 정확한 작업 UUID 취소, 취소 뒤 위치 정지, 이후 작업 성공
- 외부 Origin 및 제어 헤더 없는 POST 거절
- 브라우저 버튼을 통한 작업 요청·취소
- 새로고침 후 작업 기록 유지, 취소 필터 동작, JavaScript 오류 없음
- 390px 모바일 가로 넘침 없음, 연결 차단 시 제어 잠금 및 복구
- CLI 외부 작업 감지 및 웹 취소 후 위치 정지 확인
- 기존 ROS Action/Topic 회귀 검사 통과
- 수동 이동·대각선 속도·범위 제한, 자동/수동 상호 배제, 오래된 입력 거절
- ROS watchdog 자동 정지, 브라우저 keydown/keyup 및 blur 이벤트 후 실제 좌표 정지
- ROS 원문 수신, 검색·레벨 필터·표시 일시정지/재개, 390px 모바일 화면

추가 검증은 `python3 scripts/teleop_smoke.py`로 재실행한다(시뮬레이터 이동 포함). [수동 조작·ROS 로그 검사](evidence/teleop-smoke.log), [ROS 회귀 검사](evidence/ros-teleop-regression.log). 핵심 로직 단위 검사는 15개 통과했다.

CLI가 완료를 기다리는 작업을 웹에서 취소하면 CLI는 ROS 상태 5(CANCELED)를 받고 종료 코드 1을 반환한다. 운반이 완료되지 않았다는 기존 dispatcher의 동작이며, 웹에서는 `취소`로 표시된다.

로그: [웹 통합 검사](evidence/web-smoke.log), [ROS 회귀 검사](evidence/ros-web-regression.log), [브라우저 검증](evidence/web-browser.log).

![웹 관제 화면](evidence/web-ui.png)

![방향키 조작과 ROS 원본 로그](evidence/web-teleop-rosout.png)

## 사용자 지도 지원 업데이트

이제 고정 샘플 외에 웹에서 작성한 사용자 지도를 지원합니다. 도면 편집에서 저장하면 ROS 지도·웹 표시·Codex 입력 PNG를 함께 갱신하며 이전 AI 계획은 만료됩니다. 상세 제한과 저장 방식은 [도면 편집](MAP_EDITOR.md)을 참고하세요.

## LLM 판단 로그 패널

`LLM 판단 로그`는 `/api/state`의 `ai.logs`를 표시한다. 출처와 요청 ID별 필터, 검색, 일시정지, 전체 보기, 항목별 상세 펼치기를 지원한다. LLM이 반환한 설명·좌표와 검증기의 등록 좌표·경로 판정을 구분한다. ROS 실행 요청과 완료·취소·실패 결과를 함께 기록한다. 인증용 토큰이나 CLI 원본 출력은 전달하지 않는다. 최근 200개를 메모리에 유지하며 서버 재시작 시 초기화된다.
