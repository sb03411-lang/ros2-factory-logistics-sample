# 검증 기록

검증일: 2026-09-17.

**실제 ROS 2 빌드와 노드 간 통신 검증을 완료했다.** Mac의 전용 Linux VM에서 Ubuntu 24.04/ROS 2 Jazzy 컨테이너를 빌드하고, Action·Topic을 사용하는 통합 검사와 작업 요청·취소·종료 명령을 실행했다. 로봇의 이동 모델은 Python으로 계산하는 2D 경유점 이동이다. 정적 지도에서 A*가 벽을 우회하고 이동 선분에 대해 충돌을 검사한다.

최종 상태: 서버 컨테이너를 제거하고 **09:17:44 KST에 VM을 정상 중지했다.** VM 환경과 빌드한 이미지 캐시는 보존되어 있다. `demo` 또는 `up`을 실행하면 VM이 자동으로 다시 시작된다.

## 실제 실행 환경

| 항목 | 확인한 환경 |
| --- | --- |
| 호스트 | macOS 26.2, arm64 |
| VM 도구 | Colima 0.10.3, Lima 2.2.0 |
| VM 프로필 | `ros2`, VZ 가상화, native aarch64 |
| VM 설정 | CPU 2개, 메모리 4 GiB, 데이터 디스크 20 GiB |
| Docker | 클라이언트 29.8.0, 서버 29.5.2, Buildx 0.37.0 |
| 컨테이너 | Ubuntu 24.04, ROS 2 Jazzy, Python 3.12.3 |
| 런타임 경로 | `/Users/igyeongseog/Documents/Codex/work/r2` |

Colima·Docker·Buildx를 Homebrew로 설치했다. 전용 `COLIMA_HOME`, `DOCKER_CONFIG`, `DOCKER_HOST`를 사용하며 전역 Docker 기본 context·셸 시작 파일·사용자 SSH 설정은 변경하지 않았다. VM에는 호스트 폴더를 마운트하지 않고, 소스를 Docker 이미지에 복사했다.

## ROS 빌드·통합 검증 결과

| 항목 | 실제 결과 |
| --- | --- |
| Dockerfile 이미지 빌드 | 종료 코드 `0` |
| `colcon build` | `factory_interfaces`, `factory_logistics` 두 패키지 빌드 성공, 10.1초 |
| `ros2 interface show factory_interfaces/action/TransportJob` | 생성된 goal·result·feedback 필드 확인 |
| `bash scripts/ros2.sh test` | 실제 ROS 통합 검사 성공, 종료 코드 `0` |
| 컨테이너 내부 코어 단위 테스트 | 13개 테스트 통과 |

실제 출력: [ROS 통합 검사 로그](evidence/ros-smoke.log), [왕복 demo 로그](evidence/ros-demo.log).

`scripts/ros_smoke.py`는 서버를 별도 프로세스로 시작하고 실제 ROS Action·Topic 통신으로 다음을 확인했다.

1. 창고 → 생산라인 A → 창고 왕복과 `SUCCEEDED` 결과
2. 이동 중 feedback 수신 및 pose의 `map` 좌표계
3. 상태 Topic 수신과 창고 복귀 좌표 `(0.0, 0.0)`
4. 빈 ID·미등록 목적지·중복 ID·실행 중 추가 요청 거절
5. 이동 중 취소와 `CANCELED` 결과, 후속 상태 메시지의 위치 유지
6. 취소 후 새 작업 성공 및 검사 종료 시 서버 정리

검사는 검사 프로세스와 자식 서버에 한해 20~80 중 임의 ROS domain을 선택하고 localhost 통신을 사용한다. 실행 중 `ROS_LOCALHOST_ONLY`가 deprecated라는 경고가 출력되었지만, 설정은 적용되었고 검사는 오류 없이 통과했다.

## Mac 운영 명령 검증

| 명령 | 실제 결과 |
| --- | --- |
| `bash scripts/ros2.sh demo` | 종료 코드 `0`; `JOB-001`의 `line_a` 도착, `JOB-002`의 `warehouse` 복귀 |
| demo 종료 처리 | dispatcher 정상 종료, simulated robot의 SIGINT 정상 종료 |
| `bash scripts/ros2.sh up` | 백그라운드 서버 시작, Action discovery 성공 |
| `bash scripts/ros2.sh state` | 최초 `IDLE` 상태 수신 |
| `bash scripts/ros2.sh send --job-id USER-001 --destination line_b` | 도착 결과 `SUCCEEDED` |
| `bash scripts/ros2.sh send --job-id USER-CANCEL --destination warehouse --cancel-after 1` | 이동 중 취소 성공 |
| 취소 후 `bash scripts/ros2.sh state` | `CANCELED`와 위치를 포함하는 전체 JSON 수신 |
| `bash scripts/ros2.sh down` | 종료 코드 `0`, 샘플 서버 컨테이너 제거 |
| `bash scripts/ros2.sh stop` | 종료 코드 `0`, 전용 VZ VM 정상 중지 |
| 최종 `bash scripts/ros2.sh status` | VM 중지 상태 확인 |

`up`의 서버는 Python 모듈을 컨테이너의 주 프로세스로 실행한다. `state`는 10초 대기 제한과 전체 문자열 출력을 사용한다. 컨테이너 소유권 충돌 같은 오류 분기를 모두 실험한 것은 아니다.

## 재현 명령

이 Mac에서는 프로젝트 루트에서 전용 runtime을 선택하는 helper를 사용한다.

```bash
bash scripts/ros2.sh build
bash scripts/ros2.sh test
bash scripts/ros2.sh demo
bash scripts/ros2.sh stop
```

Docker 기본 context는 변경하지 않았으므로 다른 터미널의 일반 `docker` 명령이 이 전용 VM을 가리킨다고 가정하지 않는다. 다른 Docker 환경 및 Ubuntu 직접 실행 방법은 [README](../README.md)에 있다.

## 코어·정적 검증 기록

ROS 환경 설치 전에 macOS/Python 3.9.6에서 확인한 결과도 보존한다.

| 항목 | 결과 |
| --- | --- |
| `python3 scripts/local_demo.py` | 창고 → 생산라인 A → 창고 왕복 완료, 최종 `(0.0, 0.0)` |
| `python3 -m unittest discover -s tests -v` | 13개 테스트 통과 |
| Python 파일 AST 파싱 | 9개 파일 문법 검사 통과 |
| ROS `package.xml` 파싱 | 2개 파일 XML 문법 검사 통과 |
| JSON 목적지 설정 | 파싱 성공 |
| `bash -n scripts/entrypoint.sh` | 셸 문법 검사 통과 |
| Python 패키지 `setup.py build` | Python 모듈과 `stations.json` 포함 확인 |
| 위 빌드 산출물에서 코어 로딩 | 소스 폴더에 의존하지 않고 설정을 읽어 이동 완료 |

단위 테스트는 정상·대각선 이동, 도착 시 초과 이동 방지, 현재 위치 목적지, 잘못된 요청, 중복 ID, 실행 중 요청 거절, 취소 후 위치 유지와 새 작업, 실패 후 복구, 속도·좌표·시간 입력 검증을 포함한다.

ROS 어댑터는 별도 정적 리뷰에서 요청 수락 예약, 취소 상태 전이, callback group과 executor 구성, 요청기의 종료 코드, 검사 스크립트의 서버 정리를 확인했다. 정적 리뷰는 실제 ROS 통신 검증을 대체하지 않는다.

Mac helper의 셸 문법과 `help` 출력을 확인했고, 긴 runtime 경로가 Lima의 UNIX 소켓 제한을 넘으면 실행 전에 거절되는 것을 확인했다. 중지된 VM을 `status`로 조회할 때 정상 안내를 표시하는 것도 확인했다.

## 현재 범위와 남은 검증

- 실제 ROS 2 노드·생성된 Action 인터페이스·Topic 통신은 검증했다. macOS에 ROS를 직접 설치한 방식은 검증하지 않았다.
- 검증 아키텍처는 arm64다. amd64 이미지 빌드와 네이티브 Ubuntu 호스트 실행은 별도로 수행하지 않았다.
- RViz·Gazebo GUI, Nav2, SLAM, 센서 인식, 충돌 회피, 실제 로봇 구동과 적재·하역은 구현하지 않았다.
- MQTT·OPC UA·VDA 5050 및 MES·WMS·PLC 연동은 구현하지 않았다.
- 호스트·다른 컨테이너·외부 장비를 연결한 ROS 네트워크 구성은 검증하지 않았다.
- 취소는 소프트웨어 시뮬레이션의 이동 중지다. 실제 장비의 안전 정지 기능을 의미하지 않는다.

## 2026-09-17 도면 편집 및 LLM 판단 로그

- 단위 테스트 37개 통과: `evidence/decision-unit.log`.
- 실제 ROS Action/Topic 회귀 통과: `evidence/map-editor-ros.log`.
- HTTP 운반·취소 및 방향키·watchdog·ROS 원본 로그 회귀 통과: `evidence/decision-web-regression.log`, `evidence/decision-teleop-regression.log`.
- 사용자 5×4m 지도, 사각형 장애물 배치, 이미지 해시 일치, 실제 ROS 우회, 잘못된 지도/이동 중 변경 거절, 실제 Codex의 변경된 도면 인식, 이전 계획 만료: `evidence/map-editor-smoke.log`.
- 컨테이너 교체 후 사용자 지도 유지 확인: `evidence/map-editor-persistence.log`.
- 실제 Codex 출하장 Z 불명확 판정 및 실행 보류·거절 기록, 생산라인 B 판단·좌표/경로 검증·ROS 도착 기록 확인: `evidence/decision-smoke.log`, `evidence/decision-logs.json`.
- 브라우저에서 도면 좌표 입력·드래그·삭제·되돌리기·저장 확인. 테스트용 지도는 샘플 지도로 복원함.
- 판단 로그 출처 필터 2개 LLM 항목 확인, 요청 ID·출하장 검색으로 1개 항목 확인, 모델 좌표 상세 보기 확인.
- 표시 일시정지 중 화면은 5개 항목 유지, 수신 로그는 15개로 증가 확인. 재개 후 최신 내역 표시.
- 1440px 데스크톱과 390px 모바일 표시 확인. 모바일 문서 가로 너비 390px, JavaScript 오류 없음.
- 화면 증거: `evidence/map-editor-desktop.png`, `evidence/map-editor-mobile.png`, `evidence/decision-llm-ui.png`, `evidence/decision-mobile.png`.

최종 실행 상태: http://localhost:8765, 기본 샘플 도면 적용. 검증용 실제 Codex 이동이 생산라인 B에서 완료됨. 판단 로그는 서버 메모리의 최근 200개이며 재시작하면 초기화됨.

## 2026-09-17 실시간 판단·동적 장애물·UI 개편

- 단위 테스트 48개 통과: 오래된/중복/정지 이후 응답, 관측 후 장애물 추가, 이동 중 차단, 왕복 충돌 검사, 40번째 관측 처리, 이전 운반 기록 보존 포함 (`realtime-unit.log`).
- 실제 Codex가 새 관측마다 최대 0.5m 행동을 선택하여 10회 관측 후 생산라인 B 도착. 창고 → 왼쪽 통로 → 위쪽 통로로 이동. 왕복 장애물이 존재하며 판단 중 위치 고정과 장애물 간격 검사 통과 (`realtime-live.log`, `realtime-trace.json`, `realtime-decisions.json`).
- 이미지 관측 후 장애물을 새로 배치하여 기존 판단의 이동을 거절하고 재관측하는 실제 통합 검증 통과. 자동 운반·수동 조작·지도 변경 동시 실행 거절, 정지 뒤 늦은 응답 실행 차단 확인 (`realtime-guard.log`).
- ROS Action/Topic, HTTP 운반·취소, 수동 watchdog·ROS 로그 회귀 모두 통과 (`realtime-ros-regression.log`, `realtime-web-regression.log`, `realtime-teleop-regression.log`).
- 브라우저 검증: 왕복 장애물 생성·이동, 드래그로 X 1.0 → 약 0.697m 반영, 지도 가장자리 드래그 보정, 4개 탭 전환, 관측 이미지 ID 일치, 출처별 판단 로그 확인.
- 390px 모바일 가로 넘침 없음. 고정 조작 바에서 창고 목표로 실제 Codex 주행 시작 및 정지 확인. JavaScript 오류 없음. 최종 실행 자산과 저장된 소스 일치 확인.
- 사용자가 수정한 고정 지도 `map-8cd7cda9834686ca`와 벽 2개 보존. 실시간 검증 후 로봇 정지. 최종 상태는 `realtime-final-state.json` 참조.

화면 증거: `evidence/realtime-running.png`, `evidence/realtime-mobile.png`, `evidence/realtime-mobile-controls.png`. 동적 장애물과 실시간 실행 상태는 메모리에 있으며 재시작 시 초기화됩니다.
