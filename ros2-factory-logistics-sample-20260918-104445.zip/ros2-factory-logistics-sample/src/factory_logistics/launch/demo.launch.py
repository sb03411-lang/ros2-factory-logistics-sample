"""Run the robot and two default jobs, then shut down the launch session."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    robot = Node(
        package="factory_logistics",
        executable="simulated_robot",
        output="screen",
        parameters=[{"speed": ParameterValue(LaunchConfiguration("speed"), value_type=float)}],
    )
    dispatcher = Node(
        package="factory_logistics",
        executable="task_dispatcher",
        output="screen",
        arguments=["--timeout", "20"],
    )
    stop_after_jobs = RegisterEventHandler(
        OnProcessExit(
            target_action=dispatcher,
            on_exit=[EmitEvent(event=Shutdown(reason="Task dispatcher exited"))],
        )
    )
    return LaunchDescription(
        [
            DeclareLaunchArgument("speed", default_value="1.0", description="Robot speed in m/s"),
            stop_after_jobs,
            robot,
            dispatcher,
        ]
    )
