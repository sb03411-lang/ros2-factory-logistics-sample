"""Run the robot and local web bridge together; stop if either process exits."""
from launch import LaunchDescription
from launch.actions import EmitEvent, RegisterEventHandler, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.parameter_descriptions import ParameterValue
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch_ros.actions import Node


def generate_launch_description():
    robot = Node(package='factory_logistics', executable='simulated_robot', output='screen', parameters=[{'initial_pose':ParameterValue(LaunchConfiguration('initial_pose'),value_type=str)}])
    web = Node(package='factory_logistics', executable='factory_web', output='screen')
    guards = [RegisterEventHandler(OnProcessExit(target_action=node,
              on_exit=[EmitEvent(event=Shutdown(reason='Web stack process exited'))])) for node in (robot, web)]
    return LaunchDescription([DeclareLaunchArgument('initial_pose',default_value='[]')]+guards + [robot, web])
