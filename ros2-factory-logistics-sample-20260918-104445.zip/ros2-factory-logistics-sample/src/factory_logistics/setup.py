from glob import glob

from setuptools import find_packages, setup


PACKAGE_NAME = "factory_logistics"

setup(
    name=PACKAGE_NAME,
    version="0.1.0",
    packages=find_packages(exclude=["test", "tests"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + PACKAGE_NAME]),
        ("share/" + PACKAGE_NAME, ["package.xml"]),
        ("share/" + PACKAGE_NAME + "/launch", glob("launch/*.launch.py")),
    ],
    package_data={PACKAGE_NAME: ["stations.json", "navigation_map.json", "web/*"]},
    install_requires=["setuptools"],
    zip_safe=False,
    maintainer="Sample Maintainer",
    maintainer_email="maintainer@example.com",
    description="ROS 2 transport dispatcher and simulated factory robot",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "simulated_robot = factory_logistics.simulated_robot:main",
            "task_dispatcher = factory_logistics.task_dispatcher:main",
            "factory_web = factory_logistics.web_bridge:main",
        ],
    },
)
