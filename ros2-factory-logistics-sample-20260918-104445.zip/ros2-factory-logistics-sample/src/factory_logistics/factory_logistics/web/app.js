'use strict';
const $ = id => document.getElementById(id);
const states = {REACTIVE:'실시간 판단',MANUAL:'수동 이동',IDLE:'대기 중',SUBMITTING:'접수 중',RUNNING:'이동 중',SUCCEEDED:'완료',CANCELED:'취소',FAILED:'실패',REJECTED:'거절'};
let snapshot = null, busy = false, lastHistory = '', lastEvents = '';
const label = id => snapshot?.stations.find(s => s.id === id)?.label || '—';
const time = value => new Date(value).toLocaleTimeString('ko-KR',{hour12:false});
const newId = () => 'WEB-' + Date.now().toString(36).toUpperCase();
$('job-id').value = newId();
function notice(message, error=false){$('notice').textContent=message;$('notice').classList.toggle('error',error);}
function controls(){ $('submit').disabled=busy||!snapshot?.can_submit||$('manual-enable').checked; $('cancel').disabled=busy||!snapshot?.can_cancel; manualControls(); renderAI(); }
function text(tag, value, className){const el=document.createElement(tag);el.textContent=value;if(className)el.className=className;return el;}
function renderHistory(){
 const jobs=snapshot?.jobs||[], filter=$('history-filter').value;
 $('job-count').textContent=jobs.length;
 const visible=jobs.filter(j=>filter==='ALL'||j.state===filter||(filter==='FAILED'&&j.state==='REJECTED'));
 $('jobs').replaceChildren(...visible.map(j=>{const row=document.createElement('tr'),id=text('td',j.job_id);id.append(text('small',time(j.started_at)));const status=document.createElement('td');status.append(text('span',states[j.state]||j.state,'status '+j.state));row.append(id,text('td',label(j.destination)),text('td',j.source==='CODEX'?'Codex AI':j.source==='WEB'?'웹 UI':'ROS 외부'),status);return row;}));
 $('empty').hidden=visible.length>0;
 $('empty').replaceChildren(text('span',jobs.length?'조건에 맞는 작업이 없습니다.':'아직 작업 기록이 없습니다.'),text('small','새 운반 작업을 요청하면 이곳에 표시됩니다.'));
}
function mapProjection(geometry){
 const [x0,y0,x1,y1]=geometry.outer_bounds, scale=Math.min(760/(x1-x0),370/(y1-y0));
 const left=(900-(x1-x0)*scale)/2, bottom=445;
 return {scale, point:(x,y)=>[left+(x-x0)*scale,bottom-(y-y0)*scale], inverse:(x,y)=>[(x-left)/scale+x0,(bottom-y)/scale+y0]};
}
function svgElement(name,attrs={}){const el=document.createElementNS('http://www.w3.org/2000/svg',name);for(const [key,value] of Object.entries(attrs))el.setAttribute(key,value);return el;}
function mapRect(bounds,projection,fill,stroke){const [a,b,c,d]=bounds,[x,y]=projection.point(a,d);return svgElement('rect',{x,y,width:(c-a)*projection.scale,height:(d-b)*projection.scale,fill,stroke});}
function drawMap(){
 const robot=snapshot?.robot;if(!robot)return;
 const geometry=snapshot.navigation, projection=mapProjection(geometry), point=projection.point;
 if($('map-geometry').dataset.map!==geometry.id){
  const rectangles=[mapRect(geometry.outer_bounds,projection,'#252f40','#718bac'),mapRect(geometry.center_bounds,projection,'#354d6c','#d27979')];
  for(const wall of geometry.walls){const r=geometry.robot_radius+(geometry.robot_clearance||0);rectangles.push(mapRect([wall[0]-r,wall[1]-r,wall[2]+r,wall[3]+r],projection,'#283b55','#56708d'),mapRect(wall,projection,'#14243b','#8295ad'));}
  $('map-geometry').replaceChildren(...rectangles);$('map-geometry').dataset.map=geometry.id;
  $('map-stations').replaceChildren(...snapshot.stations.map(s=>{const [x,y]=point(s.x,s.y),g=svgElement('g');g.append(svgElement('circle',{cx:x,cy:y,r:7,fill:'#8fb2ff'}));const t=svgElement('text',{x,y:y+27,'text-anchor':'middle',fill:'#e8effb','font-size':15});t.textContent=s.label;g.append(t);return g;}));
  $('map-scale').textContent=`${geometry.center_bounds[2]} × ${geometry.center_bounds[3]} m · 장애물 ${geometry.walls.length}개`;
  $('floorplan-image').src='/floorplan.png?map='+encodeURIComponent(geometry.id);$('map-revision').textContent=geometry.id+' · 적용된 ROS 지도';
 }
 const selected=currentView==='live'?$('rt-destination').value:document.querySelector('input[name="destination"]:checked').value;
 const plan=snapshot.ai?.plan;
 const preview=plan?.state==='READY'&&Math.hypot(robot.x-plan.origin[0],robot.y-plan.origin[1])<=.15?plan.result:null;
 const target=snapshot.stations.find(s=>s.id===((robot.state==='RUNNING'||snapshot.realtime?.active)?robot.destination:preview?.destination||selected));
 const [x,y]=point(robot.x,robot.y);
 $('robot-envelope').setAttribute('r',19*(geometry.robot_radius+(geometry.robot_clearance||0))/geometry.robot_radius);
 $('robot').setAttribute('transform',`translate(${x} ${y}) scale(${projection.scale*geometry.robot_radius/19})`);$('robot').setAttribute('visibility','visible');
 if(target){const [tx,ty]=point(target.x,target.y);$('target').setAttribute('cx',tx);$('target').setAttribute('cy',ty);const rt=snapshot.realtime;const path=rt?.active?(rt.mode==='global'?[[robot.x,robot.y],...(rt.route||[])]:rt.phase==='MOVING'&&rt.last_action?.action==='move'?[[robot.x,robot.y],[rt.last_action.x,rt.last_action.y]]:[]):robot.state==='RUNNING'?robot.path:(currentView==='live'||snapshot.obstacles?.length)?[]:(snapshot.preview_routes?.[target.id]||[]);$('route').setAttribute('d',(path||[]).map((p,i)=>`${i?'L':'M'}${point(...p).join(' ')}`).join(' '));}
}

function render(data){
 snapshot=data;const r=data.robot;
 $('connection').textContent=data.connected?'ROS 연결됨':'ROS 연결 끊김';$('connection').classList.toggle('muted',!data.connected);
 $('offline').hidden=data.connected;
 $('offline').textContent='ROS 연결이 끊겼습니다. 마지막 수신 상태를 표시하며 제어는 비활성화됩니다.';
 if(r){$('robot-status').textContent=states[r.state]||r.state;$('destination').textContent=label(r.destination);$('current-job').textContent=r.job_id||'대기 중인 작업 없음';$('distance').textContent=Number(r.remaining_distance).toFixed(2);$('coordinates').textContent=`${r.x.toFixed(2)}, ${r.y.toFixed(2)}`;}
 $('update-age').textContent=data.connected?'실시간 상태 수신 중':data.age_seconds==null?'상태 수신 대기':`마지막 수신 ${data.age_seconds.toFixed(0)}초 전`;
 controls();drawMap();renderEditor();
 renderLogs();
 renderDecisions();
 renderRealtime();
 renderAI();
 const history=JSON.stringify(data.jobs);if(history!==lastHistory){lastHistory=history;renderHistory();}
 const events=JSON.stringify(data.events);if(events!==lastEvents){lastEvents=events;$('events').replaceChildren(...data.events.map(e=>{const li=text('li',e.message);li.append(text('time',time(e.at)));return li;}));$('events-empty').hidden=data.events.length>0;}
}
async function poll(){
 try{const response=await fetch('/api/state',{signal:AbortSignal.timeout(2500)});if(!response.ok)throw Error('상태 조회 실패');render(await response.json());}
 catch{if(snapshot){snapshot.connected=false;snapshot.can_submit=false;snapshot.can_cancel=false;render(snapshot);}$('connection').textContent='서버 연결 끊김';$('connection').classList.add('muted');$('offline').hidden=false;$('offline').textContent='웹 서버에 연결할 수 없습니다. 서버가 실행 중인지 확인해 주세요. 마지막 수신 상태를 표시합니다.';$('update-age').textContent='상태 수신 중단';controls();}
 finally{setTimeout(poll,350);}
}
async function command(path,payload){
 busy=true;controls();notice('ROS 응답을 확인하고 있습니다.');
 try{const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify(payload),signal:AbortSignal.timeout(6000)});const result=await response.json();if(!response.ok)throw Error(result.error||result.message||'요청을 처리하지 못했습니다.');notice(result.message||(path==='/api/jobs'?'운반 요청을 접수했습니다.':'취소 요청을 접수했습니다.'));if(path==='/api/jobs')$('job-id').value=newId();}
 catch(error){notice(error.name==='TimeoutError'?'응답을 받지 못했습니다. 작업 기록에서 접수 여부를 확인해 주세요.':error.message,true);}
 finally{busy=false;controls();}
}
$('job-form').addEventListener('submit',e=>{e.preventDefault();if(!busy&&snapshot?.can_submit)command('/api/jobs',{job_id:$('job-id').value.trim(),destination:document.querySelector('input[name="destination"]:checked').value});});
$('cancel').addEventListener('click',()=>{if(!busy&&snapshot?.can_cancel)command('/api/cancel',{job_id:snapshot.robot.job_id});});
$('destinations').addEventListener('change',drawMap);
$('history-filter').addEventListener('change',renderHistory);
setInterval(()=>{$('clock').textContent=new Date().toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});},1000);
let logsPaused=false, logSignature='';
function renderLogs(){
 $('log-view-state').textContent=logsPaused?'화면 표시 일시정지 중':!snapshot?.connected?'ROS 연결 끊김':Number($('log-level').value)>20||$('log-search').value?'실시간 수신 · 필터 적용 중':'실시간 수신 · 동작 로그는 INFO 레벨';
 if(logsPaused)return;
 const all=snapshot?.ros_logs||[], minimum=Number($('log-level').value), query=$('log-search').value.toLowerCase();
 const logs=all.filter(l=>l.level>=minimum&&(`${l.name} ${l.message}`).toLowerCase().includes(query));
 const signature=JSON.stringify([all.length,logs]);if(signature===logSignature)return;logSignature=signature;
 $('ros-log-count').textContent=`${logs.length} / ${all.length}`;
 $('ros-logs').replaceChildren(...logs.map(l=>{const row=document.createElement('div');row.className='ros-row';const level={10:'DEBUG',20:'INFO',30:'WARN',40:'ERROR',50:'FATAL'}[l.level]||String(l.level);row.append(text('time',new Date(l.stamp*1000).toLocaleTimeString('ko-KR',{hour12:false})),text('span',level,'log-level level-'+level),text('strong',l.name),text('pre',l.message));row.title=`${l.file}:${l.line} · ${l.function}`;return row;}));
 if(!logs.length)$('ros-logs').append(text('p','표시할 ROS 로그가 없습니다.','logs-empty'));
}
$('log-level').addEventListener('change',renderLogs);$('log-search').addEventListener('input',renderLogs);
$('log-pause').addEventListener('click',()=>{logsPaused=!logsPaused;$('log-pause').textContent=logsPaused?'표시 재개':'표시 일시정지';renderLogs();});
$('log-reset').addEventListener('click',()=>{logsPaused=false;$('log-level').value='0';$('log-search').value='';$('log-pause').textContent='표시 일시정지';renderLogs();$('ros-logs').scrollTop=0;});
const pressedKeys=new Set();let sendingVelocity=false, stopRequested=false;
function manualAllowed(){return $('manual-enable').checked&&snapshot?.connected&&snapshot?.can_teleop&&!busy&&!document.querySelector('dialog[open]');}
function manualControls(){
 $('manual-enable').disabled=!snapshot?.connected||!snapshot?.can_teleop||busy;
 if(!snapshot?.connected||!snapshot?.can_teleop){$('manual-enable').checked=false;pressedKeys.clear();}
 document.querySelectorAll('[data-key]').forEach(b=>{b.disabled=!manualAllowed();b.classList.toggle('pressed',pressedKeys.has(b.dataset.key));});
 $('manual-stop').disabled=!$('manual-enable').checked;
 $('manual-status').textContent=snapshot?.robot?.collision_blocked?'벽 충돌 차단 · 위치 유지':!$('manual-enable').checked?'수동 조작 꺼짐':pressedKeys.size?'방향키 입력 중':'방향키 입력 대기';
}
async function sendVelocity(){
 if(sendingVelocity)return;
 if(!manualAllowed()&&!stopRequested)return;
 const x=stopRequested?0:Number(pressedKeys.has('ArrowRight'))-Number(pressedKeys.has('ArrowLeft'));
 const y=stopRequested?0:Number(pressedKeys.has('ArrowUp'))-Number(pressedKeys.has('ArrowDown'));
 if(!stopRequested&&!pressedKeys.size)return;
 stopRequested=false;sendingVelocity=true;
 try{const res=await fetch('/api/teleop',{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify({x,y,issued_at:Date.now()/1000}),signal:AbortSignal.timeout(600)});if(!res.ok){const data=await res.json();throw Error(data.error);}}
 catch(e){$('manual-enable').checked=false;pressedKeys.clear();notice(e.message||'수동 조작 연결이 끊겼습니다.',true);}
 finally{sendingVelocity=false;manualControls();if(stopRequested)sendVelocity();}
}
function stopManual(){pressedKeys.clear();stopRequested=true;manualControls();sendVelocity();}
$('manual-enable').addEventListener('change',()=>{if(!$('manual-enable').checked)stopManual();controls();});
const arrowKeys=['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
window.addEventListener('keydown',e=>{if(e.repeat||!manualAllowed()||e.target.closest('input:not([type="checkbox"]),textarea,select,[contenteditable="true"]'))return;if(e.code==='Space'){e.preventDefault();stopManual();return;}if(arrowKeys.includes(e.key)){e.preventDefault();pressedKeys.add(e.key);manualControls();sendVelocity();}});
document.addEventListener('focusin',e=>{if(pressedKeys.size&&e.target.closest('input:not([type="checkbox"]),textarea,select'))stopManual();});
window.addEventListener('keyup',e=>{if(pressedKeys.has(e.key)){e.preventDefault();pressedKeys.delete(e.key);if(!pressedKeys.size)stopManual();else sendVelocity();manualControls();}});
document.querySelectorAll('[data-key]').forEach(b=>{b.addEventListener('pointerdown',e=>{if(!manualAllowed())return;e.preventDefault();b.setPointerCapture(e.pointerId);pressedKeys.add(b.dataset.key);manualControls();sendVelocity();});b.addEventListener('pointerup',stopManual);b.addEventListener('pointercancel',stopManual);b.addEventListener('lostpointercapture',()=>{if(pressedKeys.size)stopManual();});});
$('manual-stop').addEventListener('click',stopManual);
window.addEventListener('blur',()=>{if(pressedKeys.size)stopManual();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopManual();$('manual-enable').checked=false;controls();}});
window.addEventListener('pagehide',stopManual);
setInterval(sendVelocity,100);
let aiSending=false;
function renderAI(){
 const ai=snapshot?.ai, plan=ai?.plan;
 const online=Boolean(ai?.worker_connected&&snapshot?.connected);
 $('ai-connection').textContent=online?'LLM 연결기 실행 중':'LLM 연결기 오프라인';$('ai-connection').classList.toggle('muted',!online);
 const active=plan&&['QUEUED','READING','EXECUTING'].includes(plan.state);
 $('ai-read').disabled=aiSending||!online||!snapshot?.can_submit||active||$('manual-enable').checked;
 $('ai-execute').disabled=aiSending||!snapshot?.can_submit||plan?.state!=='READY'||$('manual-enable').checked;
 if(!plan)return;
 const names={QUEUED:'요청 대기',READING:'도면 해석 중',READY:'목표 검증 완료',CLARIFY:'목표를 구체적으로 입력해 주세요',FAILED:'처리 실패',EXPIRED:'계획 만료',EXECUTING:'ROS 이동 중',SUCCEEDED:'목표 도착',CANCELED:'이동 취소',REJECTED:'요청 거절'};
 $('ai-state').textContent=names[plan.state]||plan.state;
 $('ai-target').textContent=plan.result?`${plan.result.label} · (${plan.result.x.toFixed(2)}, ${plan.result.y.toFixed(2)}) m`:'도면 목표를 확인하고 있습니다';
 $('ai-message').textContent=plan.message;
 $('ai-explanation').textContent=(plan.result?.explanation||'')+(plan.result?.route?` · 통로 경로 ${plan.result.route_length.toFixed(2)}m / ${plan.result.route.length-1}개 구간 / 로봇 안전 반경 ${(snapshot.navigation.robot_radius+(snapshot.navigation.robot_clearance||0)).toFixed(2)}m 반영`:'');
}
async function aiCommand(path,payload){
 aiSending=true;renderAI();
 try{const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify(payload),signal:AbortSignal.timeout(6000)});const data=await response.json();if(!response.ok)throw Error(data.error||'AI 요청 실패');}
 catch(e){notice(e.message,true);}
 finally{aiSending=false;renderAI();}
}
$('ai-read').addEventListener('click',()=>{if(!$('ai-read').disabled)aiCommand('/api/ai/request',{prompt:$('ai-prompt').value});});
$('ai-execute').addEventListener('click',()=>{if(!$('ai-execute').disabled)aiCommand('/api/ai/execute',{id:snapshot.ai.plan.id});});
const techDialog=$('tech-guide');
const openTechBtn=$('open-tech-guide');
const closeTechBtn=$('close-tech-guide');
if(openTechBtn&&techDialog){
 openTechBtn.addEventListener('click',()=>{
  if(pressedKeys.size)stopManual();
  techDialog.showModal();
  manualControls();
 });
}
if(closeTechBtn&&techDialog){
 closeTechBtn.addEventListener('click',()=>techDialog.close());
}
if(techDialog){
 techDialog.addEventListener('click',event=>{
  const rect=techDialog.getBoundingClientRect();
  if(event.target===techDialog&&(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)){
   techDialog.close();
  }
 });
 techDialog.addEventListener('close',()=>{
  openTechBtn?.focus();
  manualControls();
 });
}
window.addEventListener('keydown',event=>{
 if(techDialog&&techDialog.open){
  if(event.key==='Escape'){
   event.preventDefault();
   techDialog.close();
  }
  event.stopImmediatePropagation();
 }
},true);
window.addEventListener('DOMContentLoaded',()=>{notice('목적지를 선택하고 운반 작업을 시작하세요.');renderHistory();poll();});
