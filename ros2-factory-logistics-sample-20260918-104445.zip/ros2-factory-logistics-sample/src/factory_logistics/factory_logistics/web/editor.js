'use strict';
let draft=null, editorBase=null, editorDirty=false, editorSaving=false, editorTool='draw', selectedWall=-1, dragStart=null, dragEnd=null;
const editorHistory=[];
const copyMap=value=>JSON.parse(JSON.stringify(value));
const snap=value=>Math.round(value*10)/10;
function editorMessage(value,error=false){$('editor-message').textContent=value;$('editor-message').classList.toggle('error',error);}
function rememberMap(){editorHistory.push(copyMap(draft));if(editorHistory.length>50)editorHistory.shift();editorDirty=true;}
function editorGeometry(width,height,walls){return {center_bounds:[0,0,width,height],outer_bounds:[-.3,-.3,width+.3,height+.3],resolution:.1,robot_radius:draft?.robot_radius||.12,robot_clearance:draft?.robot_clearance||0,walls};}
function loadEditor(){
 if(!snapshot?.navigation)return;
 draft=copyMap(snapshot.navigation);editorBase=draft.id;editorDirty=false;selectedWall=-1;editorHistory.length=0;
 $('map-width').value=draft.center_bounds[2];$('map-height').value=draft.center_bounds[3];
 editorMessage('현재 운행 지도를 불러왔습니다. 편집 후 적용해 주세요.');drawEditor();
}
function editorControls(){
 $('editor-apply').disabled=editorSaving||!editorDirty||!snapshot?.can_submit||$('manual-enable').checked;
 $('editor-undo').disabled=editorSaving||!editorHistory.length;
 $('obstacle-delete').disabled=editorSaving||selectedWall<0;
 for(const id of ['tool-draw','tool-select','editor-resize','obstacle-save','editor-empty','editor-sample','editor-reload'])$(id).disabled=editorSaving||!draft;
 $('editor-badge').textContent=editorSaving||snapshot?.map_pending?'ROS 적용 확인 중':editorDirty?'미적용 초안':'현재 지도';
 $('editor-badge').classList.toggle('muted',!editorDirty);
}
function renderEditor(){
 if(!draft&&snapshot?.navigation)loadEditor();
 if(draft&&editorBase!==snapshot?.navigation?.id&&!editorDirty&&!editorSaving)loadEditor();
 editorControls();
 if(draft){const pose=$('editor-robot');if(pose&&snapshot?.robot){const [x,y]=mapProjection(draft).point(snapshot.robot.x,snapshot.robot.y);pose.setAttribute('cx',x);pose.setAttribute('cy',y);}}
}
function selectWall(index){
 selectedWall=index;
 $('obstacle-heading').textContent=index<0?'장애물 추가':`장애물 ${index+1} 수정`;
 $('obstacle-save').textContent=index<0?'좌표로 추가':'선택 장애물 수정';
 if(index>=0){const [a,b,c,d]=draft.walls[index];$('obstacle-x').value=a;$('obstacle-y').value=b;$('obstacle-width').value=snap(c-a);$('obstacle-height').value=snap(d-b);}
 drawEditor();
}
function drawEditor(){
 if(!draft)return;
 const projection=mapProjection(draft),point=projection.point,parts=[mapRect(draft.outer_bounds,projection,'#f8fbff','#7992b3')];
 for(let x=0;x<=draft.center_bounds[2]+.001;x+=.1){const a=point(x,0),b=point(x,draft.center_bounds[3]);parts.push(svgElement('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#dce5f0','stroke-width':.5}));}
 for(let y=0;y<=draft.center_bounds[3]+.001;y+=.1){const a=point(0,y),b=point(draft.center_bounds[2],y);parts.push(svgElement('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#dce5f0','stroke-width':.5}));}
 draft.walls.forEach((wall,index)=>{const r=draft.robot_radius+(draft.robot_clearance||0);parts.push(mapRect([wall[0]-r,wall[1]-r,wall[2]+r,wall[3]+r],projection,'#d0d9e7','none'));const el=mapRect(wall,projection,index===selectedWall?'#376bf0':'#263d5a',index===selectedWall?'#1d4cdf':'#172942');el.dataset.wall=index;parts.push(el);});
 if(dragStart&&dragEnd)parts.push(mapRect(dragRectangle(),projection,'#6794ee88','#3269e8'));
 for(const s of snapshot.stations){const [x,y]=point(s.x,s.y);parts.push(svgElement('circle',{cx:x,cy:y,r:7,fill:'#376bf0'}));const label=svgElement('text',{x,y:y+25,'text-anchor':'middle',fill:'#233e61','font-size':15});label.textContent=`${s.label} (${s.x}, ${s.y})`;parts.push(label);}
 if(snapshot.robot){const [x,y]=point(snapshot.robot.x,snapshot.robot.y);parts.push(svgElement('circle',{id:'editor-robot',cx:x,cy:y,r:5,fill:'#ee8b28',stroke:'white'}));}
 const caption=svgElement('text',{x:45,y:495,fill:'#536b87','font-size':16});caption.textContent=`${draft.center_bounds[2]} × ${draft.center_bounds[3]} m · 장애물 ${draft.walls.length} / 32 · 회색 영역: 로봇 여유 공간`;parts.push(caption);
 $('editor-canvas').replaceChildren(...parts);editorControls();
}
function validWall(wall){return wall.every(Number.isFinite)&&wall[0]>=0&&wall[1]>=0&&wall[2]<=draft.center_bounds[2]&&wall[3]<=draft.center_bounds[3]&&wall[2]-wall[0]>=.099999&&wall[3]-wall[1]>=.099999;}
function putWall(wall,index=-1){
 if(!validWall(wall)){editorMessage('장애물은 도면 안에 있고 크기가 0.1m 이상이어야 합니다.',true);return;}
 if(index<0&&draft.walls.length>=32){editorMessage('장애물은 최대 32개입니다.',true);return;}
 rememberMap();if(index<0){draft.walls.push(wall);index=draft.walls.length-1;}else draft.walls[index]=wall;
 selectWall(index);editorMessage('초안 변경됨 · 저장하고 ROS에 적용을 눌러 주세요.');
}
function eventPoint(event){const p=new DOMPoint(event.clientX,event.clientY).matrixTransform($('editor-canvas').getScreenCTM().inverse());return mapProjection(draft).inverse(p.x,p.y).map((v,i)=>snap(Math.max(0,Math.min(draft.center_bounds[i+2],v))));}
function dragRectangle(){return [Math.min(dragStart[0],dragEnd[0]),Math.min(dragStart[1],dragEnd[1]),Math.max(dragStart[0],dragEnd[0]),Math.max(dragStart[1],dragEnd[1])];}
$('editor-canvas').addEventListener('pointerdown',event=>{
 if(!draft||editorSaving||event.button!==0)return;
 event.preventDefault();
 if(editorTool==='select'){const index=event.target.dataset.wall;selectWall(index===undefined?-1:Number(index));return;}
 dragStart=eventPoint(event);dragEnd=dragStart;$('editor-canvas').setPointerCapture(event.pointerId);
});
$('editor-canvas').addEventListener('pointermove',event=>{if(dragStart){dragEnd=eventPoint(event);drawEditor();}});
$('editor-canvas').addEventListener('pointerup',event=>{if(!dragStart)return;dragEnd=eventPoint(event);const wall=dragRectangle();dragStart=dragEnd=null;putWall(wall);drawEditor();});
$('editor-canvas').addEventListener('pointercancel',()=>{dragStart=dragEnd=null;drawEditor();});
$('editor-canvas').addEventListener('lostpointercapture',()=>{if(dragStart){dragStart=dragEnd=null;drawEditor();}});
for(const tool of ['draw','select'])$('tool-'+tool).addEventListener('click',()=>{editorTool=tool;for(const name of ['draw','select'])$('tool-'+name).setAttribute('aria-pressed',name===tool);selectWall(-1);});
$('obstacle-save').addEventListener('click',()=>{const x=Number($('obstacle-x').value),y=Number($('obstacle-y').value),w=Number($('obstacle-width').value),h=Number($('obstacle-height').value);putWall([snap(x),snap(y),snap(x+w),snap(y+h)],selectedWall);});
$('obstacle-delete').addEventListener('click',()=>{if(selectedWall<0)return;rememberMap();draft.walls.splice(selectedWall,1);selectWall(-1);editorMessage('선택한 장애물을 초안에서 삭제했습니다.');});
$('editor-undo').addEventListener('click',()=>{if(!editorHistory.length)return;draft=editorHistory.pop();editorDirty=true;$('map-width').value=draft.center_bounds[2];$('map-height').value=draft.center_bounds[3];selectWall(-1);editorMessage('이전 초안으로 되돌렸습니다.');});
$('editor-resize').addEventListener('click',()=>{
 const w=snap(Number($('map-width').value)),h=snap(Number($('map-height').value));
 if(!Number.isFinite(w)||!Number.isFinite(h)||w<3||w>8||h<2||h>8){editorMessage('가로 3~8m, 세로 2~8m 범위로 입력해 주세요.',true);return;}
 if(draft.walls.some(wall=>wall[2]>w||wall[3]>h)){editorMessage('줄어드는 영역의 장애물을 먼저 삭제해 주세요.',true);return;}
 rememberMap();draft=editorGeometry(w,h,draft.walls);drawEditor();editorMessage('도면 크기를 변경했습니다. 적용 전까지 초안입니다.');
});
$('editor-empty').addEventListener('click',()=>{rememberMap();draft.walls=[];selectWall(-1);editorMessage('빈 도면 초안입니다. 장애물을 배치해 주세요.');});
$('editor-sample').addEventListener('click',()=>{rememberMap();draft=editorGeometry(3,2,[[.3,.3,2.7,1.7]]);draft.robot_radius=.12;draft.robot_clearance=0;$('map-width').value=3;$('map-height').value=2;selectWall(-1);editorMessage('기본 샘플 도면을 초안에 불러왔습니다.');});
$('editor-reload').addEventListener('click',loadEditor);
$('editor-apply').addEventListener('click',async()=>{
 if($('editor-apply').disabled)return;
 editorSaving=true;editorControls();editorMessage('ROS에서 지도와 통로를 검증하고 있습니다.');
 try{
  localStorage.setItem('warehouse.previousMap',JSON.stringify(snapshot.navigation));
  const response=await fetch('/api/map',{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify({expected_id:editorBase,map:draft}),signal:AbortSignal.timeout(6500)});
  const result=await response.json();if(!response.ok)throw Error(result.error||result.message);
  if(result.pending){editorMessage(result.message+' 현재 도면 불러오기로 결과를 확인해 주세요.');return;}
  // The service is authoritative; wait until the matching ROS state is visible.
  let state;
  for(let attempt=0;attempt<20;attempt++){
   const stateResponse=await fetch('/api/state',{signal:AbortSignal.timeout(2500)});if(!stateResponse.ok)throw Error('저장 후 상태 조회 실패. 현재 도면을 다시 불러와 주세요.');state=await stateResponse.json();render(state);
   if(state.navigation.id===result.map_id)break;
   await new Promise(resolve=>setTimeout(resolve,150));
  }
  if(state.navigation.id===result.map_id){loadEditor();editorMessage('저장 완료 · 라이브 맵, Codex 도면, ROS 경로에 적용되었습니다.');}
  else editorMessage('ROS에 저장되었습니다. 상태 갱신 후 현재 도면을 다시 불러와 주세요.');
 }catch(error){editorMessage(error.name==='TimeoutError'?'응답 지연 · 현재 도면을 불러와 적용 여부를 확인해 주세요.':error.message,true);}
 finally{editorSaving=false;editorControls();}
});

$('editor-warehouse').addEventListener('click',()=>{
 if(!draft||editorSaving)return;rememberMap();
 const walls=[];for(const x of [1,3.6,6.2])for(const y of [1,3.4,5.8])walls.push([x,y,x+.8,y+1.4]);
 draft=editorGeometry(8,8,walls);draft.robot_radius=.25;draft.robot_clearance=.1;draft.stations={warehouse:[0,0],line_a:[7.6,.3],line_b:[7.6,7.6]};
 $('map-width').value=8;$('map-height').value=8;selectWall(-1);editorMessage('8×8m · 선반 9개 · 교차 통로 · 출고/피킹 지점. 저장하고 적용하세요.');
});
$('editor-backup').addEventListener('click',async()=>{
 let saved=localStorage.getItem('warehouse.previousMap');if(!saved){try{const r=await fetch('/previous-map.json');if(!r.ok)throw Error();saved=JSON.stringify(await r.json());}catch(e){editorMessage('이전 도면을 불러오지 못했습니다.',true);return;}}
 rememberMap();draft=JSON.parse(saved);$('map-width').value=draft.center_bounds[2];$('map-height').value=draft.center_bounds[3];selectWall(-1);editorMessage('이전 도면 복원 초안입니다. 현재 로봇·장애물 위치를 확인하고 적용하세요.');
});
