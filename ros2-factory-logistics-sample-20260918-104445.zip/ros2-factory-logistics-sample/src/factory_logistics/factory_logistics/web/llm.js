(()=>{const $=id=>document.getElementById(id);let busy=false;
async function request(path,data){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw Error(result.error||'요청 실패');return result;}
function show(s){$('llm-provider').value=s.provider;$('llm-model').value=s.model;$('llm-key-status').textContent=s.has_key?'API 키 저장됨 (값은 표시하지 않음)':'저장된 API 키 없음';}
async function run(fn){if(busy)return;busy=true;const buttons=[...$('llm-form').querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);$('llm-status').textContent='처리 중…';try{await fn();}catch(e){$('llm-status').textContent=e.message;}finally{busy=false;buttons.forEach(b=>b.disabled=false);}}
$('llm-form').addEventListener('submit',e=>{e.preventDefault();run(async()=>{const data={provider:$('llm-provider').value,model:$('llm-model').value,api_key:$('llm-key').value};$('llm-key').value='';const s=await request('/api/llm/settings',data);show(s);$('llm-status').textContent='설정 저장 완료';});});
$('llm-test').onclick=()=>run(async()=>{const s=await request('/api/llm/test',{});$('llm-status').textContent=s.message+(s.description?' · '+s.description:'');});
$('llm-clear').onclick=()=>run(async()=>{const s=await request('/api/llm/settings',{provider:'codex',clear_key:true});$('llm-key').value='';show(s);$('llm-status').textContent='키 삭제 완료 · Codex 선택됨';});
fetch('/api/state').then(r=>r.json()).then(s=>show(s.llm)).catch(()=>{$('llm-status').textContent='서버 연결을 확인해 주세요.';});})();
