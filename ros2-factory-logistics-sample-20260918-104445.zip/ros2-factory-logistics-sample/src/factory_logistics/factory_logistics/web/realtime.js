'use strict';
let currentView='live',rtSending=false,dynamicSending=false,dynamicSignature='',dragObstacle=null,dragPending=null,dragSending=false;
const phaseNames={INSPECTING:'오래된 장애물 재관측 중',RECOVERING:'충돌 후 전방·좌우 재관측',BLOCKED:'충돌 원인 미확인 · 안전 정지',ASSESSING:'장애물 발견 · 정지 후 판단',YIELDING:'지나가는 장애물 양보 중',IDLE:'준비',OBSERVING:'새 화면 관측 중',THINKING:'LLM 판단 중 · 로봇 정지',MOVING:'전체 경로 연속 주행 중',WAITING:'장애물 통과 대기',ARRIVED:'목표 도착',STOPPED:'사용자 정지',ERROR:'확인 필요',LIMIT:'실행 한도 도달'};
function selectView(view){
 currentView=['live','editor','classic','logs'].includes(view)?view:'live';
 const groups={live:[$('live')],editor:[$('map-editor')],classic:[$('ai-planner'),document.querySelector('.workspace-grid'),document.querySelector('.manual-panel')],logs:[document.querySelector('.bottom-grid'),$('decision-log'),document.querySelector('.ros-panel')]};
 for(const [name,elements] of Object.entries(groups))for(const el of elements)el.hidden=name!==currentView;
 const map=document.querySelector('.map-panel');if(currentView==='classic')document.querySelector('.workspace-grid').prepend(map);else $('live-map-slot').append(map);
 document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===currentView);if(el.tagName==='BUTTON')el.setAttribute('aria-selected',String(el.dataset.view===currentView));});
 if(currentView!=='classic'&&$('manual-enable').checked){$('manual-enable').checked=false;stopManual();}
}
window.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',event=>{event.preventDefault();selectView(el.dataset.view);}));
 document.querySelector('.view-tabs').addEventListener('keydown',event=>{const tabs=[...document.querySelectorAll('.view-tabs [role=tab]')],index=tabs.indexOf(event.target);if(index<0||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?tabs.length-1:(index+(event.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next].focus();selectView(tabs[next].dataset.view);});
 selectView(location.hash==='#decision-log'?'logs':location.hash==='#map-editor'?'editor':'live');
});
async function rtRequest(payload){
 const response=await fetch('/api/realtime/control',{method:'POST',headers:{'Content-Type':'application/json','X-Factory-Control':'1'},body:JSON.stringify(payload),signal:AbortSignal.timeout(5500)});
 const result=await response.json();if(!response.ok)throw Error(result.error||result.message||'요청 실패');return result;
}
async function rtControl(operation){
 if(rtSending&&operation!=='stop')return;
 rtSending=true;$('rt-error').textContent='';renderRealtime();
 try{await rtRequest({operation,destination:$('rt-destination').value,mode:'global',speed:Number($('rt-speed').value)});}
 catch(error){$('rt-error').textContent=error.message;}
 finally{rtSending=false;renderRealtime();}
}
$('rt-destination').addEventListener('change',()=>{$('rt-mobile-goal').value=$('rt-destination').value;drawMap();});
$('rt-mobile-goal').addEventListener('change',()=>{$('rt-destination').value=$('rt-mobile-goal').value;drawMap();});
$('rt-mobile-start').addEventListener('click',()=>rtControl('start'));
$('rt-mobile-stop').addEventListener('click',()=>rtControl('stop'));
$('rt-start').addEventListener('click',()=>rtControl('start'));
$('rt-stop').addEventListener('click',()=>rtControl('stop'));
$('rt-open-logs').addEventListener('click',()=>{selectView('logs');$('decision-log').scrollIntoView({block:'start',behavior:'smooth'});});
window.addEventListener('keydown',event=>{if(event.key==='Escape'&&snapshot?.realtime?.active)rtControl('stop');});
function renderRealtime(){
 if(!snapshot)return;
 const sig=JSON.stringify(snapshot.stations);if(sig!==stationSignature){stationSignature=sig;for(const id of ['rt-destination','rt-mobile-goal'])for(const option of $(id).options){const s=snapshot.stations.find(s=>s.id===option.value);if(s)option.textContent=`${s.label} · (${s.x}, ${s.y})`;}for(const radio of document.querySelectorAll('input[name=destination]')){const s=snapshot.stations.find(s=>s.id===radio.value);if(s){radio.parentElement.querySelector('small').textContent=`${s.x}, ${s.y}`;}}}
 const rt=snapshot.realtime||{},obstacles=snapshot.obstacles||[],online=snapshot.ai?.worker_connected&&snapshot.connected;
 $('rt-start').disabled=rtSending||!snapshot.connected||!snapshot.can_submit||['QUEUED','READING','EXECUTING'].includes(snapshot.ai?.plan?.state);
 $('rt-mobile-start').disabled=$('rt-start').disabled;$('rt-mobile-stop').disabled=!rt.active&&!rtSending;$('rt-mobile-goal').disabled=rt.active||rtSending;
 $('rt-speed').disabled=rt.active||rtSending;
 $('rt-stop').disabled=!rt.active&&!rtSending;$('rt-destination').disabled=rt.active||rtSending;
 $('rt-connection').textContent=online?`● 경로 주행 + ${snapshot.llm?.provider==='openrouter'?'OpenRouter':'Codex'} 비동기 검토`:'LLM 검토 연결 대기 · ROS 연결 시 경로 주행 가능';
 const behaviorNames={REOBSERVE_TRAVEL:'재관측 지점으로 이동',REOBSERVE_SCAN:'이전 장애물 위치 확인',GLOBAL_ROUTE:'기존 경로 이동',DETECTED:'발견 · 정지',LOCAL_AVOID:'가까운 우회',YIELD:'진로 양보 대기',NO_ROUTE:'통로 없음 · 대기',REOBSERVE:'반복 우회 방지 · 재관측',REPLAN:'전체 재탐색',SAFETY_STOP:'충돌 안전 정지'};
 $('robot-footprint').textContent=`로봇 지름 ${(snapshot.navigation.robot_radius*2).toFixed(2)}m + 사방 여유 ${(snapshot.navigation.robot_clearance||0).toFixed(2)}m · 최소 통과 폭 ${((snapshot.navigation.robot_radius+(snapshot.navigation.robot_clearance||0))*2).toFixed(2)}m 초과`;
 const people=rt.people||{};const toggle=$('dynamic-people-toggle');toggle.textContent=people.enabled?`사람 끄기 (${people.count}명)`:`사람 켜기${people.saved_count?` (${people.saved_count}명)`:''}`;toggle.setAttribute('aria-pressed',String(Boolean(people.enabled)));toggle.disabled=dynamicSending||!snapshot.connected;
 $('dynamic-people').disabled=dynamicSending||!snapshot.connected||obstacles.length>4;
 $('sensor-summary').textContent=`전방 카메라 80° · 지금 탐지 ${snapshot.sensor?.visible_ids?.length||0}개 / 기억 ${snapshot.sensor?.tracks?.length||0}개 (오래됨 ${(snapshot.sensor?.tracks||[]).filter(o=>o.uncertain_memory).length}개) · ${behaviorNames[rt.behavior]||'준비'} · 실제 속도 ${rt.actual_speed_mps??0}m/s · 가까운 우회 ${rt.local_avoids||0}회`;
 $('rt-phase').textContent=rt.camera_wait?'전방 관측 대기':phaseNames[rt.phase]||'준비';$('rt-message').textContent=rt.camera_wait||rt.message||'목표를 선택하고 시작해 주세요.';
 $('rt-cycle').textContent=`경로 계산 ${rt.replans||0}회 · ${rt.planning_ms??0}ms · 속도 ${rt.speed_mps??.5}m/s`;$('rt-status').dataset.phase=rt.phase||'IDLE';
 document.querySelectorAll('[data-phase]').forEach(el=>el.classList.toggle('active',el.dataset.phase===rt.phase||(el.dataset.phase==='OBSERVING'&&rt.phase==='WAITING')));
 const entry=snapshot.ai?.logs?.find(e=>e.request_id===rt.session&&e.source==='LLM');
 const sourceObservation=snapshot.ai?.logs?.find(e=>e.stage==='현재 화면 관측'&&e.details?.observation_id===entry?.details?.observation_id);$('rt-reason-label').textContent=sourceObservation?`최근 판단 근거 · 관측 #${sourceObservation.details.cycle}`:'최근 LLM 도면 검토 · 참고용';
 $('rt-reason').textContent=entry?.message||'경로 탐색기가 주행을 제어합니다. LLM 도면 검토는 비동기로 표시됩니다.';
 const action=rt.last_action;$('rt-action').textContent=action?.action==='move'?`선택한 이동 → (${action.x.toFixed(2)}, ${action.y.toFixed(2)}) m`:action?.action==='wait'?'선택한 행동 → 1초 대기':'아직 실행할 행동 없음';
 if(rt.observation){$('rt-age').textContent=`관측 #${rt.observation.cycle} · ${rt.observation_age?.toFixed(1)||0}초 전`;}
 else $('rt-age').textContent='아직 관측 없음';
 if(snapshot.observation_image_id&&$('rt-observation').dataset.id!==snapshot.observation_image_id){$('rt-observation').dataset.id=snapshot.observation_image_id;$('rt-observation').src='/api/realtime/observation.png?id='+snapshot.observation_image_id;$('rt-observation').hidden=false;$('rt-observation-empty').hidden=true;}
 $('rt-observation').hidden=!rt.observation||$('rt-observation').dataset.id!==rt.observation.id;$('rt-observation-empty').hidden=!$('rt-observation').hidden;
 if(rt.active){$('robot-status').textContent=rt.camera_wait?'카메라 대기':rt.phase==='MOVING'?'실시간 이동':rt.phase==='THINKING'?'관측 판단 중':'실시간 대기';$('current-job').textContent=`${rt.session} · 관측 ${rt.cycle}회`;const target=snapshot.stations.find(s=>s.id===rt.destination);if(target&&snapshot.robot)$('distance').textContent=rt.remaining_route_m==null?'—':rt.remaining_route_m.toFixed(2);}
 $('distance-caption').textContent=rt.active?'남은 계획 경로 거리':'목적지까지 경로 거리';
 const signature=JSON.stringify(obstacles.map(o=>o.id));
 if(signature!==dynamicSignature){dynamicSignature=signature;const selected=$('dynamic-select').value;$('dynamic-select').replaceChildren(...['new',...obstacles.map(o=>o.id)].map(id=>{const option=text('option',id==='new'?'새 장애물':id);option.value=id;return option;}));if(obstacles.some(o=>o.id===selected))$('dynamic-select').value=selected;}
 $('obstacle-count').textContent=`${obstacles.length} / 8`;
 $('dynamic-save').textContent=$('dynamic-select').value==='new'?'장애물 추가':'변경 적용';
 $('dynamic-save').disabled=dynamicSending||!snapshot.connected;$('dynamic-delete').disabled=dynamicSending||$('dynamic-select').value==='new';$('dynamic-clear').disabled=dynamicSending||(!obstacles.length&&!people.saved_count);
 for(const id of ['dynamic-bx','dynamic-by'])$(id).disabled=$('dynamic-mode').value!=='patrol';$('dynamic-speed').disabled=$('dynamic-mode').value==='manual';
 if(snapshot.navigation){const projection=mapProjection(snapshot.navigation);const sensor=snapshot.sensor||{},[sx,sy]=projection.point(snapshot.robot.x,snapshot.robot.y);const yaw=snapshot.robot.yaw||0,origin=[snapshot.robot.x,snapshot.robot.y],rays=[yaw-Math.PI*40/180,yaw+Math.PI*40/180].map(a=>projection.point(origin[0]+Math.cos(a)*3,origin[1]+Math.sin(a)*3));$('map-sensor').replaceChildren(svgElement('path',{d:`M${rays[0].join(' ')} L${sx} ${sy} L${rays[1].join(' ')}`,fill:'none',stroke:'#41b8ae','stroke-dasharray':'5 7',opacity:.55,'pointer-events':'none'}),...(sensor.tracks||[]).map(o=>{const [x,y]=projection.point(o.x,o.y);return svgElement('circle',{cx:x,cy:y,r:Math.max(5,o.radius*projection.scale),fill:'none',stroke:'#41b8ae','stroke-dasharray':'2 3','pointer-events':'none'});}));$('old-route').setAttribute('d',(rt.active?rt.previous_route||[]:[]).map((p,i)=>`${i?'L':'M'}${projection.point(...p).join(' ')}`).join(' '));$('blocked-route').setAttribute('visibility',rt.active&&rt.blocked_at?'visible':'hidden');if(rt.blocked_at){const [bx,by]=projection.point(...rt.blocked_at);$('blocked-route').setAttribute('cx',bx);$('blocked-route').setAttribute('cy',by);}$('map-dynamic').replaceChildren(...obstacles.map(o=>{const [x,y]=projection.point(o.x,o.y),g=svgElement('g',{'data-obstacle':o.id,tabindex:0,role:'button','aria-label':o.id+' 동적 장애물'});g.append(svgElement('circle',{cx:x,cy:y,r:(o.radius+snapshot.navigation.robot_radius+(snapshot.navigation.robot_clearance||0))*projection.scale,fill:'#ef9a3222','pointer-events':'none'}));const circle=svgElement('circle',{cx:x,cy:y,r:Math.max(7,o.radius*projection.scale),fill:snapshot.sensor?.visible_ids?.includes(o.id)?'#f7a73f':'#8a96a6',stroke:o.id===$('dynamic-select').value?'#fff':'#ffcf8b','stroke-width':2});g.append(circle);if(o.kind==='person'){g.append(svgElement('circle',{cx:x,cy:y-5,r:3,fill:'#fff','pointer-events':'none'}),svgElement('path',{d:`M${x} ${y-1}v7m-5 -4l5 -3 5 3m-8 8l3 -4 3 4`,stroke:'#fff',fill:'none','stroke-width':2,'pointer-events':'none'}));}const t=svgElement('text',{x,y:y-18,'text-anchor':'middle',fill:'#ffc879','font-size':12,'pointer-events':'none'});t.textContent=(o.kind==='person'?'사람 ':'')+o.id+(o.mode==='patrol'?' ↔':o.mode==='wander'?' ↝':'');g.append(t);return g;}));}
}
$('dynamic-mode').addEventListener('change',renderRealtime);
function pickObstacle(id){
 const o=snapshot?.obstacles.find(item=>item.id===id);if(!o)return;
 $('dynamic-select').value=id;$('dynamic-x').value=o.x.toFixed(2);$('dynamic-y').value=o.y.toFixed(2);$('dynamic-mode').value=o.mode;$('dynamic-speed').value=o.speed;
 if(o.b){$('dynamic-bx').value=o.b[0];$('dynamic-by').value=o.b[1];}renderRealtime();
}
$('dynamic-select').addEventListener('change',()=>{if($('dynamic-select').value==='new')prepareNewObstacle();else pickObstacle($('dynamic-select').value);renderRealtime();});
async function dynamicControl(obstacle){
 dynamicSending=true;renderRealtime();
 try{
  await rtRequest({operation:'obstacle',obstacle});
  const response=await fetch('/api/state',{cache:'no-store',signal:AbortSignal.timeout(4000)});
  if(response.ok)render(await response.json());
  if(obstacle.operation==='add'){
   prepareNewObstacle();
   $('dynamic-message').textContent=`(${obstacle.x.toFixed(2)}, ${obstacle.y.toFixed(2)})에 추가했습니다. 다음 장애물은 새 빈 좌표로 준비했습니다.`;
  }else $('dynamic-message').textContent=obstacle.operation==='people_toggle'?(obstacle.enabled?'사람을 다시 배치했습니다.':'사람을 장면·충돌 대상에서 제외했습니다. 관측 기억은 새 영상으로 갱신됩니다.'):'장애물 변경을 ROS에 적용했습니다.';
  $('dynamic-message').classList.remove('error');
 }
 catch(error){$('dynamic-message').textContent=error.message;$('dynamic-message').classList.add('error');}
 finally{dynamicSending=false;renderRealtime();}
}
$('dynamic-save').addEventListener('click',()=>{if(!$('dynamic-x').value.trim()||!$('dynamic-y').value.trim()){$('dynamic-message').textContent='X와 Y 좌표를 모두 입력해 주세요.';return;}const id=$('dynamic-select').value,x=Number($('dynamic-x').value),y=Number($('dynamic-y').value);const issue=obstaclePlacementIssue(x,y,id);if(issue){$('dynamic-message').textContent=issue+' ‘빈 통로에 새 장애물’을 누르면 가능한 좌표를 찾습니다.';$('dynamic-message').classList.add('error');return;}dynamicControl({operation:id==='new'?'add':'update',id,x,y,mode:$('dynamic-mode').value,speed:Number($('dynamic-speed').value),a:[x,y],b:[Number($('dynamic-bx').value),Number($('dynamic-by').value)]});});
$('dynamic-delete').addEventListener('click',()=>dynamicControl({operation:'delete',id:$('dynamic-select').value}));
$('dynamic-clear').addEventListener('click',()=>dynamicControl({operation:'clear'}));
async function sendDrag(){
 if(dragSending||!dragPending)return;
 const payload=dragPending;dragPending=null;dragSending=true;
 try{await rtRequest({operation:'obstacle',obstacle:payload});$('dynamic-message').textContent='드래그 중 · 최신 위치에 충돌 검사 적용';}
 catch(error){$('dynamic-message').textContent=error.message;}
 finally{dragSending=false;if(dragPending)sendDrag();}
}
function dragPoint(event){const p=new DOMPoint(event.clientX,event.clientY).matrixTransform($('factory-map').getScreenCTM().inverse());return mapProjection(snapshot.navigation).inverse(p.x,p.y).map((value,axis)=>Math.max(snapshot.navigation.center_bounds[axis],Math.min(snapshot.navigation.center_bounds[axis+2],value)));}
$('factory-map').addEventListener('keydown',event=>{const g=event.target.closest('[data-obstacle]');if(g&&(event.key==='Enter'||event.key===' ')){event.preventDefault();pickObstacle(g.dataset.obstacle);}});
$('factory-map').addEventListener('pointerdown',event=>{const g=event.target.closest('[data-obstacle]');if(!g||event.button!==0)return;event.preventDefault();dragObstacle=g.dataset.obstacle;pickObstacle(dragObstacle);$('factory-map').setPointerCapture(event.pointerId);});
$('factory-map').addEventListener('pointermove',event=>{if(!dragObstacle)return;const [x,y]=dragPoint(event);dragPending={operation:'update',id:dragObstacle,x,y,mode:'manual'};});
$('factory-map').addEventListener('pointerup',event=>{if(!dragObstacle)return;const [x,y]=dragPoint(event);dragPending={operation:'update',id:dragObstacle,x,y,mode:'manual'};dragObstacle=null;sendDrag();});
$('factory-map').addEventListener('pointercancel',()=>{dragObstacle=null;dragPending=null;});
setInterval(sendDrag,120);

let stationSignature='';

function obstaclePlacementIssue(x,y,id='new'){
 if(!snapshot?.navigation||!Number.isFinite(x)||!Number.isFinite(y))return '유효한 좌표를 입력해 주세요.';
 const o=snapshot.obstacles.find(o=>o.id===id),r=o?.radius||($('dynamic-mode').value==='wander'?.22:.1),nav=snapshot.navigation,b=nav.center_bounds;
 if(x<b[0]||y<b[1]||x>b[2]||y>b[3])return `도면 좌표 범위는 X ${b[0]}~${b[2]}, Y ${b[1]}~${b[3]}m입니다.`;
 if(nav.walls.some(w=>x>=w[0]-r&&x<=w[2]+r&&y>=w[1]-r&&y<=w[3]+r))return '이 좌표는 선반·벽 또는 그 여유 공간과 겹칩니다.';
 if(Math.hypot(x-snapshot.robot.x,y-snapshot.robot.y)<=r+nav.robot_radius+(nav.robot_clearance||0)+.01)return '이 좌표는 로봇과 너무 가깝습니다.';
 const other=snapshot.obstacles.find(o=>o.id!==id&&Math.hypot(x-o.x,y-o.y)<=r+o.radius+.01);
 return other?`이 좌표에는 장애물 ${other.id}가 이미 있습니다.`:'';
}
function prepareNewObstacle(){
 if(!snapshot?.connected)return;
 if(snapshot.obstacles.length>=8){$('dynamic-message').textContent='장애물은 최대 8개입니다. 기존 장애물을 삭제한 뒤 추가해 주세요.';return;}
 const b=snapshot.navigation.center_bounds,px=Number($('dynamic-x').value)||b[0],py=Number($('dynamic-y').value)||b[1];
 let best=null,distance=Infinity;
 for(let x=b[0];x<=b[2];x+=.25)for(let y=b[1];y<=b[3];y+=.25){if(obstaclePlacementIssue(x,y))continue;const d=Math.hypot(x-px,y-py);if(d<distance){best=[x,y];distance=d;}}
 if(!best){$('dynamic-message').textContent='배치 가능한 빈 좌표를 찾지 못했습니다.';return;}
 $('dynamic-select').value='new';$('dynamic-mode').value='manual';$('dynamic-x').value=best[0].toFixed(2);$('dynamic-y').value=best[1].toFixed(2);
 $('dynamic-message').textContent=`빈 위치 (${best.map(v=>v.toFixed(2)).join(', ')}) 준비됨 · ‘장애물 추가’를 누르세요.`;$('dynamic-message').classList.remove('error');renderRealtime();
}
$('dynamic-new').addEventListener('click',prepareNewObstacle);

$('dynamic-people-toggle').addEventListener('click',()=>dynamicControl({operation:'people_toggle',enabled:!snapshot.realtime?.people?.enabled}));
$('dynamic-people').addEventListener('click',()=>dynamicControl({operation:'people',count:4}));

// A native modal keeps focus inside the guide and restores it to its opener.
const processDialog=document.getElementById('motion-process');
document.getElementById('open-motion-process').addEventListener('click',()=>{
 if(pressedKeys.size)stopManual();
 processDialog.showModal();
});
document.getElementById('close-motion-process').addEventListener('click',()=>processDialog.close());
processDialog.addEventListener('click',event=>{
 const rect=processDialog.getBoundingClientRect();
 if(event.target===processDialog&&(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom))processDialog.close();
});
// Let native Escape/scroll behavior work without invoking global robot shortcuts.
window.addEventListener('keydown',event=>{if(processDialog.open)event.stopImmediatePropagation();},true);

// Shared 30 FPS canvas renderer. Interpolation is display-only; never extrapolate.
(()=>{
 const ids=['live-camera','warehouse-overview'];
 const canvases=ids.map(id=>{const old=$(id),c=document.createElement('canvas');c.id=id;c.width=640;c.height=id==='live-camera'?360:440;c.setAttribute('role','img');c.setAttribute('aria-label',old.alt);old.replaceWith(c);return c;});
 const [front,overview]=canvases.map(c=>c.getContext('2d',{alpha:false}));
 const FOV=80*Math.PI/180,focal=320/Math.tan(FOV/2),height=.85,horizon=145;
 let frames=[],map=null,pending=false,received=0,lastDraw=0,windowStart=0,count=0,total=0,fps=0,cost=0;
 const visible=()=>!document.hidden&&currentView==='live';
 async function receive(){
  if(pending||!visible())return;
  pending=true;
  try{
   const r=await fetch('/api/scene',{cache:'no-store',signal:AbortSignal.timeout(1800)});if(!r.ok)throw Error('scene');
   const s=await r.json();if(!s.connected)throw Error('ROS disconnected');
   const now=performance.now();if(map?.id!==s.navigation.id)frames=[];
   map=s.navigation;frames.push({...s.scene,time:now});frames=frames.slice(-8);received=now;
  }catch(e){$('camera-status').textContent='상태 수신 지연 · 마지막 화면';}
  finally{pending=false;}
 }
 setInterval(receive,100);receive();
 function sample(now){
  const time=now-150;let a=frames[0],b=a;
  for(const f of frames){if(f.time<=time)a=f;else{b=f;break;}b=f;}
  const t=a===b?0:Math.max(0,Math.min(1,(time-a.time)/(b.time-a.time)));
  const lerp=(x,y)=>x+(y-x)*t,delta=Math.atan2(Math.sin(b.yaw-a.yaw),Math.cos(b.yaw-a.yaw));
  return {...b,pose:a.pose.map((v,i)=>lerp(v,b.pose[i])),yaw:a.yaw+delta*t,obstacles:b.obstacles.map(o=>{const old=a.obstacles.find(p=>p.id===o.id);return old?{...o,x:lerp(old.x,o.x),y:lerp(old.y,o.y),walk_phase:lerp(old.walk_phase||0,o.walk_phase||0)}:o;})};
 }
 function boxHit(x,y,dx,dy,b){
  let near=0,far=Infinity,axis=0;
  for(let i=0;i<2;i++){const d=i?dy:dx,o=i?y:x;if(Math.abs(d)<1e-9){if(o<b[i]||o>b[i+2])return null;continue;}
   let a=(b[i]-o)/d,c=(b[i+2]-o)/d;if(a>c)[a,c]=[c,a];if(a>near){near=a;axis=i;}far=Math.min(far,c);}
  return far<near||far<=0?null:{t:near>1e-5?near:far,axis};
 }
 function hits(s,angle,objects=true){
  const [x,y]=s.pose,dx=Math.cos(angle),dy=Math.sin(angle),all=[];
  map.walls.forEach((w,i)=>{const h=boxHit(x,y,dx,dy,w);if(h)all.push({...h,kind:'rack',i});});
  const edge=boxHit(x,y,dx,dy,map.outer_bounds);if(edge)all.push({...edge,kind:'edge'});
  if(objects)for(const o of s.obstacles){const ox=x-o.x,oy=y-o.y,p=ox*dx+oy*dy,d=p*p-(ox*ox+oy*oy-o.radius*o.radius);if(d>=0){const t=-p-Math.sqrt(d);if(t>0)all.push({t,kind:o.kind==='person'?'person':'object',o,axis:0});}}
  return all.sort((a,b)=>b.t-a.t);
 }
 function drawFront(s){
  const c=front;c.fillStyle='#5b7082';c.fillRect(0,0,640,horizon);c.fillStyle='#7e8b90';c.fillRect(0,horizon,640,360-horizon);
  // Perspective ground grid follows the same world axes as the camera rays.
  const project=(x,y)=>{const dx=x-s.pose[0],dy=y-s.pose[1],f=dx*Math.cos(s.yaw)+dy*Math.sin(s.yaw);return f>.05?[320+focal*(dx*Math.sin(s.yaw)-dy*Math.cos(s.yaw))/f,horizon+height*focal/f]:null;};
  c.strokeStyle='#687a83';c.lineWidth=1;c.beginPath();
  for(let x=0;x<=map.center_bounds[2];x+=.5)for(let y=0;y<=map.center_bounds[3];y+=.5){const a=project(x,y);if(!a)continue;for(const v of [[x+.5,y],[x,y+.5]]){const b=project(...v);if(b){c.moveTo(...a);c.lineTo(...b);}}}c.stroke();
  for(let x=0;x<640;x+=2){const angle=Math.atan((x-320)/focal),dir=s.yaw-angle;
   for(const hit of hits(s,dir)){const d=Math.max(.025,hit.t*Math.cos(angle)),h=hit.kind==='person'?1.75:hit.kind==='object'?.7:2.2;
    const screen=z=>horizon-(z-height)*focal/d,top=Math.max(30,screen(h)),bottom=Math.min(335,screen(0));if(top>=bottom)continue;
    const shade=Math.max(.3,1/(1+d*.075))*(hit.axis?.83:1),color=(r,g,b)=>`rgb(${r*shade|0},${g*shade|0},${b*shade|0})`;
    const strip=(z0,z1,fill)=>{const t=Math.max(30,screen(z1)),b=Math.min(335,screen(z0));if(b>t){c.fillStyle=fill;c.fillRect(x,t,2,b-t);}};
    if(hit.kind==='rack'){
     const along=hit.axis?s.pose[0]+Math.cos(dir)*hit.t:s.pose[1]+Math.sin(dir)*hit.t;
     c.fillStyle=color(183+(hit.i%3)*9,144,93);c.fillRect(x,top,2,bottom-top);
     if(((along%.5)+.5)%.5<.045){c.fillStyle=color(36,90,130);c.fillRect(x,top,2,bottom-top);}
     for(let z=0;z<2.2;z+=.55)strip(z,z+.045,color(36,90,130));
    }else if(hit.kind==='person'){
     const o=hit.o,lateral=(s.pose[0]+Math.cos(dir)*hit.t-o.x)*Math.sin(s.yaw)-(s.pose[1]+Math.sin(dir)*hit.t-o.y)*Math.cos(s.yaw),a=Math.abs(lateral);
     if(a<.12){const extent=.16*Math.sqrt(1-(a/.12)**2);strip(1.59-extent,1.59+extent,color(207,159,122));if(a<.1)strip(1.67,1.74,color(244,196,52));}
     if(a<.21)strip(.75,1.43,color(a>.17?200:235,a>.17?154:124,a>.17?120:32));
     if(a<.17){strip(.91,.98,color(208,218,62));strip(1.2,1.27,color(208,218,62));}
     const gait=Math.sin(o.walk_phase||0)*.025;if(Math.min(Math.abs(lateral-.105-gait),Math.abs(lateral+.105+gait))<.055){strip(.09,.75,color(39,51,70));strip(0,.09,color(24,29,38));}
    }else if(hit.kind==='object'){strip(0,.7,color(46,55,66));strip(.12,.6,color(235,135,35));}
    else{c.fillStyle=color(151,168,180);c.fillRect(x,top,2,bottom-top);for(let z=0;z<2.2;z+=.65)strip(z,z+.025,color(104,127,144));}
   }
  }
  c.fillStyle='#14243b';c.fillRect(0,0,640,29);c.fillRect(0,335,640,25);c.font='12px sans-serif';c.fillStyle='#e9f2fc';c.fillText('AMR-01 / FRONT CAMERA / SYNTHETIC 3D',12,19);c.fillText(`x ${s.pose[0].toFixed(2)}  y ${s.pose[1].toFixed(2)}  | FOV 80° | height 0.85m`,12,352);
  c.fillStyle='#6be4cd';c.fillText('L',16,49);c.fillText('FRONT',298,49);c.fillText('R',615,49);c.fillRect(312,horizon-1,16,2);c.fillRect(319,horizon-8,2,16);
 }
 function drawOverview(s){
  const c=overview,w=map.center_bounds[2],h=map.center_bounds[3],scale=Math.min(480/(w+h),260/(w+h)*1.8);
  const p=(x,y,z=0)=>[320+(x-y)*scale,95+(x+y)*scale*.48-z*scale*.8];
  const line=(points,color,width=1)=>{c.beginPath();points.forEach((v,i)=>i?c.lineTo(...v):c.moveTo(...v));c.strokeStyle=color;c.lineWidth=width;c.stroke();};
  const polygon=(points,fill)=>{c.beginPath();points.forEach((v,i)=>i?c.lineTo(...v):c.moveTo(...v));c.closePath();c.fillStyle=fill;c.fill();};
  const box=(x,y,a,b,z,colors)=>{polygon([p(x,y),p(a,y),p(a,y,z),p(x,y,z)],colors[0]);polygon([p(a,y),p(a,b),p(a,b,z),p(a,y,z)],colors[1]);polygon([p(x,y,z),p(a,y,z),p(a,b,z),p(x,b,z)],colors[2]);};
  c.fillStyle='#e9eff6';c.fillRect(0,0,640,440);polygon([p(0,0),p(w,0),p(w,h),p(0,h)],'#c7d5de');
  for(let x=0;x<=w;x++)line([p(x,0),p(x,h)],'#b0c4ce');for(let y=0;y<=h;y++)line([p(0,y),p(w,y)],'#b0c4ce');
  const [x,y]=s.pose,arc=[];for(let i=0;i<=40;i++){const a=s.yaw+FOV/2-i*FOV/40,all=hits(s,a,false),d=Math.min(3,all.length?all[all.length-1].t:3);arc.push(p(x+Math.cos(a)*d,y+Math.sin(a)*d,.02));}polygon([p(x,y,.02),...arc],'#16b89d55');
  [...map.walls].sort((a,b)=>a[0]+a[1]-b[0]-b[1]).forEach(v=>box(...v,.8,['#718b9b','#365773','#bca781']));
  if(s.route?.length)line([s.pose,...s.route].map(v=>p(...v,.04)),'#287dd4',3);
  for(const o of s.obstacles){const r=o.radius;if(o.kind==='person'){const foot=p(o.x,o.y,.03),hip=p(o.x,o.y,.55),shoulder=p(o.x,o.y,1.05),head=p(o.x,o.y,1.25);line([[foot[0]-4,foot[1]],hip,[foot[0]+4,foot[1]]],'#293950',3);line([hip,shoulder],'#dc832e',7);line([[shoulder[0]-6,shoulder[1]+10],shoulder,[shoulder[0]+6,shoulder[1]+10]],'#cfa276',3);c.beginPath();c.arc(...head,4,0,Math.PI*2);c.fillStyle='#efc554';c.fill();}else box(o.x-r,o.y-r,o.x+r,o.y+r,.35,['#f1ae51','#c6802e','#ffcc78']);}
  const r=map.robot_radius;box(x-r,y-r,x+r,y+r,.3,['#377ddd','#2254a2','#94c4ff']);
  const origin=p(x,y,.34);for(const [label,angle] of [['L',s.yaw+FOV/2],['R',s.yaw-FOV/2],['FRONT',s.yaw]]){const end=p(x+Math.cos(angle)*1.2,y+Math.sin(angle)*1.2,.34);line([origin,end],'#075d51',label==='FRONT'?4:2);c.font='11px sans-serif';c.fillStyle='#f0fffa';c.fillRect(end[0]+1,end[1]-14,label==='FRONT'?42:12,15);c.fillStyle='#075d51';c.fillText(label,end[0]+3,end[1]-3);}
  c.fillStyle='#263f58';c.font='12px sans-serif';c.fillText('WAREHOUSE / 3D OVERVIEW (shelf height reduced)',20,25);c.fillStyle='#137565';c.fillText(`Heading ${((s.yaw*180/Math.PI+360)%360).toFixed(0)}° / camera FOV 80°`,20,45);c.fillStyle='#496178';c.fillText('Blue: robot / Orange: dynamic obstacle / Green: camera direction',20,423);
 }
 function tick(now){
  requestAnimationFrame(tick);
  if(!visible()){lastDraw=0;windowStart=now;count=0;return;}
  if(!map||!frames.length||now-lastDraw<1000/30-.5)return;
  lastDraw=lastDraw?lastDraw+Math.max(1,Math.floor((now-lastDraw)/(1000/30)))*(1000/30):now;
  const start=performance.now(),s=sample(now);drawFront(s);drawOverview(s);window.drawYoloOverlay?.(s,now);cost=performance.now()-start;total++;count++;
  for(const c of canvases)c.dataset.frame=String(total);
  const stale=now-received>600;
  if(now-windowStart>=1000){fps=count*1000/(now-windowStart);count=0;windowStart=now;
   $('camera-status').textContent=stale?'상태 수신 지연 · 마지막 화면':`● ${fps.toFixed(0)} FPS · 목표 30`;
   $('view-alignment').textContent=`동일 상태로 두 시점 렌더링 · 화면 ${fps.toFixed(1)} FPS / ROS 10Hz · 표시 보간 150ms · 위치 (${s.pose.map(v=>v.toFixed(2)).join(', ')})m · L / FRONT / R = 좌 / 정면 / 우`;
  }
  window.warehouseViewStats={fps,renderMs:cost,frames:total,stale,pose:s.pose,yaw:s.yaw,targetFPS:30};
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden){frames=[];}else{received=0;receive();}});
 requestAnimationFrame(tick);
})();

// One camera worker drives navigation and publishes the exact inspected frame.
(()=>{
 const source=$('live-camera'),toggle=$('yolo-visible'),status=$('yolo-status'),details=$('yolo-details');
 const wrap=document.createElement('div');wrap.className='yolo-live-wrap';source.before(wrap);wrap.append(source);
 const layer=document.createElement('canvas');layer.id='yolo-overlay';layer.width=640;layer.height=360;layer.setAttribute('aria-hidden','true');wrap.append(layer);
 const ctx=layer.getContext('2d'),preview=$('yolo-frame').getContext('2d');
 let result=null,pending=false;
 try{toggle.checked=localStorage.getItem('factory-yolo-visible')!=='false';}catch{}
 function update(){ctx.clearRect(0,0,640,360);layer.hidden=!toggle.checked;details.hidden=!toggle.checked;try{localStorage.setItem('factory-yolo-visible',String(toggle.checked));}catch{}}
 toggle.addEventListener('change',update);update();
 function boxes(c,items){c.font='bold 13px sans-serif';c.lineWidth=2;for(const d of items){const [x,y,x2,y2]=d.xyxy;c.strokeStyle='#26f5a7';c.strokeRect(x,y,x2-x,y2-y);const label=`장애물 ${Math.round(d.confidence*100)}%`,w=c.measureText(label).width+12,tx=Math.max(0,Math.min(x,640-w)),ty=Math.max(18,y);c.fillStyle='#102d29';c.fillRect(tx,ty-18,w,19);c.fillStyle='#a4ffde';c.fillText(label,tx+6,ty-4);}}
 window.drawYoloOverlay=(scene,now)=>{
  ctx.clearRect(0,0,640,360);if(!toggle.checked||!result||Date.now()/1000-result.stamp>1.2)return;
  // Short-lived reprojection uses only camera pose and the detected box's floor contact.
  const f=320/Math.tan(40*Math.PI/180),items=[];
  for(const d of result.detections){let [x,y,x2,y2]=d.xyxy;const depth=.85*f/Math.max(20,y2-145),side=((x+x2)/2-320)*depth/f;
   const wx=result.pose[0]+Math.cos(result.yaw)*depth+Math.sin(result.yaw)*side,wy=result.pose[1]+Math.sin(result.yaw)*depth-Math.cos(result.yaw)*side;
   const dx=wx-scene.pose[0],dy=wy-scene.pose[1],forward=dx*Math.cos(scene.yaw)+dy*Math.sin(scene.yaw);if(forward<.1)continue;
   const center=320+f*(dx*Math.sin(scene.yaw)-dy*Math.cos(scene.yaw))/forward,scale=depth/forward,bottom=145+.85*f/forward;
   if(scale<.65||scale>1.5)continue;
   items.push({...d,xyxy:[center-(x2-x)*scale/2,bottom-(y2-y)*scale,center+(x2-x)*scale/2,bottom]});
  }
  boxes(ctx,items);
 };
 async function pollVision(){
  if(pending||document.hidden||currentView!=='live')return;pending=true;
  try{const response=await fetch('/api/vision/status',{cache:'no-store',signal:AbortSignal.timeout(2500)});if(!response.ok)throw Error();const data=await response.json();
   if(!data.id){status.textContent='카메라 분석기 연결 대기 · 주행 대기';return;}
   const age=Date.now()/1000-data.stamp;
   status.textContent=(toggle.checked?'표시':'숨김')+` · ${data.detections.length}개 · ${Math.round(data.inference_ms)}ms`+(age>1.2?' · 영상 지연':' · 카메라 주행');
   if(result?.id===data.id)return;const img=new Image();img.src='data:image/png;base64,'+data.image;await img.decode();result=data;preview.drawImage(img,0,0);boxes(preview,data.detections);
   $('yolo-result').textContent=`${new Date(data.stamp*1000).toLocaleTimeString('ko-KR',{hour12:false})} · 실제 주행 판단에 사용한 전방 프레임 · 장애물 ${data.detections.length}개 · ${data.model}`;
   window.yoloViewStats={...data,image:undefined,age_seconds:age};
  }catch(e){status.textContent='카메라 분석 연결 대기';}finally{pending=false;}
 }
 setInterval(pollVision,200);
})();
