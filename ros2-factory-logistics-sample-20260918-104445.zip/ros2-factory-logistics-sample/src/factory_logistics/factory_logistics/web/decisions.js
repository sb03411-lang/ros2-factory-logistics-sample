'use strict';
let decisionsPaused=false, decisionsSignature='', decisionRequests='';
const decisionSources={CAMERA:'카메라',SENSOR:'거리 센서',PLANNER:'경로 탐색기',LLM:'LLM · Codex',VALIDATOR:'검증기',SYSTEM:'시스템',ROS:'ROS 실행'};
function renderDecisions(){
 const all=snapshot?.ai?.logs||[];
 $('decision-view-state').textContent=decisionsPaused?'화면 표시 일시정지 중':!snapshot?.connected?'서버 연결 끊김 · 마지막 수신 로그':'실시간 수신 · 출처별로 판단과 검증 결과를 확인하세요';
 if(decisionsPaused)return;
 const ids=[...new Set(all.map(entry=>entry.request_id).filter(Boolean))];
 const requestSignature=JSON.stringify(ids);
 if(requestSignature!==decisionRequests){
  decisionRequests=requestSignature;const selected=$('decision-request').value;
  $('decision-request').replaceChildren(...['ALL',...ids].map(id=>{const option=text('option',id==='ALL'?'모든 요청':id);option.value=id;return option;}));
  if(selected==='ALL'||ids.includes(selected))$('decision-request').value=selected;
 }
 const source=$('decision-source').value,request=$('decision-request').value,query=$('decision-search').value.toLowerCase().trim();
 const logs=all.filter(entry=>(source==='ALL'||entry.source===source)&&(request==='ALL'||entry.request_id===request)&&(!query||JSON.stringify(entry).toLowerCase().includes(query)));
 const signature=JSON.stringify(logs);if(signature===decisionsSignature)return;decisionsSignature=signature;
 const expanded=new Set([...$('decision-entries').querySelectorAll('details[open]')].map(el=>el.dataset.id));
 $('decision-count').textContent=`${logs.length} / ${all.length}`;
 $('decision-entries').replaceChildren(...logs.map(entry=>{
  const item=document.createElement('article');item.className='decision-entry decision-'+entry.source;
  const heading=text('div','','decision-entry-heading');
  heading.append(text('span',decisionSources[entry.source]||entry.source,'decision-source source-'+entry.source),text('strong',entry.stage),text('span',entry.level,'decision-level level-'+entry.level),text('time',new Date(entry.stamp*1000).toLocaleTimeString('ko-KR',{hour12:false})));
  item.append(heading,text('p',entry.message,'decision-message'));
  const meta=text('div',(entry.request_id||'지도 시스템')+' · '+entry.map_id,'decision-meta');item.append(meta);
  if(Object.keys(entry.details||{}).length){const details=document.createElement('details');details.dataset.id=String(entry.id);details.open=expanded.has(String(entry.id));details.append(text('summary',entry.source==='LLM'?'모델이 반환한 목표·좌표 보기':'검증·실행 데이터 보기'),text('pre',JSON.stringify(entry.details,null,2)));item.append(details);}
  return item;
 }));
 if(!logs.length)$('decision-entries').append(text('p',all.length?'조건에 맞는 판단 로그가 없습니다.':'Codex로 도면 읽기를 실행하면 요청과 판단 근거가 여기에 표시됩니다.','logs-empty'));
}
$('decision-source').addEventListener('change',renderDecisions);
$('decision-request').addEventListener('change',renderDecisions);
$('decision-search').addEventListener('input',renderDecisions);
$('decision-pause').addEventListener('click',()=>{decisionsPaused=!decisionsPaused;$('decision-pause').textContent=decisionsPaused?'표시 재개':'표시 일시정지';renderDecisions();});
$('decision-reset').addEventListener('click',()=>{decisionsPaused=false;$('decision-source').value='ALL';$('decision-request').value='ALL';$('decision-search').value='';$('decision-pause').textContent='표시 일시정지';renderDecisions();$('decision-entries').scrollTop=0;});
