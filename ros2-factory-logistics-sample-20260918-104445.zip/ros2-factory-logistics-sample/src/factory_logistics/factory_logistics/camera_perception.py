"""Obstacle memory from camera boxes only; no world obstacle coordinates."""
import copy
import math


class CameraPerception:
    RANGE=4.5
    def __init__(self,base):
        self.tracks={};self.visible=set();self.revision=0
        self.last_frame=-1e9;self.frame_pose=None;self.frame_yaw=0.;self.sequence=0
        self.detections=[];self.model='';self.inference_ms=0.;self.uncertain=False
        self.sight=copy.copy(base) if base is not None else None
        if self.sight:
            self.sight.radius=0.;self.sight.inflated=self.sight.walls

    def scan(self,pose,world,now):
        raise RuntimeError('Camera perception must not read world objects')

    def _empty_visible(self,o,pose,yaw,boxes):
        dx,dy=o['x']-pose[0],o['y']-pose[1]
        forward=dx*math.cos(yaw)+dy*math.sin(yaw)
        if not .6<forward<self.RANGE:return False
        f=320/math.tan(math.radians(40))
        center=320+f*(dx*math.sin(yaw)-dy*math.cos(yaw))/forward
        half=f*o['radius']/forward
        minimum_top=145+(.85-.7)*f/forward
        # Simulated objects are at least .7m tall: require their expected
        # upper portion inside the image, even when floor contact is cropped.
        # Shelves and foreground detections must not occlude that region.
        if center-half<35 or center+half>605 or minimum_top>300:return False
        if self.sight and not self.sight.segment_free(pose,[o['x'],o['y']]):return False
        return not any(b['xyxy'][0]<center+half and b['xyxy'][2]>center-half for b in boxes)

    def accept(self,boxes,pose,yaw,captured,now,model='',inference_ms=0):
        if not isinstance(boxes,list) or len(boxes)>30:raise ValueError('잘못된 카메라 탐지')
        estimates=[];valid=[];f=320/math.tan(math.radians(40))
        for b in boxes:
            if b.get('label')!='obstacle':continue
            confidence=float(b.get('confidence',0));rect=b.get('xyxy',[])
            if len(rect)!=4 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in rect):raise ValueError('잘못된 탐지 좌표')
            x,y,x2,y2=rect
            if not (0<=x<x2<=640 and 0<=y<y2<=360 and math.isfinite(confidence)):raise ValueError('잘못된 탐지 범위')
            if confidence<.35:continue
            valid.append(b)
            if y2<=150:continue
            floor_depth=.85*f/(y2-145)
            if floor_depth>self.RANGE:continue
            # Smooth transition instead of the former 315px discontinuity.
            u=max(0.,min(1.,(y2-280)/55));blend=u*u*(3-2*u)
            depth=floor_depth*(1-blend)+1.1*blend
            side=((x+x2)/2-320)*depth/f
            radius=max(.10,min(.32,(x2-x)*depth/f/2))+.08
            depth+=max(0,radius-.08)
            wx=pose[0]+math.cos(yaw)*depth+math.sin(yaw)*side
            wy=pose[1]+math.sin(yaw)*depth-math.cos(yaw)*side
            estimates.append(dict(x=wx,y=wy,radius=radius,label='obstacle',confidence=confidence,cropped=blend>.5,blend=blend,box_width=x2-x,screen_center=(x+x2)/2))
        new=[];used=set();visible=set();changed=False
        for e in sorted(estimates,key=lambda v:-v['confidence']):
            matches=[(math.hypot(e['x']-o['x'],e['y']-o['y']),k) for k,o in self.tracks.items() if k not in used]
            match=min(matches,default=(999,None));key=match[1] if match[0]<.85 else None
            if key is None:
                # Suppress overlapping duplicate boxes in the same frame.
                if any(math.dist([e['x'],e['y']],[self.tracks[k]['x'],self.tracks[k]['y']])<.3 for k in used):continue
                self.sequence+=1;key='V-'+str(self.sequence);new.append(key)
            old=self.tracks.get(key);hits=old['hits']+1 if old else 1
            if old:
                # Use the last fully visible physical width when feet become
                # cropped; scale changes still reveal an approaching object.
                if old.get('grounded') and e['blend']>0:
                    wd=max(.35,min(4.5,2*max(.05,old['radius']-.08)*f/e['box_width']))
                    side=(e['screen_center']-320)*wd/f
                    center_depth=wd+max(0,old['radius']-.08)
                    px=pose[0]+math.cos(yaw)*center_depth+math.sin(yaw)*side
                    py=pose[1]+math.sin(yaw)*center_depth-math.cos(yaw)*side
                    e['x']+=(px-e['x'])*e['blend'];e['y']+=(py-e['y'])*e['blend']
                    e['radius']+=(old['radius']-e['radius'])*e['blend']
                for field in ('x','y','radius'):e[field]=old[field]+.35*(e[field]-old[field])
            history=[h for h in (old.get('history') or []) if now-h['t']<=2.0] if old else []
            history.append(dict(t=now,x=e['x'],y=e['y'],pose=list(pose),depth=depth,screen_center=e['screen_center']))
            vx=old.get('vx',0.) if old else 0.
            vy=old.get('vy',0.) if old else 0.
            speed=old.get('speed',0.) if old else 0.
            moving_until=old.get('moving_until',0.) if old else 0.
            past_samples=[h for h in history if now-h['t']>=0.25]
            if past_samples:
                h0=past_samples[0];dt=now-h0['t']
                dx=e['x']-h0['x'];dy=e['y']-h0['y']
                disp=math.hypot(dx,dy);inst_speed=disp/dt
                # Suppress ID-switch teleportation (> 1.8 m/s)
                if inst_speed<=1.8:
                    if disp>0.12 and inst_speed>=0.10:
                        vx=dx/dt;vy=dy/dt;speed=inst_speed
                        moving_until=max(moving_until,now+4.5)
                    elif dt>=0.8 and disp<0.08:
                        vx=0.;vy=0.;speed=0.
                        if now>=moving_until:moving_until=0.
            anchor=old.get('anchor') if old else None
            if anchor is None:anchor=[e['x'],e['y'],now]
            elif now-anchor[2]>=1.:
                if math.dist(anchor[:2],[e['x'],e['y']])>.3:moving_until=max(moving_until,now+5.)
                anchor=[e['x'],e['y'],now]
            if now>=moving_until:moving_until=0.
            moving=(now<moving_until) or (speed>=0.10)
            # Radial speed towards current robot pose: eliminates ego-motion false positives
            to_rx,to_ry=pose[0]-e['x'],pose[1]-e['y']
            dist_to_r=math.hypot(to_rx,to_ry)
            if dist_to_r>1e-6 and moving and speed>=0.10:
                radial_speed=vx*(to_rx/dist_to_r)+vy*(to_ry/dist_to_r)
                approaching=bool(radial_speed>=0.08)
            else:
                approaching=False
            if old and (math.dist([e['x'],e['y']],[old['x'],old['y']])>.08 or abs(e['radius']-old['radius'])>.04):changed=True
            self.tracks[key]=dict(e,id=key,last_seen=now,moving=moving,moving_until=moving_until,
                vx=vx,vy=vy,speed=speed,approaching=approaching,history=history,hits=hits,anchor=anchor,
                grounded=bool((old and old.get('grounded')) or not e['cropped']),empty_since=None,empty_frames=0)
            if hits==2:changed=True
            used.add(key);visible.add(key)
        cleared=[]
        for key,o in list(self.tracks.items()):
            if key in visible:continue
            age=now-o['last_seen']
            empty=self._empty_visible(o,pose,yaw,valid)
            if empty:
                if o.get('empty_since') is None:o['empty_since']=now
                o['empty_frames']=o.get('empty_frames',0)+1
            else:o['empty_since']=None;o['empty_frames']=0
            clear=empty and o['empty_frames']>=4 and now-o['empty_since']>=1.2
            # Unconfirmed flashes and formerly moving objects have bounded
            # memory. Confirmed stationary obstacles require visual clearance.
            expired=(o['hits']<2 and age>5) or (o['moving_until']>0 and age>15)
            if clear or expired:del self.tracks[key];cleared.append(key)
        self.visible=visible;self.last_frame=captured;self.frame_pose=list(pose);self.frame_yaw=yaw
        self.detections=valid;self.model=model;self.inference_ms=inference_ms
        if new or cleared or changed:self.revision+=1
        return new,cleared

    def ready(self,pose,yaw,now):
        return (self.frame_pose is not None and now-self.last_frame<1.2 and
                math.dist(pose,self.frame_pose)<.25 and
                abs(math.atan2(math.sin(yaw-self.frame_yaw),math.cos(yaw-self.frame_yaw)))<.07)

    def snapshot(self,now):
        tracks=[]
        for k,o in self.tracks.items():
            t=dict(o)
            t.pop('history',None)
            t.update(uncertain_memory=now-o['last_seen']>20,visible=k in self.visible,age_seconds=round(now-o['last_seen'],2))
            tracks.append(t)
        return dict(type='camera_yolo',range_m=self.RANGE,fov_deg=80,model=self.model,inference_ms=self.inference_ms,
                    frame_age_seconds=round(now-self.last_frame,2) if self.frame_pose else None,uncertain=self.uncertain,
                    tracks=tracks,visible_ids=sorted(self.visible))
