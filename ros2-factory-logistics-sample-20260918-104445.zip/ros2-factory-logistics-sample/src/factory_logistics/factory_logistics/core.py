"""ROS-independent, single-robot transport simulation.

Distances use metres and time uses seconds. Callers must serialize access (for
example, with an external lock in a ROS executor). Accepted job IDs are retained
for this process lifetime, including canceled and failed jobs; they are not
persisted across restarts. IDs and station names must have no outer whitespace.
"""

import json
import math
from collections.abc import Mapping
from numbers import Real
from pathlib import Path
from typing import Any, Dict, Optional


def _finite_number(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError("{} must be a finite number".format(name))
    try:
        number = float(value)
    except (ValueError, OverflowError) as error:
        raise ValueError("{} must be a finite number".format(name)) from error
    if not math.isfinite(number):
        raise ValueError("{} must be a finite number".format(name))
    return number


def _identifier(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError("{} must be nonempty with no outer whitespace".format(name))
    return value


class TransportCore:
    """Move between stations; an optional navigation map enforces wall avoidance.

    ``stations`` maps names to two-element lists or tuples of finite (x, y)
    coordinates. ``warehouse`` is required and determines the initial pose.
    Construction copies the configuration. Invalid requests leave existing state
    unchanged; an accepted ID can never be reused by this instance.
    """

    def __init__(self, stations: Optional[Mapping] = None, speed: float = 1.0, navigation=None):
        self.navigation = navigation
        self._route = []
        self._route_index = 0
        self._blocked = False
        self._speed = _finite_number(speed, "speed")
        if self._speed <= 0:
            raise ValueError("speed must be positive")
        if stations is None and navigation is not None:stations=navigation.data.get('stations')
        if stations is None:
            config_path = Path(__file__).with_name("stations.json")
            with config_path.open(encoding="utf-8") as config_file:
                stations = json.load(config_file)
        if not isinstance(stations, Mapping) or "warehouse" not in stations:
            raise ValueError("stations must be a mapping containing warehouse")
        self._stations = {}
        for name, coordinates in stations.items():
            _identifier(name, "station name")
            if not isinstance(coordinates, (list, tuple)) or len(coordinates) != 2:
                raise ValueError("station {} requires [x, y] coordinates".format(name))
            self._stations[name] = (
                _finite_number(coordinates[0], "{}.x".format(name)),
                _finite_number(coordinates[1], "{}.y".format(name)),
            )
        # Finite coordinates can still have an unrepresentable separation.
        xs, ys = zip(*self._stations.values())
        if not math.isfinite(math.hypot(max(xs) - min(xs), max(ys) - min(ys))):
            raise ValueError("station distances must fit in a finite float")

        self._x, self._y = self._stations["warehouse"]
        self._target = (self._x, self._y)
        self._accepted_ids = set()
        self._job_id = ""
        self._destination = ""
        self._state = "IDLE"
        self._message = "Ready at warehouse."

    @property
    def busy(self) -> bool:
        return self._state == "RUNNING"

    def start(self, job_id: str, destination: str) -> None:
        """Accept one job or raise ValueError without changing existing state."""
        _identifier(job_id, "job_id")
        _identifier(destination, "destination")
        if destination not in self._stations:
            raise ValueError("unknown destination: {}".format(destination))
        if self.busy:
            raise ValueError("robot is already executing a job")
        if job_id in self._accepted_ids:
            raise ValueError("job_id was already accepted: {}".format(job_id))

        route = self.navigation.plan((self._x,self._y), self._stations[destination]) if self.navigation else [
            [self._x,self._y], list(self._stations[destination])]
        self._route, self._route_index, self._blocked = route[1:], 0, False
        self._accepted_ids.add(job_id)
        self._job_id = job_id
        self._destination = destination
        self._target = self._stations[destination]
        self._state = "RUNNING"
        self._message = "Moving to {}.".format(destination)

    def step(self, dt: float) -> None:
        """Advance by nonnegative finite seconds; zero is always a no-op.

        A goal at the current position completes on the first positive step.
        Terminal jobs never move, and arrival is clamped to the station pose.
        """
        dt = _finite_number(dt, "dt")
        if dt < 0:
            raise ValueError("dt must be nonnegative")
        if dt == 0 or not self.busy:
            return

        travel = self._speed * dt
        while self._route_index < len(self._route):
            target = self._route[self._route_index]
            dx,dy = target[0]-self._x,target[1]-self._y
            remaining = math.hypot(dx,dy)
            fraction = min(1., travel/remaining) if remaining else 1.
            next_pose = (target[0],target[1]) if fraction == 1 else (self._x+dx*fraction,self._y+dy*fraction)
            if self.navigation and not self.navigation.segment_free((self._x,self._y),next_pose):
                self.fail('Planned movement blocked by wall.')
                self._blocked = True
                return
            self._x,self._y = next_pose
            if fraction < 1:
                return
            travel -= remaining
            self._route_index += 1
            if travel <= 0 and self._route_index < len(self._route):
                return
        self._state = 'SUCCEEDED'
        self._message = 'Arrived at {}.'.format(self._destination)

    def manual_step(self, vx, vy, dt):
        """Map-frame translation, confined to the sample floor (0..3, 0..2 m)."""
        vx, vy, dt = (_finite_number(v, n) for v, n in ((vx, 'vx'), (vy, 'vy'), (dt, 'dt')))
        if dt < 0 or math.hypot(vx, vy) > 0.501:
            raise ValueError('invalid manual velocity or timestep')
        if self.busy:
            raise ValueError('automatic job is active')
        if vx or vy:
            x0,y0,x1,y1 = self.navigation.bounds if self.navigation else (0.,0.,3.,2.)
            candidate = (max(x0, min(x1, self._x + vx * dt)),max(y0, min(y1, self._y + vy * dt)))
            self._blocked = bool(self.navigation and not self.navigation.segment_free((self._x,self._y),candidate))
            if not self._blocked:
                self._x,self._y = candidate
            self._job_id, self._destination = '', ''
            self._target = (self._x, self._y)
            self._route,self._route_index = [],0
            self._state, self._message = 'MANUAL', 'Wall collision prevented.' if self._blocked else 'Manual map-frame movement.'
        elif self._state == 'MANUAL':
            self._state, self._message = 'IDLE', 'Manual movement stopped.'
            self._blocked = False

    def navigation_state(self):
        return {'path': [[self._x,self._y]] + [list(p) for p in self._route[self._route_index:]],
                'collision_blocked': self._blocked}

    def replace_navigation(self, navigation):
        """Install a checked map while retaining the robot pose and job history."""
        if self.busy or not navigation.point_free((self._x, self._y)):
            raise ValueError('Map replacement requires an idle robot in free space.')
        self.navigation = navigation
        self._stations = {k:tuple(v) for k,v in (navigation.data.get('stations') or json.loads(Path(__file__).with_name('stations.json').read_text())).items()}
        self._route, self._route_index, self._blocked = [], 0, False

    def begin_external_motion(self):
        if self.busy:
            raise ValueError('An automatic job is active.')
        self._job_id, self._destination = '', ''
        self._route, self._route_index, self._blocked = [], 0, False
        self._target = (self._x, self._y)
        self._state, self._message = 'IDLE', 'Observed-action controller owns movement.'

    def cancel(self) -> bool:
        """Stop an active simulated movement at its current pose."""
        if not self.busy:
            return False
        self._state = "CANCELED"
        self._message = "Canceled at current pose."
        return True

    def fail(self, message: str) -> None:
        """End an active job after an adapter error, retaining the current pose."""
        if self.busy:
            self._state = "FAILED"
            self._message = str(message)

    def snapshot(self) -> Dict[str, Any]:
        """Return a detached view; remaining distance also survives cancellation."""
        return {
            "job_id": self._job_id,
            "destination": self._destination,
            "state": self._state,
            "x": self._x,
            "y": self._y,
            "remaining_distance": sum(math.dist(a,b) for a,b in zip(
                self.navigation_state()['path'],self.navigation_state()['path'][1:])),
            "message": self._message,
        }
