"""Deterministic perspective warehouse renderer shared by live UI and vision input.

Extruded shelves and cylinders use ray depth, so objects behind shelves cannot
appear in the camera. This is a synthetic camera, not a physical sensor.
"""
import io
import math
from PIL import Image, ImageDraw

WIDTH, HEIGHT = 640, 360
FOV = math.radians(80)
CAMERA_HEIGHT = .85

def hit_box(origin, direction, box):
    near,far,side=0.,float('inf'),0
    for axis in (0,1):
        if abs(direction[axis])<1e-10:
            if not box[axis]<=origin[axis]<=box[axis+2]:return None
            continue
        a,b=sorted(((box[axis]-origin[axis])/direction[axis],(box[axis+2]-origin[axis])/direction[axis]))
        if a>near:near,side=a,axis
        far=min(far,b)
    if far<near or far<=0:return None
    return (near if near>1e-5 else far),side

def cast_ray(origin,direction,walls,obstacles,outer,all_hits=False):
    hits=[]
    for i,box in enumerate(walls):
        hit=hit_box(origin,direction,box)
        if hit:hits.append((hit[0],'rack',i,hit[1]))
    for i,o in enumerate(obstacles):
        dx,dy=origin[0]-o['x'],origin[1]-o['y']
        projection=dx*direction[0]+dy*direction[1]
        disc=projection*projection-(dx*dx+dy*dy-o['radius']**2)
        if disc>=0:
            t=-projection-math.sqrt(disc)
            if t>0:hits.append((t,'obstacle',i,0))
    hit=hit_box(origin,direction,outer)
    if hit:hits.append((hit[0],'boundary',0,hit[1]))
    hits=hits or [(30.,'boundary',0,0)]
    return sorted(hits,reverse=True) if all_hits else min(hits)

def render_camera(navigation,scene,annotations=False):
    image=Image.new('RGB',(WIDTH,HEIGHT));pixels=image.load()
    mask=Image.new('I',(WIDTH,HEIGHT),0) if annotations else None
    labels=mask.load() if mask is not None else None
    pose=scene['pose'];yaw=scene.get('yaw',0.);horizon=145
    cy,sy=math.cos(yaw),math.sin(yaw);draw=ImageDraw.Draw(image)
    focal=WIDTH/(2*math.tan(FOV/2))
    # Perspective floor tiles and ceiling; all pixels are generated locally.
    for y in range(HEIGHT):
        if y<=horizon:
            color=(int(48+y*.22),int(61+y*.22),int(76+y*.22))
            draw.line((0,y,WIDTH-1,y),fill=color)
        else:
            forward=CAMERA_HEIGHT*focal/(y-horizon)
            for x in range(0,WIDTH,2):
                side=(x-WIDTH/2)*forward/focal
                wx=pose[0]+cy*forward+sy*side
                wy=pose[1]+sy*forward-cy*side
                tile=(int(math.floor(wx*2))+int(math.floor(wy*2)))%2
                edge=min(wx% .5,wy% .5)<.012
                v=(112 if tile else 126) if not edge else 86
                if wx<0 or wy<0 or wx>navigation.bounds[2] or wy>navigation.bounds[3]:v=69
                pixels[x,y]=pixels[x+1,y]=(v,v+9,v+13)
    draw=ImageDraw.Draw(image)
    for x in range(0,WIDTH,2):
        angle=math.atan((x-WIDTH/2)/focal);direction=(math.cos(yaw-angle),math.sin(yaw-angle))
        for t,kind,index,axis in cast_ray(pose,direction,navigation.walls,scene.get('obstacles',[]),navigation.outer,all_hits=True):
            depth=max(.025,t*math.cos(angle));person=kind=='obstacle' and scene['obstacles'][index].get('kind')=='person'
            height=1.75 if person else .7 if kind=='obstacle' else 2.2
            top=max(0,int(horizon-(height-CAMERA_HEIGHT)*focal/depth));bottom=min(HEIGHT-1,int(horizon+CAMERA_HEIGHT*focal/depth))
            along=pose[1-axis]+direction[1-axis]*t
            shade=max(.3,1/(1+depth*.075))*(.83 if axis else 1)
            palette={}
            if person:
                o=scene['obstacles'][index]
                lateral=(pose[0]+direction[0]*t-o['x'])*sy-(pose[1]+direction[1]*t-o['y'])*cy
                gait=math.sin(o.get('walk_phase',0))*.025
            for y in range(top,bottom+1):
                z=CAMERA_HEIGHT+(horizon-y)*depth/focal
                if kind=='rack':
                    beam=(z%.55)<.045 or (along%.5)<.045
                    seam=(along%.5)>.465
                    base=(36,90,130) if beam else (77,74,65) if seam else (183+(index%3)*9,144,93)
                    if not beam and .21<(along%.5)<.26:base=(212,187,133)
                elif person:
                    if z>1.43:
                        if (lateral/.12)**2+((z-1.59)/.16)**2>1:continue
                        base=(244,196,52) if z>1.67 else (207,159,122)
                    elif z>.75:
                        width=.21 if z<1.28 else .17
                        if abs(lateral)>width:continue
                        base=(200,154,120) if abs(lateral)>.17 else (208,218,62) if .91<z<.98 or 1.2<z<1.27 else (235,124,32)
                    else:
                        if min(abs(lateral-.105-gait),abs(lateral+.105+gait))>.055:continue
                        base=(39,51,70) if z>.09 else (24,29,38)
                elif kind=='obstacle':base=(235,135,35) if .12<z<.6 else (46,55,66)
                else:base=(151,168,180) if z%.65>.025 else (104,127,144)
                color=palette.get(base)
                if color is None:color=palette[base]=tuple(int(c*shade) for c in base)
                pixels[x,y]=pixels[x+1,y]=color
                if labels is not None:labels[x,y]=labels[x+1,y]=index+1 if kind=='obstacle' else 0
    draw.rectangle((0,0,WIDTH,29),fill='#14243b')
    draw.text((12,9),'AMR-01 / FRONT CAMERA / SYNTHETIC 3D',fill='#e9f2fc')
    draw.text((16,43),'L',fill='#6be4cd')
    draw.text((WIDTH//2-16,43),'FRONT',fill='#6be4cd')
    draw.text((WIDTH-25,43),'R',fill='#6be4cd')
    draw.line((WIDTH//2-8,horizon,WIDTH//2+8,horizon),fill='#6be4cd',width=2)
    draw.line((WIDTH//2,horizon-8,WIDTH//2,horizon+8),fill='#6be4cd',width=2)
    draw.rectangle((0,HEIGHT-25,WIDTH,HEIGHT),fill='#14243b')
    draw.text((12,HEIGHT-17),'x {:.2f}  y {:.2f}  heading {:03.0f} deg | FOV 80 | height 0.85m'.format(*pose,math.degrees(yaw)%360),fill='#d4e4f5')
    output=io.BytesIO();image.save(output,format='PNG')
    if annotations:
        boxes=[]
        for i,o in enumerate(scene.get('obstacles',[])):
            coords=[(x,y) for y in range(30,HEIGHT-25) for x in range(0,WIDTH,2) if labels[x,y]==i+1]
            if len(coords)<35:continue
            xs,ys=zip(*coords);boxes.append(dict(kind=o.get('kind','obstacle'),xyxy=[min(xs),min(ys),max(xs)+2,max(ys)+1]))
        return output.getvalue(),boxes
    return output.getvalue()

def render_overview(navigation,scene):
    image=Image.new('RGB',(640,440),'#e9eff6');draw=ImageDraw.Draw(image)
    w,h=navigation.bounds[2:];scale=min(480/(w+h),260/(w+h)*1.8)
    def p(x,y,z=0):return (320+(x-y)*scale,95+(x+y)*scale*.48-z*scale*.8)
    def box(a,b,c,d,z,color):
        draw.polygon([p(a,b),p(c,b),p(c,b,z),p(a,b,z)],fill=color[0],outline='#466078')
        draw.polygon([p(c,b),p(c,d),p(c,d,z),p(c,b,z)],fill=color[1],outline='#466078')
        draw.polygon([p(a,b,z),p(c,b,z),p(c,d,z),p(a,d,z)],fill=color[2],outline='#466078')
    draw.polygon([p(0,0),p(w,0),p(w,h),p(0,h)],fill='#c7d5de',outline='#8198a8')
    for i in range(math.ceil(w)+1):draw.line([p(i,0),p(i,h)],fill='#b0c4ce')
    for j in range(math.ceil(h)+1):draw.line([p(0,j),p(w,j)],fill='#b0c4ce')
    # Same yaw and FOV as the first-person renderer; left is yaw + FOV/2.
    x,y=scene['pose'];yaw=scene.get('yaw',0)
    arc=[]
    for i in range(41):
        angle=yaw+FOV/2-i*FOV/40
        direction=(math.cos(angle),math.sin(angle))
        distance=min(3.,cast_ray((x,y),direction,navigation.walls,[],navigation.outer)[0])
        arc.append(p(x+direction[0]*distance,y+direction[1]*distance,.02))
    overlay=Image.new('RGBA',image.size);od=ImageDraw.Draw(overlay)
    od.polygon([p(x,y,.02)]+arc,fill=(22,184,157,75))
    image=Image.alpha_composite(image.convert('RGBA'),overlay).convert('RGB');draw=ImageDraw.Draw(image)
    for wall in sorted(navigation.walls,key=lambda b:b[0]+b[1]):box(*wall,.8,('#718b9b','#365773','#bca781'))
    route=[scene['pose']]+scene.get('route',[])
    if len(route)>1:draw.line([p(*v,.04) for v in route],fill='#287dd4',width=3)
    for o in scene.get('obstacles',[]):
        x,y,r=o['x'],o['y'],o['radius']
        if o.get('kind')=='person':
            foot=p(x,y,.03);hip=p(x,y,.55);shoulder=p(x,y,1.05);head=p(x,y,1.25)
            draw.line([(foot[0]-4,foot[1]),hip,(foot[0]+4,foot[1])],fill='#293950',width=3)
            draw.line([hip,shoulder],fill='#dc832e',width=7)
            draw.line([(shoulder[0]-6,shoulder[1]+10),shoulder,(shoulder[0]+6,shoulder[1]+10)],fill='#cfa276',width=3)
            draw.ellipse((head[0]-4,head[1]-4,head[0]+4,head[1]+4),fill='#efc554',outline='#7b6640')
        else:box(x-r,y-r,x+r,y+r,.35,('#f1ae51','#c6802e','#ffcc78'))
    x,y=scene['pose'];r=navigation.body_radius;box(x-r,y-r,x+r,y+r,.3,('#377ddd','#2254a2','#94c4ff'))
    origin=p(x,y,.34)
    for label,angle,color in [('L',yaw+FOV/2,'#158a7a'),('R',yaw-FOV/2,'#158a7a'),('FRONT',yaw,'#075d51')]:
        end=p(x+math.cos(angle)*1.0,y+math.sin(angle)*1.0,.34)
        draw.line([origin,end],fill=color,width=4 if label=='FRONT' else 2)
        if label=='FRONT':
            dx,dy=end[0]-origin[0],end[1]-origin[1];length=math.hypot(dx,dy);ux,uy=dx/length,dy/length
            draw.polygon([end,(end[0]-9*ux+4*uy,end[1]-9*uy-4*ux),(end[0]-9*ux-4*uy,end[1]-9*uy+4*ux)],fill=color)
        tx,ty=end[0]+4,end[1]-12
        draw.rectangle((tx-2,ty-2,tx+(32 if label=='FRONT' else 8),ty+11),fill='#f0fffa')
        draw.text((tx,ty),label,fill=color)
    draw.text((20,40),'Heading {:03.0f} deg / camera FOV 80 / view guide 3m'.format(math.degrees(yaw)%360),fill='#137565')
    draw.text((20,20),'WAREHOUSE / 3D OVERVIEW (shelf height reduced)',fill='#263f58')
    draw.text((20,414),'Blue: robot / Orange: dynamic obstacle / Route: navigation planner',fill='#496178')
    output=io.BytesIO();image.save(output,format='PNG');return output.getvalue()
