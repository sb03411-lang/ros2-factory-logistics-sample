"""Validated editable maps and atomic persistence. Only the robot writes maps."""
import hashlib
import json
import math
import os
import tempfile
from pathlib import Path
from factory_logistics.navigation import NavigationMap


def validate_map(data, pose=None):
    if not isinstance(data, dict):
        raise ValueError('도면 형식이 올바르지 않습니다.')
    bounds = data.get('center_bounds')
    if (not isinstance(bounds, list) or len(bounds) != 4
            or any(type(v) not in (int, float) or not math.isfinite(v) for v in bounds)
            or bounds[:2] != [0, 0] or not 3 <= bounds[2] <= 8 or not 2 <= bounds[3] <= 8):
        raise ValueError('도면 크기는 가로 3~8m, 세로 2~8m여야 합니다.')
    width, height = bounds[2:]
    walls = data.get('walls')
    if not isinstance(walls, list) or len(walls) > 32:
        raise ValueError('장애물은 최대 32개까지 배치할 수 있습니다.')
    for wall in walls:
        if (not isinstance(wall, list) or len(wall) != 4
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in wall)
                or not 0 <= wall[0] < wall[2] <= width
                or not 0 <= wall[1] < wall[3] <= height
                or min(wall[2]-wall[0], wall[3]-wall[1]) < .099999):
            raise ValueError('장애물은 도면 안에 있고 가로·세로가 0.1m 이상이어야 합니다.')
    radius=data.get('robot_radius',.12);clearance=data.get('robot_clearance',0.)
    if type(radius) not in (int,float) or type(clearance) not in (int,float) or not math.isfinite(radius+clearance) or not .1<=radius<=.4 or not 0<=clearance<=.2:raise ValueError('로봇 반경 0.1~0.4m, 여유 거리 0~0.2m 범위입니다.')
    margin=max(.3,radius+clearance+.05)
    canonical = dict(resolution=.1, robot_radius=radius, center_bounds=bounds,
                     outer_bounds=[-margin, -margin, width+margin, height+margin], walls=walls)
    if clearance:canonical['robot_clearance']=clearance
    if 'stations' in data:
        stations=data['stations']
        if not isinstance(stations,dict) or set(stations)!={'warehouse','line_a','line_b'} or any(not isinstance(v,list) or len(v)!=2 or any(type(x) not in (int,float) or not math.isfinite(x) for x in v) for v in stations.values()):
            raise ValueError('입고·출고·피킹 목적지 좌표가 올바르지 않습니다.')
        canonical['stations']=stations
    canonical = json.loads(json.dumps(canonical))
    canonical['id'] = 'map-' + hashlib.sha256(json.dumps(canonical, sort_keys=True).encode()).hexdigest()[:16]
    navigation = NavigationMap(canonical)
    stations = canonical.get('stations') or json.loads(Path(__file__).with_name('stations.json').read_text())
    if pose is not None and not navigation.point_free(pose):
        raise ValueError('현재 로봇 위치에 장애물을 놓거나 도면 밖으로 잘라낼 수 없습니다.')
    for name, target in stations.items():
        if not navigation.point_free(target):
            raise ValueError('{} 목적지와 로봇 안전 반경 {:.2f}m 공간을 비워 주세요.'.format(name,radius+clearance))
        try:
            navigation.plan(pose if pose is not None else stations['warehouse'], target)
        except ValueError:
            raise ValueError('{} 목적지까지 통로가 연결되어야 합니다.'.format(name))
    return navigation


def load_map():
    path = os.environ.get('FACTORY_MAP_PATH')
    if path and Path(path).exists():
        return validate_map(json.loads(Path(path).read_text()))
    return validate_map(json.loads(Path(__file__).with_name('navigation_map.json').read_text()))


def save_map(navigation):
    path = Path(os.environ.get('FACTORY_MAP_PATH', '/tmp/factory-map.json'))
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, delete=False) as stream:
            temporary = stream.name
            json.dump(navigation.data, stream, ensure_ascii=False, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
