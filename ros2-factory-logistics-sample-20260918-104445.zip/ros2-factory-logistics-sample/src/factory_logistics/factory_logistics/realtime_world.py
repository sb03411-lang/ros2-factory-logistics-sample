"""ROS-independent observed-action loop and moving obstacles; global replanning with asynchronous vision review."""
import collections
import copy
import math
import secrets
import random
import time
from factory_logistics.core import _finite_number
from factory_logistics.navigation import NavigationMap
from factory_logistics.perception import RangeSensor
from factory_logistics.camera_perception import CameraPerception


def distance_segment(p, a, b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy))) if dx or dy else 0.
    return math.dist(p,(a[0]+t*dx,a[1]+t*dy))


def ccw(a, b, c):
    return (c[1]-a[1])*(b[0]-a[0]) > (b[1]-a[1])*(c[0]-a[0])


def intersect_segments(a, b, c, d):
    return (ccw(a, c, d) != ccw(b, c, d)) and (ccw(a, b, c) != ccw(a, b, d))


class LiveNavigation:
    def __init__(self, base, obstacles):
        self.base,self.obstacles=base,obstacles
    def __getattr__(self, key):
        return getattr(self.base,key)
    def segment_free(self,a,b):
        return self.base.segment_free(a,b) and all(distance_segment((o['x'],o['y']),a,b)>o['radius']+self.radius+.005 for o in self.obstacles.values())
    def point_free(self,p):
        return self.segment_free(p,p)
    def plan(self,a,b):
        if not self.obstacles:return self.base.plan(a,b)
        # Plan with the same circular obstacle clearance as motion validation.
        # Inflating a bounding square used to reject otherwise free goals and
        # aisle corners. Static wall geometry remains the calibrated blueprint.
        view=copy.copy(self.base)
        view.point_free=self.point_free
        view.segment_free=self.segment_free
        view.nodes={key:p for key,p in self.base.nodes.items() if self.point_free(p)}
        return NavigationMap.plan(view,a,b)


class RealtimeWorld:
    MAX_STEP=.5
    MAX_AGE=30.
    def __init__(self, core, clock=time.monotonic, camera_only=False):
        self.core,self.clock=core,clock
        self.obstacles={}
        self.disabled_people={}
        self.recovery=None
        self.recovery_attempts=0
        self.reobserve=None
        self.reobserve_after=0.
        self.reobserve_visits={}
        self.rng=random.Random()
        self.base=core.navigation
        self.camera_only=camera_only
        self.camera_frames={}
        self.sensor=CameraPerception(self.base) if self.camera_only else RangeSensor(self.base)
        self.last_wait=-100.
        self.assess_until=0.
        self.core.navigation=LiveNavigation(self.base,self.obstacles)
        self.rt={'active':False,'session':'','phase':'IDLE','destination':'','cycle':0,'message':'목표를 선택하고 실시간 판단을 시작하세요.','last_action':None,'observation':None}
        self.events=collections.deque(maxlen=80)
        self.yaw=0.
        self.last_pose=self.pose()
        self.route_history=collections.deque(maxlen=16)
        self.wait_revision=-1
        self.inspect_after=0.
        self.inspections={}
        self.sequence=0
        self.observed_at=0.
        self.started_at=0.
        self.target=None
        self.wait_until=0.
        self.failures=0
        self.yield_episode=None
        self._last_event_meta=None
    def pose(self):
        s=self.core.snapshot();return [s['x'],s['y']]
    def event(self,stage,message,source='SYSTEM',details=None,level='INFO'):
        now_t=time.time()
        if hasattr(self,'_last_event_meta') and self._last_event_meta:
            l_stage,l_msg,l_time=self._last_event_meta
            if l_stage==stage and l_msg==message and (now_t-l_time<0.8):return
        self._last_event_meta=(stage,message,now_t)
        self.sequence+=1
        self.events.appendleft(dict(id='rt-'+str(self.sequence),stamp=now_t,request_id=self.rt['session'],map_id=self.base.data['id'],source=source,stage=stage,message=message,details=details or {},level=level))
        self.rt['message']=message
    def snapshot(self):
        current=self.pose();delta=[current[i]-self.last_pose[i] for i in (0,1)]
        if math.hypot(*delta)>1e-6:self.yaw=math.atan2(delta[1],delta[0])
        self.last_pose=current
        state=copy.deepcopy(self.rt)
        state['remaining_route_m']=self.base.length([current]+state['route']) if state.get('route') else (0. if state['phase']=='ARRIVED' else None)
        state['people']={'enabled':any(o.get('kind')=='person' for o in self.obstacles.values()),'count':sum(o.get('kind')=='person' for o in self.obstacles.values()),'saved_count':len(self.disabled_people)}
        state['observation_age']=round(self.clock()-self.observed_at,1) if self.rt['observation'] else None
        return dict(sensor=self.sensor.snapshot(self.clock()),yaw=self.yaw,realtime=state,obstacles=copy.deepcopy(list(self.obstacles.values())),realtime_logs=copy.deepcopy(list(self.events)))
    def replace_map(self, navigation):
        if self.rt['active'] or self.obstacles or self.disabled_people:raise ValueError('실시간 판단을 정지하고 움직이는 장애물을 삭제한 뒤 도면을 바꿔 주세요.')
        self.base=navigation
        self.sensor=CameraPerception(navigation) if self.camera_only else RangeSensor(navigation)
        self.core.replace_navigation(LiveNavigation(navigation,self.obstacles))
    def stop(self,message='사용자가 실시간 판단을 정지했습니다.',phase='STOPPED'):
        self.rt.update(active=False,phase=phase,actual_speed_mps=0.)
        self.target=None
        self.recovery=None
        self.reobserve=None
        self.yield_episode=None
        self.rt['camera_wait']=None
        self.core.manual_step(0,0,.1)
        self.event('실시간 '+phase,message,'ROS',level='INFO' if phase in ('ARRIVED','STOPPED') else 'ERROR' if phase=='ERROR' else 'WARN')
    def start(self,destination,mode="reactive",speed=.5):
        if mode not in ("reactive","global"):raise ValueError("잘못된 주행 모드")
        if self.camera_only:mode="global"  # All autonomous camera-only starts use the guarded planner.
        speed=_finite_number(speed,"speed")
        if not .1<=speed<=.5:raise ValueError("속도는 0.1~0.5m/s 범위입니다.")
        if self.rt['active'] or self.core.busy:raise ValueError('진행 중인 로봇 작업을 먼저 정지해 주세요.')
        if destination not in self.core._stations:raise ValueError('등록된 목적지를 선택해 주세요.')
        self.core.begin_external_motion()
        self.rt=dict(active=True,session='RT-'+secrets.token_hex(5).upper(),phase='OBSERVING',destination=destination,cycle=0,message='',last_action=None,observation=None)
        self.started_at=self.clock();self.target=None;self.failures=0
        self.recovery=None;self.recovery_attempts=0
        self.reobserve=None;self.reobserve_after=0.;self.reobserve_visits={}
        self.yield_episode=None
        self.route_history.clear();self.wait_revision=-1;self.inspect_after=0.;self.inspections.clear()
        self.rt.update(mode=mode,speed_mps=speed,route=[],previous_route=[],replans=0,review_pending=False,review_due=0.,last_rejection=None)
        if mode=='global':
            self.sensor=CameraPerception(self.base) if self.camera_only else RangeSensor(self.base);self.last_wait=-100.
            self.camera_frames.clear()
            self.rt.update(behavior='GLOBAL_ROUTE',local_avoids=0,actual_speed_mps=0.)
            self.replan('최초 전체 도면 경로 탐색');return
        self.event('실시간 시작','전체 경로 대신 최신 관측에 대한 짧은 행동을 반복합니다.',details={'destination':destination,'max_step_m':self.MAX_STEP})
    def replan(self,reason):
        self.reobserve=None
        self.core.manual_step(0,0,.1)
        self.rt['previous_route']=([self.pose()]+copy.deepcopy(self.rt['route'])) if self.rt.get('route') else []
        before=time.perf_counter()
        self.rt['replans']+=1
        self.rt['review_due']=0.
        try:
            path=LiveNavigation(self.base,self.sensor.tracks).plan(self.pose(),self.core._stations[self.rt['destination']])
            signature=tuple((round(p[0],1),round(p[1],1)) for p in path[1:])
            if self.camera_only and list(self.route_history).count(signature)>=2:
                self.rt.update(route=[],phase='WAITING',behavior='REOBSERVE',last_rejection='같은 우회 경로 반복 · 관측 변화 대기')
                self.wait_until=self.clock()+3.;self.wait_revision=self.sensor.revision
                self.event('반복 우회 차단 · 재관측','같은 경로가 반복되어 이동을 보류합니다. 장애물 관측이 바뀐 뒤 다시 탐색합니다.','PLANNER',level='WARN')
                return
            self.route_history.append(signature)
            self.rt.update(route=path[1:],phase='MOVING',behavior='GLOBAL_ROUTE',last_rejection=None,blocked_at=None)
            self.event('전체 경로 재탐색' if self.rt['replans']>1 else '최초 경로 계산',reason,'PLANNER',
                dict(path=path,length_m=round(self.base.length(path),3),planning_ms=round((time.perf_counter()-before)*1000,2)))
        except ValueError as exc:
            self.rt.update(route=[],phase='WAITING',behavior='NO_ROUTE',last_rejection=str(exc))
            self.wait_until=self.clock()+(3. if self.camera_only else 1.)
            self.wait_revision=self.sensor.revision
            if self.rt['previous_route'] or self.rt['replans']==1:
                self.event('통로 없음 · 정지 대기',str(exc),'PLANNER',level='WARN')
        self.rt['planning_ms']=round((time.perf_counter()-before)*1000,2)
        if self.camera_only and self.rt['behavior']=='NO_ROUTE':self.plan_reobservation()

    def plan_reobservation(self):
        """Reach a camera viewpoint without crossing ANY remembered obstacle."""
        now=self.clock()
        if now<self.reobserve_after:return False
        self.reobserve_after=now+8.
        stale=[o for o in self.sensor.tracks.values() if now-o['last_seen']>20 and now-self.reobserve_visits.get(o['id'],-1e9)>45]
        if not stale:return False
        nav=LiveNavigation(self.base,self.sensor.tracks)
        candidates=[]
        for o in stale:
            for radius in (1.3,2.,2.8):
                for i in range(16):
                    a=2*math.pi*i/16
                    point=[round(o['x']+radius*math.cos(a),2),round(o['y']+radius*math.sin(a),2)]
                    if math.dist(self.pose(),point)<.4 or not nav.point_free(point):continue
                    yaw=math.atan2(o['y']-point[1],o['x']-point[0])
                    if not self.sensor._empty_visible(o,point,yaw,[]):continue
                    candidates.append((math.dist(self.pose(),point)+radius*.15,o,point))
        # Bounded search; the same conservative map validates the entire path.
        for _,o,point in sorted(candidates,key=lambda c:c[0])[:24]:
            try:path=nav.plan(self.pose(),point)
            except ValueError:continue
            self.reobserve=dict(id=o['id'],point=[o['x'],o['y']],arrived=None,frame=None)
            self.rt.update(route=path[1:],phase='MOVING',behavior='REOBSERVE_TRAVEL',blocked_at=None,
                message='오래된 장애물을 확인할 수 있는 지점으로 이동합니다.')
            self.event('재관측 지점 이동','오래된 장애물도 유지한 안전 경로로 이동해 통로가 실제로 비었는지 확인합니다.','PLANNER',
                {'track_id':o['id'],'age_seconds':round(now-o['last_seen'],1),'viewpoint':point,'path':path})
            return True
        self.event('재관측 지점 없음','기억한 장애물을 통과하지 않고 접근할 수 있는 관측 지점을 찾지 못했습니다. 새 관측을 기다립니다.','PLANNER',level='WARN')
        return False

    def inspect_memory(self,dt):
        r=self.reobserve;now=self.clock()
        self.core.manual_step(0,0,dt)
        if r['arrived'] is None:
            r.update(arrived=now,frame=self.sensor.last_frame)
            self.rt.update(phase='INSPECTING',behavior='REOBSERVE_SCAN')
            self.event('재관측 지점 도착','장애물의 마지막 위치를 바라보고 연속 새 영상으로 존재 여부를 확인합니다.','CAMERA',{'track_id':r['id']})
        self.yaw=math.atan2(r['point'][1]-self.pose()[1],r['point'][0]-self.pose()[0])
        if now-r['arrived']>8:
            self.reobserve_visits[r['id']]=now
            self.reobserve=None
            self.replan('재관측 시간 초과 · 장애물 기억 유지');return
        if (now-r['arrived']>=2. and self.sensor.last_frame>r['frame'] and self.sensor.ready(self.pose(),self.yaw,now)):
            self.reobserve_visits[r['id']]=now
            remaining=self.sensor.tracks.get(r['id'])
            outcome='빈 공간 확인 · 기억 해제' if remaining is None else ('장애물 다시 확인' if remaining['last_seen']>=r['arrived'] else '가림 또는 관측 부족 · 기억 유지')
            self.event('재관측 결과',outcome,'CAMERA',{'track_id':r['id']})
            self.route_history.clear()
            self.reobserve=None
            self.replan('재관측 결과로 목적지 경로 재검토')

    def camera_capture(self):
        self.snapshot()
        key=secrets.token_hex(12)
        context=dict(id=key,pose=self.pose(),yaw=self.yaw,captured=self.clock(),session=self.rt['session'],map_id=self.base.data['id'])
        self.camera_frames[key]=context
        while len(self.camera_frames)>4:del self.camera_frames[next(iter(self.camera_frames))]
        return dict(context,navigation=copy.deepcopy(self.base.data),obstacles=copy.deepcopy(list(self.obstacles.values())))

    def camera_result(self,payload):
        if not self.camera_only:raise ValueError('카메라 주행 모드가 아닙니다.')
        context=self.camera_frames.pop(payload.get('id'),None)
        if not context or context['session']!=self.rt['session'] or context['map_id']!=self.base.data['id'] or self.clock()-context['captured']>1.2:raise ValueError('만료된 카메라 프레임')
        if context['captured']<=self.sensor.last_frame:raise ValueError('이전 카메라 프레임')
        new,cleared=self.sensor.accept(payload.get('detections'),context['pose'],context['yaw'],context['captured'],self.clock(),str(payload.get('model',''))[:80],payload.get('inference_ms',0))
        if self.rt['active'] and (new or cleared):
            self.event('카메라 · YOLO 관측','전방 영상의 탐지 박스로 장애물 위치를 추정했습니다.','CAMERA',{'detected_ids':new,'cleared_ids':cleared,'frame_id':context['id'],'detections':payload.get('detections')})

    def sense(self):
        if self.camera_only:return
        new,cleared=self.sensor.scan(self.pose(),self.obstacles,self.clock())
        if new and self.rt['active']:self.event('센서 · 장애물 발견','거리 센서의 범위와 시야에 들어온 장애물을 주변 지도에 반영합니다.','SENSOR',{'detected_ids':new,'range_m':self.sensor.RANGE})
        if cleared and self.rt['active']:self.event('센서 · 빈 공간 확인','마지막 관측 위치가 비어 있어 장애물 기억을 해제합니다.','SENSOR',{'cleared_ids':cleared})

    def obstacle_crosses_route(self,o,route_points):
        ox,oy=o['x'],o['y']
        r=o['radius']+self.base.radius+.005
        for a,b in zip(route_points,route_points[1:]):
            if distance_segment((ox,oy),a,b)<=r:
                if o.get('moving') or o.get('speed',0.)>=.06 or o.get('approaching'):return True
        vx,vy=o.get('vx',0.),o.get('vy',0.)
        if math.hypot(vx,vy)>=.06:
            pred=[ox+vx*3.,oy+vy*3.]
            for a,b in zip(route_points,route_points[1:]):
                if intersect_segments((ox,oy),pred,a,b):return True
                if distance_segment(pred,a,b)<=r:return True
        return False

    def blocked_route(self,nav):
        points=[self.pose()]+self.rt['route']
        return next((b for a,b in zip(points,points[1:]) if not nav.segment_free(a,b)),None)

    def local_detour(self,nav):
        """Rejoin within 2.25m along the old route; reject large/global detours."""
        original=[self.pose()]+self.rt['route']
        for reach in (1.,1.5,2.,2.25):
            traveled=0.
            for i,(a,b) in enumerate(zip(original,original[1:])):
                length=math.dist(a,b)
                if traveled+length<reach and i<len(original)-2:
                    traveled+=length;continue
                f=min(1.,max(0.,(reach-traveled)/max(length,1e-9)))
                join=[a[j]+(b[j]-a[j])*f for j in (0,1)]
                prefix=original[:i+1]+[join]
                if all(nav.segment_free(x,y) for x,y in zip(prefix,prefix[1:])):break
                try:path=nav.plan(self.pose(),join)
                except ValueError:break
                if self.base.length(path)>reach+1.25 or any(math.dist(self.pose(),p)>2.6 for p in path):break
                suffix=original[i+1:]
                if suffix and math.dist(join,suffix[0])<.001:suffix=suffix[1:]
                self.rt.update(previous_route=original,route=path[1:]+suffix,phase='MOVING',behavior='LOCAL_AVOID',blocked_at=None)
                self.rt['local_avoids']+=1
                self.local_join=join
                self.event('가까운 우회 선택','주변 통로로 우회한 뒤 기존 경로에 복귀합니다.','PLANNER',{'rejoin':join,'local_path':path})
                return True
        return False

    def choose_response(self,nav,allow_wait=True):
        if not self.camera_only:
            points=[self.pose()]+self.rt['route']
            blockers=[o for o in self.sensor.tracks.values() if any(distance_segment((o['x'],o['y']),a,b)<=o['radius']+self.base.radius+.005 for a,b in zip(points,points[1:]))]
            if allow_wait and self.clock()-self.last_wait>5 and any(o['moving'] for o in blockers):
                self.last_wait=self.clock();self.wait_until=self.clock()+1.5
                self.rt.update(phase='YIELDING',behavior='YIELD')
                self.event('일시 장애물 · 대기','관측 위치가 변하는 장애물입니다. 최대 1.5초 기다린 뒤 다시 판단합니다.','PLANNER');return
            if self.local_detour(nav):return
            self.rt['behavior']='REPLAN'
            self.replan('가까운 우회 불가 · 발견한 장애물과 전체 지도로 다른 통로 탐색')
            return
        if self.local_detour(nav):return
        self.rt['behavior']='REPLAN'
        self.replan('가까운 우회 불가 · 발견한 장애물과 전체 지도로 다른 통로 탐색')

    def recover_camera(self,dt):
        r=self.recovery;now=self.clock()
        self.core.manual_step(0,0,dt)
        self.yaw=r['yaw']+r['angles'][r['index']]
        if now-r['started']>12:
            self.stop('충돌 후 새 카메라 관측을 확보하지 못했습니다. 위치와 영상을 확인한 뒤 다시 시작해 주세요.','BLOCKED');return
        if self.sensor.last_frame<=r['frame'] or not self.sensor.ready(self.pose(),self.yaw,now):return
        r['index']+=1;r['frame']=self.sensor.last_frame
        if r['index']<len(r['angles']):
            self.yaw=r['yaw']+r['angles'][r['index']];return
        self.recovery=None
        if self.blocked_route(LiveNavigation(self.base,self.sensor.tracks)) is not None:
            self.replan('충돌 후 전방·좌우 새 영상 확인 · 관측 장애물로 경로 재탐색')
        else:
            self.stop('충돌 검사와 카메라 판단이 일치하지 않습니다. 같은 방향 재시도를 중단했습니다. 장애물 배치 또는 수동 위치 조정 후 다시 시작해 주세요.','BLOCKED')

    def global_tick(self,dt):
        now=self.clock();self.rt['actual_speed_mps']=0.
        if self.camera_only and self.reobserve is not None and not self.rt.get('route'):
            self.inspect_memory(dt);return
        if self.camera_only and self.recovery is not None:
            self.recover_camera(dt);return
        if self.camera_only:
            route=self.rt.get('route',[])
            if route and math.dist(self.pose(),route[0])>.001:
                desired=math.atan2(route[0][1]-self.pose()[1],route[0][0]-self.pose()[0])
                self.yaw=desired
            elif self.rt['phase']=='WAITING' and now>=self.inspect_after:
                remembered=[o for o in self.sensor.tracks.values() if .3<math.dist(self.pose(),[o['x'],o['y']])<self.sensor.RANGE]
                if remembered:
                    o=min(remembered,key=lambda o:(self.inspections.get(o['id'],-1),o['last_seen']))
                    self.inspections[o['id']]=now
                    self.yaw=math.atan2(o['y']-self.pose()[1],o['x']-self.pose()[0])
                    if not self.sensor.ready(self.pose(),self.yaw,now):
                        self.event('카메라 · 막힌 구간 재관측','기억한 장애물 방향을 바라보고 실제 영상으로 통로를 다시 확인합니다.','CAMERA',{'track_id':o['id']})
                self.inspect_after=now+2.
            if not self.sensor.ready(self.pose(),self.yaw,now) or self.sensor.uncertain:
                self.core.manual_step(0,0,dt)
                message='전방 YOLO 관측 대기 · 영상이 오래되었거나 새 이동 방향을 확인 중입니다.' if not self.sensor.uncertain else '영상 하단 잘림 · 거리를 확정할 수 없어 정지합니다.'
                if self.rt.get('camera_wait')!=message:self.event('카메라 · 이동 보류',message,'CAMERA')
                self.rt['camera_wait']=message
                return
            if self.rt.get('camera_wait'):
                self.rt['message']='새 전방 관측 확인 · 경로 이동 재개' if self.rt['phase']=='MOVING' else '전방 관측 확인 · 통로 재판단 중'
            self.rt['camera_wait']=None
        nav=LiveNavigation(self.base,self.sensor.tracks)
        if self.rt['review_pending'] and now-self.observed_at>35:
            self.rt['review_pending']=False;self.rt['review_due']=now+15
            self.event('영상 검토 지연','카메라 기반 주행은 LLM 응답을 기다리지 않습니다.','SYSTEM',level='WARN')
        if self.rt['phase']=='WAITING':
            if self.camera_only and self.rt.get('behavior')=='NO_ROUTE' and self.plan_reobservation():return
            if now>=self.wait_until and (not self.camera_only or self.sensor.revision!=self.wait_revision):
                if self.rt.get('behavior')=='REOBSERVE':self.route_history.clear()
                self.replan('카메라 관측 갱신 · 통로 재확인')
            return
        blocked=self.blocked_route(nav)
        if self.camera_only:
            points=[self.pose()]+self.rt['route']
            blockers=[o for o in self.sensor.tracks.values() if any(distance_segment((o['x'],o['y']),a,b)<=o['radius']+self.base.radius+.005 for a,b in zip(points,points[1:]))]
            if blocked is not None and self.yield_episode is not None:
                self.yield_episode['clear_confirmations']=0
                self.yield_episode['last_confirmed_frame']=None
            if blocked is not None and blockers and all(o.get('hits',0)<2 for o in blockers):
                self.core.manual_step(0,0,dt)
                self.rt['camera_wait']='장애물 재확인 · 연속 카메라 관측 대기'
                return
            if blocked is not None:
                self.core.manual_step(0,0,dt)
                has_crossing=any(self.obstacle_crosses_route(o,points) for o in blockers)
                has_moving=any(o.get('moving') for o in blockers)
                has_approaching=any(o.get('approaching') for o in blockers)
                is_dynamic=has_crossing or has_moving or has_approaching
                ep=self.yield_episode
                is_same_ep=(ep is not None and math.dist(self.pose(),ep['robot_pose'])<.20)
                if is_same_ep:
                    ep['last_active']=now
                    ep['clear_confirmations']=0
                    ep['last_confirmed_frame']=None
                    if is_dynamic:ep['is_dynamic']=True
                else:
                    ep=dict(started_at=now,base_until=now+2.5,max_until=now+5.0,robot_pose=list(self.pose()),
                            clear_confirmations=0,last_confirmed_frame=None,last_active=now,is_dynamic=is_dynamic,
                            logged_yield=False,logged_detected=False,exhausted=False)
                    self.yield_episode=ep
                if ep.get('exhausted') or not ep['is_dynamic']:
                    if self.rt['phase']!='ASSESSING':
                        self.rt.update(phase='ASSESSING',behavior='DETECTED',blocked_at=blocked)
                        self.assess_until=now+.2
                        if not ep.get('logged_detected'):
                            ep['logged_detected']=True
                            msg='양보 시간 소진 후 통로 차단 지속 · 우회 경로를 탐색합니다.' if ep.get('exhausted') else '카메라에 관측된 고정 장애물이 경로를 막습니다. 우회 또는 전체 재탐색을 선택합니다.'
                            self.event('발견한 장애물 · 정지',msg,'VALIDATOR',{'blocked_at':blocked},'WARN')
                        return
                    elif now>=self.assess_until:
                        self.event('통로 차단 · 우회 탐색','대기 없이 우회 경로를 탐색합니다.','PLANNER')
                        self.choose_response(nav)
                        return
                    return
                else:
                    if now<ep['max_until']:
                        self.rt.update(phase='YIELDING',behavior='YIELD',blocked_at=blocked)
                        elapsed=now-ep['started_at']
                        self.rt['message']=f'지나가는 장애물 양보 중 ({elapsed:.1f}s / 최대 5.0s)'
                        if not ep['logged_yield']:
                            ep['logged_yield']=True
                            self.event('지나가는 장애물 양보 · 정지','진로를 가로지르는 장애물을 관측하여 약 2.5초간 양보합니다. (최대 5.0초)','PLANNER',{'wait_limit_s':5.0,'base_wait_s':2.5})
                        return
                    else:
                        ep['exhausted']=True
                        self.event('양보 한도 초과 · 우회 전환','최대 대기 시간(5.0초) 동안 통로가 열리지 않아 우회 경로를 탐색합니다.','PLANNER',{'total_waited_s':round(now-ep['started_at'],2)})
                        self.choose_response(nav)
                        return
            else:
                ep=self.yield_episode
                if ep is not None and self.rt['phase'] in ('YIELDING','ASSESSING'):
                    frame_time=self.sensor.last_frame
                    last_f=ep.get('last_confirmed_frame')
                    is_new_frame=(last_f is None or frame_time>last_f)
                    is_fresh=self.sensor.ready(self.pose(),self.yaw,now)
                    if is_new_frame and is_fresh:
                        ep['last_confirmed_frame']=frame_time
                        ep['clear_confirmations']+=1
                        ep['last_active']=now
                    can_proceed=(ep['clear_confirmations']>=2 and (now>=ep['base_until'] or not ep['is_dynamic']))
                    if can_proceed:
                        elapsed=now-ep['started_at']
                        confirmations=ep['clear_confirmations']
                        self.yield_episode=None
                        self.rt.update(phase='MOVING',behavior='GLOBAL_ROUTE',blocked_at=None)
                        self.event('통로 확보 · 이동 재개',f'서로 다른 최신 영상 {confirmations}회에서 통로가 열렸음을 연속 확인했습니다. (양보 대기: {elapsed:.1f}초)','PLANNER')
                    else:
                        self.core.manual_step(0,0,dt)
                        elapsed=now-ep['started_at']
                        self.rt.update(phase='YIELDING',behavior='YIELD')
                        self.rt['message']=f'통로 열림 연속 확인 중 ({ep["clear_confirmations"]}/2 프레임, {elapsed:.1f}s / 2.5s)'
                        return
                elif ep is None and self.rt['phase']=='ASSESSING':
                    self.rt.update(phase='MOVING',behavior='GLOBAL_ROUTE',blocked_at=None)
        else:
            if self.rt['phase']=='ASSESSING':
                if blocked is None:
                    self.rt.update(phase='MOVING',behavior='GLOBAL_ROUTE')
                elif now>=self.assess_until:self.choose_response(nav)
                return
            if self.rt['phase']=='YIELDING':
                if blocked is None:
                    self.rt.update(phase='MOVING',behavior='GLOBAL_ROUTE')
                    self.event('통로 확보 · 이동 재개','카메라 관측에서 기존 경로가 비었음을 확인했습니다.','PLANNER')
                elif now>=self.wait_until:self.choose_response(nav,allow_wait=False)
                return
            if blocked is not None:
                self.core.manual_step(0,0,dt)
                self.rt.update(phase='ASSESSING',behavior='DETECTED',blocked_at=blocked,review_due=0.)
                self.assess_until=now+.2
                self.event('발견한 장애물 · 정지','카메라에 관측된 장애물이 경로를 막습니다. 움직임 확인 후 대기·가까운 우회·전체 재탐색을 선택합니다.','VALIDATOR',{'blocked_at':blocked},'WARN');return
        route=self.rt['route']
        if not route:return
        p=self.pose();target=route[0];d=math.dist(p,target)
        clearance=min((math.dist(p,(o['x'],o['y']))-o['radius']-self.base.radius for o in self.sensor.tracks.values()),default=10.)
        speed=min(self.rt['speed_mps'],.3 if self.camera_only else .5,.2 if clearance<.55 else self.rt['speed_mps'],d/max(dt,.001))
        self.core.manual_step(*[(target[i]-p[i])*speed/d if d else 0. for i in (0,1)],dt)
        self.rt['actual_speed_mps']=round(math.dist(p,self.pose())/max(dt,.001),3)
        self.rt['last_action']=dict(action='move',x=target[0],y=target[1],explanation='카메라 관측 지도와 경로를 확인하며 이동')
        if self.core.navigation_state()['collision_blocked']:
            self.rt.update(phase='YIELDING',behavior='SAFETY_STOP');self.wait_until=now+.5
            self.event('안전장치 · 충돌 차단','물리 충돌 검사가 이동을 차단했습니다. 숨은 좌표로 경로를 바꾸지 않고 카메라를 다시 확인합니다.','VALIDATOR',level='WARN')
            if self.camera_only:
                self.recovery_attempts+=1
                if self.recovery_attempts>2:
                    self.stop('카메라 재관측 후에도 충돌 차단이 반복되어 자동 재시도를 중단했습니다.','BLOCKED');return
                self.rt.update(phase='RECOVERING',behavior='SAFETY_STOP')
                self.recovery=dict(yaw=self.yaw,angles=[0.,math.pi/3,-math.pi/3,0.],index=0,frame=self.sensor.last_frame,started=now)
                self.event('충돌 후 카메라 재관측','제자리에서 전방·좌우의 새 영상을 확인합니다. 확인 전에는 이동하지 않습니다.','CAMERA')
            return
        if math.dist(p,self.pose())>.001:self.recovery_attempts=0
        if math.dist(self.pose(),target)<.001:
            route.pop(0)
            if self.rt['behavior']=='LOCAL_AVOID' and math.dist(self.pose(),self.local_join)<.01:
                self.rt['behavior']='GLOBAL_ROUTE'
                self.event('기존 경로 복귀','가까운 우회를 마치고 원래 경로로 돌아왔습니다.','PLANNER')

    def observe(self):
        global_mode=self.rt.get('mode')=='global'
        if not self.rt['active'] or (global_mode and (self.rt['review_pending'] or self.clock()<self.rt['review_due'])) or (not global_mode and self.rt['phase']!='OBSERVING'):raise ValueError('새 관측을 받을 수 있는 상태가 아닙니다.')
        self.observed_at=self.clock()
        self.rt['cycle']+=1
        observation=dict(id=secrets.token_hex(8),session=self.rt['session'],stamp=time.time(),pose=self.pose(),target=list(self.core._stations[self.rt['destination']]),destination=self.rt['destination'],obstacles=copy.deepcopy(list(self.obstacles.values())),navigation=copy.deepcopy(self.base.data),max_step_m=self.MAX_STEP,cycle=self.rt['cycle'])
        self.snapshot()
        route=self.rt.get('route',[])
        if not self.camera_only and route and math.dist(self.pose(),route[0])>.001:self.yaw=math.atan2(route[0][1]-self.pose()[1],route[0][0]-self.pose()[0])
        observation.update(camera=dict(type='synthetic_first_person',horizontal_fov_deg=80,height_m=.85),yaw=self.yaw,mode=self.rt.get('mode'),route=copy.deepcopy(self.rt.get('route',[])),last_rejection=self.rt.get('last_rejection'))
        self.rt.update(observation=observation)
        if global_mode:self.rt.update(review_pending=True,review_due=self.clock()+20)
        else:self.rt['phase']='THINKING'
        self.event('현재 화면 관측','주행과 별개로 전방 카메라를 촬영해 검토합니다.' if global_mode else '로봇을 정지하고 최신 화면으로 다음 행동을 판단합니다.',details={'observation_id':observation['id'],'pose':observation['pose'],'cycle':observation['cycle']})
        return observation
    def reject(self,message):
        self.rt['last_rejection']=message
        self.failures+=1;self.target=None
        self.rt['phase']='OBSERVING'
        self.event('행동 차단 · 재관측',message,'VALIDATOR',level='WARN')
        if self.failures>=6:self.stop('6회 연속 행동이 실행되지 않아 정지했습니다. 통로와 모델 응답을 확인해 주세요.','ERROR')
    def action(self,payload):
        observation=self.rt['observation']
        if self.rt.get('mode')=='global':
            if not self.rt['active'] or not self.rt['review_pending'] or not observation or payload.get('session')!=self.rt['session'] or payload.get('observation_id')!=observation['id']:
                raise ValueError('만료된 도면 검토 응답입니다.')
            self.rt.update(review_pending=False,review_due=self.clock()+15)
            action=payload.get('action') or {}
            message=payload.get('error') or action.get('explanation') or '검토 근거가 없습니다.'
            self.event('비동기 도면 검토',str(message)[:2000],'LLM',{'observation_id':observation['id'],'age_seconds':round(self.clock()-self.observed_at,2),'advisory_only':True},'WARN' if payload.get('error') else 'INFO')
            return
        if not self.rt['active'] or self.rt['phase']!='THINKING' or not observation or payload.get('session')!=self.rt['session'] or payload.get('observation_id')!=observation['id']:
            raise ValueError('만료되었거나 이미 처리한 실시간 관측입니다.')
        if payload.get('error'):
            self.reject(str(payload['error'])[:500]);return
        action=payload.get('action')
        if not isinstance(action,dict):self.reject('행동 응답 형식이 올바르지 않습니다.');return
        reason=action.get('explanation')
        if not isinstance(reason,str):self.reject('행동 근거 요약이 없습니다.');return
        visible={k:action.get(k) for k in ('action','x','y') if type(action.get(k)) in (str,int,float)}
        visible={k:v for k,v in visible.items() if not isinstance(v,(int,float)) or math.isfinite(v)}
        self.event('다음 행동 판단',reason[:2000],'LLM',dict(visible,observation_id=observation['id'],age_seconds=round(self.clock()-self.observed_at,2)))
        if self.clock()-self.observed_at>self.MAX_AGE:self.reject('관측이 30초 이상 오래되어 다시 확인합니다.');return
        if math.dist(self.pose(),observation['pose'])>.02:self.reject('관측 후 로봇 위치가 변경되었습니다.');return
        kind=action.get('action')
        if kind=='wait':
            self.rt.update(phase='WAITING',last_action=dict(action='wait',explanation=reason[:2000]))
            self.wait_until=self.clock()+1
            self.event('1초 대기','Codex 판단에 따라 정지한 뒤 새 화면을 관측합니다.','ROS');return
        try:
            target=[_finite_number(action.get('x'),'x'),_finite_number(action.get('y'),'y')]
            if kind!='move' or not .03<=math.dist(self.pose(),target)<=self.MAX_STEP+.000001:raise ValueError('이동은 현재 위치에서 0.03~0.5m의 한 구간이어야 합니다.')
            if not self.core.navigation.segment_free(self.pose(),target):raise ValueError('최신 장애물 또는 벽에 막힌 이동입니다.')
        except ValueError as exc:self.reject(str(exc));return
        self.failures=0;self.target=target
        self.rt.update(phase='MOVING',last_action=dict(action='move',x=target[0],y=target[1],explanation=reason[:2000]))
        self.event('짧은 이동 승인','최신 위치에서 충돌 검사를 통과한 구간만 이동합니다.','VALIDATOR',{'from':self.pose(),'to':target})
    def free_obstacle(self,o,start,end):
        r=o['radius']
        # Reuse exact swept rectangle intersection with the obstacle's own radius.
        nav=copy.copy(self.base);nav.radius=r
        nav.inflated=[(a-r,b-r,c+r,d+r) for a,b,c,d in self.base.walls]
        if not nav.segment_free(start,end):return False
        if distance_segment(self.pose(),start,end)<=r+self.base.radius+.01:return False
        return all(other['id']==o['id'] or distance_segment((other['x'],other['y']),start,end)>r+other['radius']+.01 for other in self.obstacles.values())
    def obstacle(self,payload):
        operation=payload.get('operation')
        if operation=='people_toggle':
            enabled=payload.get('enabled')
            if type(enabled) is not bool:raise ValueError('사람 켜기/끄기 값이 필요합니다.')
            if not enabled:
                for key,o in list(self.obstacles.items()):
                    if o.get('kind')=='person':self.disabled_people[key]=self.obstacles.pop(key)
                self.event('사람 끄기','사람을 장면·이동·충돌 대상에서 제외했습니다. 카메라 기억은 새 영상으로 갱신됩니다.')
                return
            if not self.disabled_people:
                if any(o.get('kind')=='person' for o in self.obstacles.values()):return
                self.obstacle(dict(operation='people',count=min(4,8-len(self.obstacles))))
                return
            if len(self.obstacles)+len(self.disabled_people)>8:raise ValueError('저장된 사람을 켤 슬롯이 부족합니다. 다른 장애물을 삭제해 주세요.')
            before=copy.deepcopy(self.obstacles)
            try:
                for key,saved in self.disabled_people.items():
                    o=copy.deepcopy(saved);point=[o['x'],o['y']]
                    if not self.free_obstacle(o,point,point):
                        candidates=sorted(self.base.nodes.values(),key=lambda v:math.dist(v,point))
                        point=next((v for v in candidates if self.free_obstacle(o,v,v)),None)
                        if point is None:raise ValueError('사람을 안전하게 다시 배치할 공간이 부족합니다.')
                    o.update(x=point[0],y=point[1],walk_remaining=0.)
                    self.obstacles[key]=o
            except Exception:
                self.obstacles.clear();self.obstacles.update(before);raise
            self.disabled_people.clear()
            self.event('사람 켜기','저장된 사람을 다시 배치했습니다. 이전 위치가 막혔으면 가까운 빈 공간을 사용합니다.')
            return
        if operation=='people':
            count=payload.get('count',4)
            if type(count) is not int or not 1<=count<=8 or len(self.obstacles)+count>8:raise ValueError('동적 장애물은 총 8개입니다. 사람을 배치할 빈 슬롯을 확보해 주세요.')
            before=copy.deepcopy(self.obstacles)
            try:
                for _ in range(count):
                    candidates=list(self.base.nodes.values());self.rng.shuffle(candidates)
                    o=dict(id='P-'+secrets.token_hex(3),x=0.,y=0.,radius=.22,kind='person',mode='wander',speed=.5,direction=1,blocked=False)
                    point=next((v for v in candidates if self.free_obstacle(o,v,v)),None)
                    if point is None:raise ValueError('사람을 안전하게 배치할 공간이 부족합니다.')
                    o.update(x=point[0],y=point[1],walk_remaining=0.,walk_phase=0.)
                    self.obstacles[o['id']]=o
            except Exception:
                self.obstacles.clear();self.obstacles.update(before);raise
            return
        if operation=='delete':
            if payload.get('id') not in self.obstacles:raise ValueError('장애물을 선택해 주세요.')
            del self.obstacles[payload['id']];return
        if operation=='clear':self.obstacles.clear();self.disabled_people.clear();return
        if operation not in ('add','update'):raise ValueError('잘못된 장애물 명령입니다.')
        if operation=='add':
            if len(self.obstacles)>=8:raise ValueError('동적 장애물은 최대 8개입니다.')
            o=dict(id='O-'+secrets.token_hex(3),x=0.,y=0.,radius=.1,mode='manual',speed=.2,direction=1,blocked=False)
        else:
            if payload.get('id') not in self.obstacles:raise ValueError('장애물을 선택해 주세요.')
            o=copy.deepcopy(self.obstacles[payload['id']])
        old=(o['x'],o['y'])
        for key in ('x','y','radius','speed'):
            if key in payload:o[key]=_finite_number(payload[key],key)
        o['mode']=payload.get('mode',o['mode'])
        o['kind']=payload.get('kind','person' if o['mode']=='wander' else o.get('kind','obstacle'))
        if o['kind'] not in ('person','obstacle'):raise ValueError('잘못된 장애물 종류입니다.')
        if operation=='add' and o['kind']=='person' and 'radius' not in payload:o['radius']=.22
        if not .08<=o['radius']<=.25 or not .05<=o['speed']<=.6 or o['mode'] not in ('manual','patrol','wander'):raise ValueError('반경 0.08~0.25m, 속도 0.05~0.6m/s, 수동/왕복/불규칙 모드를 사용하세요.')
        end=(o['x'],o['y'])
        if not self.free_obstacle(o,old if operation=='update' else end,end):raise ValueError('장애물이 벽·로봇·다른 장애물을 통과하거나 겹칠 수 없습니다.')
        if o['mode']=='patrol':
            a=payload.get('a',o.get('a',list(end)));b=payload.get('b',o.get('b'))
            if not isinstance(a,list) or not isinstance(b,list) or len(a)!=2 or len(b)!=2:raise ValueError('왕복 시작·끝 좌표가 필요합니다.')
            a=[_finite_number(v,'a') for v in a];b=[_finite_number(v,'b') for v in b]
            if math.dist(a,b)<.1 or not self.free_obstacle(o,end,a) or not self.free_obstacle(o,a,b):raise ValueError('왕복 구간에 벽·로봇·장애물이 있거나 너무 짧습니다.')
            o.update(a=a,b=b)
        self.obstacles[o['id']]=o
    def wander(self,o,dt):
        o['walk_remaining']=o.get('walk_remaining',0)-dt
        if o['walk_remaining']<=0:
            o['walk_heading']=self.rng.uniform(-math.pi,math.pi)
            o['walk_speed']=0. if self.rng.random()<.22 else self.rng.uniform(min(.12,o['speed']),o['speed'])
            o['walk_remaining']=self.rng.uniform(.5,1.6) if not o['walk_speed'] else self.rng.uniform(1.2,4.)
        speed=o.get('walk_speed',0.)
        if not speed:o['blocked']=False;return
        angle=o['walk_heading'];a=(o['x'],o['y']);b=[a[0]+math.cos(angle)*speed*dt,a[1]+math.sin(angle)*speed*dt]
        o['blocked']=not self.free_obstacle(o,a,b)
        if o['blocked']:
            o['walk_remaining']=0.;o['walk_speed']=0.
        else:
            o['x'],o['y']=b;o['walk_phase']=o.get('walk_phase',0)+speed*dt*10

    def tick(self,dt):
        dt=min(.1,max(0.,dt))
        for o in self.obstacles.values():
            if o['mode']=='wander':self.wander(o,dt);continue
            if o['mode']!='patrol':continue
            target=o['b'] if o['direction']==1 else o['a'];start=(o['x'],o['y']);d=math.dist(start,target)
            if d<.001:o['direction']*=-1;continue
            f=min(1.,o['speed']*dt/d);end=[start[i]+(target[i]-start[i])*f for i in (0,1)]
            o['blocked']=not self.free_obstacle(o,start,end)
            if o['blocked']:o['direction']*=-1
            else:o['x'],o['y']=end
        self.sense()
        if not self.rt['active']:return
        now=self.clock()
        if math.dist(self.pose(),self.core._stations[self.rt['destination']])<=.08:
            self.stop('목표 지점에 도착했습니다.','ARRIVED');return
        if now-self.started_at>600 or (self.rt.get('mode')!='global' and self.rt['cycle']>=40 and self.rt['phase']=='OBSERVING'):
            self.stop('10분 또는 40회 관측 한도에 도달했습니다.','LIMIT');return
        if self.rt.get('mode')=='global':
            self.global_tick(dt);return
        if self.rt['phase']=='THINKING' and now-self.observed_at>45:
            self.reject('판단 응답을 받지 못했습니다. 다시 관측합니다.');return
        if self.rt['phase']=='WAITING' and now>=self.wait_until:self.rt['phase']='OBSERVING'
        if self.rt['phase']!='MOVING' or not self.target:return
        p=self.pose();d=math.dist(p,self.target)
        speed=min(.4,d/max(dt,.001));vx,vy=[(self.target[i]-p[i])*speed/d if d else 0. for i in (0,1)]
        self.core.manual_step(vx,vy,dt)
        blocked=self.core.navigation_state()['collision_blocked']
        if blocked or math.dist(self.pose(),self.target)<.001:
            self.core.manual_step(0,0,dt);self.target=None;self.rt['phase']='OBSERVING'
            self.event('이동 중 충돌 차단' if blocked else '짧은 이동 완료','이동을 멈추고 최신 화면을 다시 관측합니다.','ROS',{'pose':self.pose()},'WARN' if blocked else 'INFO')
