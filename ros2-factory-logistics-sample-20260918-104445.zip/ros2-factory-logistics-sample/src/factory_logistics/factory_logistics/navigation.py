"""Deterministic grid A* and swept-segment collision checks for the sample map.

Walls are inflated by the robot radius (conservative square footprint). All
consumers use this same geometry: drawing, preview, automatic and manual motion.
"""
import copy
import heapq
import itertools
import json
import math
from pathlib import Path


class NavigationMap:
    def __init__(self, data=None):
        self.data = copy.deepcopy(data if data is not None else json.loads(
            Path(__file__).with_name('navigation_map.json').read_text()))
        self.body_radius = self.data['robot_radius']
        self.clearance = self.data.get('robot_clearance',0.)
        self.radius = self.body_radius + self.clearance
        self.resolution = self.data['resolution']
        self.bounds = self.data['center_bounds']
        self.outer = self.data['outer_bounds']
        self.walls = self.data['walls']
        if not 0 < self.resolution <= 1 or not 0 < self.radius < 1:
            raise ValueError('invalid navigation resolution or footprint')
        self.inflated = [(x0-self.radius, y0-self.radius, x1+self.radius, y1+self.radius)
                         for x0,y0,x1,y1 in self.walls]
        x0,y0,x1,y1 = self.bounds
        self.nodes = {}
        for i in range(round((x1-x0)/self.resolution)+1):
            for j in range(round((y1-y0)/self.resolution)+1):
                p = (round(x0+i*self.resolution, 8), round(y0+j*self.resolution, 8))
                if self.point_free(p):
                    self.nodes[(i,j)] = p

    def point_free(self, p):
        if len(p) != 2 or any(not math.isfinite(v) for v in p):
            return False
        x,y = p
        x0,y0,x1,y1 = self.bounds
        if not x0-1e-9 <= x <= x1+1e-9 or not y0-1e-9 <= y <= y1+1e-9:
            return False
        ox0,oy0,ox1,oy1 = self.outer
        if not ox0+self.radius <= x <= ox1-self.radius or not oy0+self.radius <= y <= oy1-self.radius:
            return False
        return not any(a-1e-9 <= x <= c+1e-9 and b-1e-9 <= y <= d+1e-9 for a,b,c,d in self.inflated)

    def segment_free(self, start, end):
        if not self.point_free(start) or not self.point_free(end):
            return False
        for rect in self.inflated:
            low, high = 0., 1.
            for axis in (0,1):
                delta = end[axis] - start[axis]
                minimum, maximum = rect[axis]-1e-9, rect[axis+2]+1e-9
                if abs(delta) < 1e-12:
                    if not minimum <= start[axis] <= maximum:
                        low, high = 1., 0.
                        break
                else:
                    a, b = sorted(((minimum-start[axis])/delta, (maximum-start[axis])/delta))
                    low, high = max(low,a), min(high,b)
            if low <= high:
                return False
        return True

    @staticmethod
    def length(path):
        return sum(math.dist(a,b) for a,b in zip(path,path[1:]))

    def plan(self, start, goal):
        start,goal = tuple(start),tuple(goal)
        if not self.point_free(start) or not self.point_free(goal):
            raise ValueError('시작 또는 목표가 벽/로봇 여유 공간에 포함됩니다.')
        if self.segment_free(start, goal):
            return [list(start), list(goal)]

        def anchor(point):
            # A short collision-checked connection from a continuous pose to the grid.
            candidates = sorted(self.nodes, key=lambda n: math.dist(point,self.nodes[n]))
            for node in candidates:
                if math.dist(point,self.nodes[node]) > self.resolution*2:
                    break
                if self.segment_free(point,self.nodes[node]):
                    return node
            raise ValueError('현재 위치를 안전한 경로 격자에 연결할 수 없습니다.')

        first,last = anchor(start),anchor(goal)
        serial = itertools.count()
        heap = [(0.,next(serial),first)]
        cost, parent = {first:0.}, {}
        closed = set()
        while heap:
            _,_,node = heapq.heappop(heap)
            if node in closed:
                continue
            if node == last:
                break
            closed.add(node)
            for di,dj in ((1,0),(0,1),(-1,0),(0,-1)):
                other = (node[0]+di,node[1]+dj)
                if other not in self.nodes or not self.segment_free(self.nodes[node], self.nodes[other]):
                    continue
                new = cost[node] + self.resolution
                if new < cost.get(other, math.inf)-1e-9:
                    cost[other],parent[other] = new,node
                    h = self.resolution*(abs(other[0]-last[0])+abs(other[1]-last[1]))
                    heapq.heappush(heap,(new+h,next(serial),other))
        else:
            raise ValueError('벽을 피해서 목표에 도달할 수 있는 경로가 없습니다.')
        chain = [last]
        while chain[-1] != first:
            chain.append(parent[chain[-1]])
        points = [start] + [self.nodes[n] for n in reversed(chain)] + [goal]
        # Remove intermediate grid points only after checking the entire new segment.
        route, index = [points[0]], 0
        while index < len(points)-1:
            next_index = len(points)-1
            while next_index > index+1 and not self.segment_free(points[index],points[next_index]):
                next_index -= 1
            route.append(points[next_index])
            index = next_index
        return [list(p) for p in route]
