"""Finite ROS 2 action client: two demo jobs or one explicitly requested job."""
import argparse
import math
import sys
import time

import rclpy
from action_msgs.msg import GoalStatus
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.utilities import remove_ros_args

from factory_interfaces.action import TransportJob


def wait_future(node, future, timeout):
    deadline = time.monotonic() + timeout
    while rclpy.ok() and not future.done() and time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=min(0.1, max(0.0, deadline - time.monotonic())))
    if not future.done():
        raise TimeoutError('ROS response timed out')
    return future.result()


def run_job(node, client, job_id, destination, timeout, cancel_after=None):
    last_print = [0.0]

    def feedback(message):
        now = time.monotonic()
        if now - last_print[0] >= 0.5:
            value = message.feedback
            node.get_logger().info('{} {} ({:.2f}, {:.2f}) remaining={:.2f}m'.format(
                job_id, value.state, value.pose.pose.position.x,
                value.pose.pose.position.y, value.remaining_distance))
            last_print[0] = now

    started = time.monotonic()
    goal = TransportJob.Goal(job_id=job_id, destination=destination)
    handle = wait_future(node, client.send_goal_async(goal, feedback_callback=feedback), timeout)
    if not handle.accepted:
        raise RuntimeError('Job rejected: {}'.format(job_id))
    result_future = handle.get_result_async()
    cancel_future = None
    try:
        while rclpy.ok() and not result_future.done():
            elapsed = time.monotonic() - started
            if elapsed >= timeout:
                raise TimeoutError('Job deadline exceeded: {}'.format(job_id))
            if cancel_after is not None and elapsed >= cancel_after and cancel_future is None:
                cancel_future = handle.cancel_goal_async()
            rclpy.spin_once(node, timeout_sec=0.1)
        if not result_future.done():
            raise RuntimeError('ROS shutdown before job result')
        wrapped = result_future.result()
    except Exception:
        # Best effort only: a client timeout is not proof the remote robot stopped.
        try:
            wait_future(node, handle.cancel_goal_async(), 1.0)
        except Exception:
            pass
        raise
    expected = GoalStatus.STATUS_CANCELED if cancel_after is not None else GoalStatus.STATUS_SUCCEEDED
    if wrapped.status != expected:
        raise RuntimeError('Unexpected action status {}: {}'.format(wrapped.status, wrapped.result.message))
    if expected == GoalStatus.STATUS_SUCCEEDED and not wrapped.result.success:
        raise RuntimeError(wrapped.result.message)
    if expected == GoalStatus.STATUS_CANCELED and wrapped.result.success:
        raise RuntimeError('Canceled job incorrectly reported success')
    node.get_logger().info('{} finished: {}'.format(job_id, wrapped.result.message))


def main(args=None):
    argv = remove_ros_args(args=sys.argv if args is None else ['task_dispatcher'] + list(args))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job-id')
    parser.add_argument('--destination')
    parser.add_argument('--timeout', type=float, default=20.0)
    parser.add_argument('--cancel-after', type=float)
    options = parser.parse_args(argv[1:])
    if (options.job_id is None) != (options.destination is None):
        parser.error('--job-id and --destination must be supplied together')
    if not math.isfinite(options.timeout) or options.timeout <= 0:
        parser.error('--timeout must be positive and finite')
    if options.cancel_after is not None:
        if options.job_id is None:
            parser.error('--cancel-after requires a single --job-id and --destination')
        if not math.isfinite(options.cancel_after) or not 0 <= options.cancel_after < options.timeout:
            parser.error('--cancel-after must be finite and between zero and --timeout')
    rclpy.init(args=args)
    node = Node('task_dispatcher')
    client = ActionClient(node, TransportJob, '/factory/transport')
    exit_code = 0
    try:
        if not client.wait_for_server(timeout_sec=min(10.0, options.timeout)):
            raise TimeoutError('No /factory/transport server found')
        jobs = [(options.job_id, options.destination)] if options.job_id is not None else [
            ('JOB-001', 'line_a'), ('JOB-002', 'warehouse')]
        for job_id, destination in jobs:
            run_job(node, client, job_id, destination, options.timeout, options.cancel_after)
        node.get_logger().info('Demo complete')
    except (Exception, KeyboardInterrupt) as exc:
        node.get_logger().error(str(exc) or 'Interrupted')
        exit_code = 1
    finally:
        client.destroy()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
