"""Local HTTP dashboard backed by actual ROS Action and Topic interfaces."""
import base64
import collections
import copy
import datetime
import json
import math
import re
import signal
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

import rclpy
from action_msgs.msg import GoalStatus
from action_msgs.srv import CancelGoal
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import TwistStamped
from rcl_interfaces.msg import Log
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from factory_interfaces.action import TransportJob
from factory_interfaces.srv import ApplyMap
from factory_logistics.llm_provider import LLMService
from factory_logistics.vision_planner import VisionPlanner, PlanError
from factory_logistics.navigation import NavigationMap
from factory_logistics.realtime_bridge import RealtimeBridge
from factory_logistics.map_store import load_map, validate_map
from factory_logistics.floorplan import render_floorplan
from factory_logistics.camera import render_camera, render_overview


def timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class RequestError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)


class WebBridge(Node):
    def __init__(self):
        super().__init__('factory_web_bridge')
        self.lock = threading.RLock()
        self.robot = None
        self.received_at = None
        self.jobs = collections.OrderedDict()
        self.events = collections.deque(maxlen=50)
        self.ros_logs = collections.deque(maxlen=300)
        self.log_sequence = 0
        self.manual_until = 0.
        self.velocity_pub = self.create_publisher(TwistStamped, '/factory/cmd_vel', 1)
        log_qos = QoSProfile(depth=300, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.log_subscription = self.create_subscription(Log, '/rosout', self.on_log, log_qos)
        self.pending = False
        self.cancel_pending = False
        self.map_pending = False
        self.map_target = None
        self.map_client = self.create_client(ApplyMap, '/factory/apply_map')
        self.client = ActionClient(self, TransportJob, '/factory/transport')
        self.cancel_client = self.create_client(CancelGoal, '/factory/transport/_action/cancel_goal')
        self.subscription = self.create_subscription(String, '/factory/robot_state', self.on_state, 10)
        positions = load_map().data.get('stations') or json.loads(Path(__file__).with_name('stations.json').read_text())
        labels = {'warehouse': '창고', 'line_a': '생산라인 A', 'line_b': '생산라인 B'}
        self.stations = [{'id': key, 'label': labels.get(key, key), 'x': value[0], 'y': value[1]}
                         for key, value in positions.items()]
        self.station_ids = set(positions)
        self.navigation = load_map()
        self.preview_pose = None
        self.preview_routes = {}
        self.floorplan = render_floorplan(self.navigation, self.stations)
        self.ai = VisionPlanner(self.stations, self.floorplan)
        self.ai.update_map(self.navigation, self.floorplan)
        self.realtime = RealtimeBridge(self)
        self.llm = LLMService(self)

    def apply_map(self, payload):
        with self.lock:
            if not self.snapshot()['can_submit'] or not self.map_client.service_is_ready():
                raise RequestError(409, '로봇이 연결된 정지 상태에서 적용해 주세요.')
            if self.ai.snapshot()['plan'] and self.ai.snapshot()['plan']['state'] == 'EXECUTING':
                raise RequestError(409, 'AI 이동 요청이 처리 중입니다.')
            if payload.get('expected_id') != self.navigation.data['id']:
                raise RequestError(409, '현재 도면이 변경되었습니다. 현재 도면 불러오기를 눌러 주세요.')
            try:
                navigation = validate_map(payload.get('map'), (self.robot['x'], self.robot['y']))
            except ValueError as exc:
                raise RequestError(400, str(exc))
            self.map_pending = True
            self.map_target = navigation.data['id']
            request = ApplyMap.Request(expected_id=payload['expected_id'], map_json=json.dumps(navigation.data))
        done, result = threading.Event(), {}
        def received(future):
            with self.lock:
                try:
                    response = future.result()
                    result.update(status=200 if response.success else 409,
                                  message=response.message, map_id=response.map_id)
                    if not response.success:
                        result['error'] = response.message
                    if self.map_target == navigation.data['id'] and (not response.success or self.navigation.data['id'] == response.map_id):
                        self.map_pending = False
                except Exception:
                    self.map_pending = False
                    result.update(status=502, error='ROS 도면 적용 응답을 확인하지 못했습니다.')
                finally:
                    done.set()
        try:
            self.map_client.call_async(request).add_done_callback(received)
        except Exception:
            with self.lock:
                self.map_pending = False
            raise RequestError(502, 'ROS 도면 적용 요청을 전송하지 못했습니다.')
        if not done.wait(3.):
            return 202, {'pending': True, 'message': 'ROS 도면 적용 결과를 기다리고 있습니다.'}
        return result.pop('status'), result

    def ai_request(self, payload):
        with self.lock:
            if not self.snapshot()['can_submit']:
                raise RequestError(409, '로봇이 연결된 대기 상태에서 도면을 읽어 주세요.')
            self.get_logger().info('[Codex] Drawing analysis requested')
            return self.ai.request(payload, (self.robot['x'], self.robot['y']))

    def ai_execute(self, payload):
        with self.lock:
            if not self.snapshot()['can_submit']:
                raise RequestError(409, '현재 작업이 끝난 뒤 실행해 주세요.')
            job = self.ai.prepare_execution(payload, (self.robot['x'], self.robot['y']))
        try:
            status, result = self.submit(job)
            with self.lock:
                if job['job_id'] in self.jobs:
                    self.jobs[job['job_id']]['source'] = 'CODEX'
            if status != 202:
                self.ai.execution_state('FAILED', result.get('error', 'ROS 요청이 거절되었습니다.'))
            else:
                self.get_logger().info('[Codex] Validated target dispatched: {} -> {}'.format(job['job_id'], job['destination']))
            return status, result
        except Exception:
            self.ai.execution_state('FAILED', 'ROS 작업 전송에 실패했습니다. 작업 기록을 확인해 주세요.')
            raise

    def on_log(self, msg):
        with self.lock:
            self.log_sequence += 1
            self.ros_logs.appendleft({'id': self.log_sequence, 'stamp': msg.stamp.sec + msg.stamp.nanosec / 1e9,
                'level': msg.level, 'name': msg.name, 'message': msg.msg,
                'file': msg.file, 'function': msg.function, 'line': msg.line})

    def teleop(self, payload):
        x, y = payload.get('x'), payload.get('y')
        if type(x) not in (int, float) or type(y) not in (int, float) or x not in (-1, 0, 1) or y not in (-1, 0, 1):
            raise RequestError(400, '방향 값은 -1, 0, 1이어야 합니다.')
        issued = payload.get('issued_at')
        # Host browser and Linux VM clocks may differ slightly.
        if type(issued) not in (int, float) or not -.5 <= time.time() - issued < .5:
            raise RequestError(400, '만료된 조작 명령입니다.')
        with self.lock:
            state = self.snapshot()
            if not state['connected']:
                raise RequestError(503, 'ROS 연결을 확인해 주세요.')
            if state['pending'] or self.map_pending or self.robot.get('realtime',{}).get('active') or self.realtime.pending or self.robot['state'] == 'RUNNING':
                raise RequestError(409, '운반 작업 종료 후 수동 조작할 수 있습니다.')
            scale = .5 / max(1., math.hypot(x, y))
            msg = TwistStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map'
            msg.twist.linear.x, msg.twist.linear.y = x * scale, y * scale
            self.velocity_pub.publish(msg)
            self.manual_until = time.monotonic() + .35 if x or y else 0.
            return 202, {'accepted': True}

    def event(self, message, kind='info'):
        self.events.appendleft({'at': timestamp(), 'message': message, 'kind': kind})

    def new_job(self, job_id, destination, source):
        origin = [self.robot['x'], self.robot['y']] if self.robot else [0.0, 0.0]
        target = next(s for s in self.stations if s['id'] == destination)
        self.jobs[job_id] = {
            'job_id': job_id, 'destination': destination, 'source': source,
            'state': 'SUBMITTING', 'started_at': timestamp(), 'finished_at': None,
            'origin': origin, 'total_distance': math.hypot(target['x'] - origin[0], target['y'] - origin[1]),
            'message': '요청 확인 중',
        }
        while len(self.jobs) > 100:
            self.jobs.popitem(last=False)
        return self.jobs[job_id]

    def on_state(self, message):
        try:
            state = json.loads(message.data)
            if not all(key in state for key in ('x', 'y', 'state', 'job_id', 'destination')):
                return
        except (ValueError, TypeError):
            return
        with self.lock:
            geometry = state.get('navigation')
            if geometry and geometry['id'] != self.navigation.data['id']:
                self.navigation = NavigationMap(geometry)
                positions=geometry.get('stations') or json.loads(Path(__file__).with_name('stations.json').read_text())
                labels={'warehouse':'입고 / 창고','line_a':'출고 / A','line_b':'피킹 / B'}
                self.stations=[dict(id=k,label=labels[k],x=v[0],y=v[1]) for k,v in positions.items()]
                self.ai.stations={s['id']:s for s in self.stations}
                self.floorplan = render_floorplan(self.navigation, self.stations)
                self.ai.update_map(self.navigation, self.floorplan)
                self.preview_pose = None
                self.event('사용자 도면 적용 · 장애물 {}개'.format(len(geometry['walls'])))
            if geometry and geometry['id'] == self.map_target:
                self.map_pending = False
            self.robot = state
            self.received_at = time.monotonic()
            job_id = state['job_id']
            if not job_id or state['destination'] not in self.station_ids:
                return
            if job_id not in self.jobs:
                self.new_job(job_id, state['destination'], 'ROS')
                self.event('{} · 외부 작업 감지'.format(job_id))
            job = self.jobs[job_id]
            if job['state'] != state['state']:
                self.event('{} · {}'.format(job_id, {
                    'RUNNING': '이동 시작', 'SUCCEEDED': '목적지 도착',
                    'CANCELED': '작업 취소 완료', 'FAILED': '작업 실패',
                }.get(state['state'], state['state'])), state['state'].lower())
            job.update(state=state['state'], message=state.get('message', ''))
            if state['state'] in ('SUCCEEDED', 'CANCELED', 'FAILED') and not job['finished_at']:
                job['finished_at'] = timestamp()

    def snapshot(self):
        with self.lock:
            ai = self.ai.snapshot()
            if ai['plan'] and ai['plan']['state'] == 'EXECUTING':
                job = self.jobs.get(ai['plan']['id'])
                if job and job['state'] in ('SUCCEEDED', 'CANCELED', 'FAILED', 'REJECTED'):
                    self.ai.execution_state(job['state'], job['message'])
                    ai = self.ai.snapshot()
            age = None if self.received_at is None else time.monotonic() - self.received_at
            connected = age is not None and age < 2.0 and self.client.server_is_ready()
            running = bool(self.robot and (self.robot['state'] == 'RUNNING' or self.robot.get('realtime',{}).get('active'))) or self.realtime.pending
            goal_uuid = self.robot.get('goal_uuid', '') if self.robot else ''
            if self.robot:
                pose = (self.robot['x'],self.robot['y'])
                if pose != self.preview_pose:
                    self.preview_pose, self.preview_routes = pose, {}
                    for station in self.stations:
                        try:
                            self.preview_routes[station['id']] = self.navigation.plan(pose, (station['x'],station['y']))
                        except ValueError:
                            self.preview_routes[station['id']] = []
            return copy.deepcopy({
                'llm': self.llm.public(), 'connected': connected, 'age_seconds': age, 'robot': self.robot,
                'pending': self.pending, 'cancel_pending': self.cancel_pending,
                'can_submit': connected and not running and not self.pending and not self.map_pending and self.robot['state'] != 'MANUAL' and time.monotonic() >= self.manual_until,
                'can_teleop': connected and not running and not self.pending and not self.map_pending,
                'map_pending': self.map_pending,
                'sensor': (self.robot or {}).get('sensor',{}),
                'observation_image_id': ((self.robot or {}).get('realtime',{}).get('observation') or {}).get('id') if ((self.robot or {}).get('realtime',{}).get('observation') or {}).get('id') in self.realtime.images else None,
                'can_cancel': connected and running and len(goal_uuid) == 32 and not self.cancel_pending,
                'stations': self.stations, 'jobs': list(reversed(self.jobs.values())),
                'events': list(self.events), 'server_time': timestamp(),
                'ros_logs': list(self.ros_logs),
                'ai': dict(ai,logs=sorted(ai['logs']+(self.robot or {}).get('realtime_logs',[]),key=lambda item:item['stamp'],reverse=True)[:200]),
                'realtime': (self.robot or {}).get('realtime',{}), 'obstacles': (self.robot or {}).get('obstacles',[]),
                'navigation': self.navigation.data, 'preview_routes': self.preview_routes,
            })

    def submit(self, payload):
        job_id, destination = payload.get('job_id'), payload.get('destination')
        if not isinstance(job_id, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}', job_id):
            raise RequestError(400, '작업 ID는 영문·숫자로 시작하는 1~64자의 영문, 숫자, _, -, ., :만 사용할 수 있습니다.')
        if not isinstance(destination, str) or destination not in self.station_ids:
            raise RequestError(400, '등록되지 않은 목적지입니다.')
        with self.lock:
            state = self.snapshot()
            if not state['connected']:
                raise RequestError(503, 'ROS 연결을 확인한 뒤 다시 요청해 주세요.')
            if not state['can_submit']:
                raise RequestError(409, '현재 작업이 끝나거나 취소될 때까지 기다려 주세요.')
            if job_id in self.jobs:
                raise RequestError(409, '이미 사용한 작업 ID입니다. 새 ID를 입력해 주세요.')
            self.pending = True
            self.new_job(job_id, destination, 'WEB')
            self.event('{} · 운반 요청'.format(job_id))
        done = threading.Event()
        response = {}

        def admitted(future):
            try:
                handle = future.result()
                with self.lock:
                    if not handle.accepted:
                        self.jobs[job_id].update(state='REJECTED', finished_at=timestamp(), message='로봇이 요청을 거절했습니다.')
                        self.event('{} · 요청 거절'.format(job_id), 'failed')
                        response.update(status=409, error='로봇이 요청을 거절했습니다. 작업 상태와 ID를 확인해 주세요.')
                    else:
                        response.update(status=202, job_id=job_id, accepted=True)
                if handle.accepted:
                    handle.get_result_async().add_done_callback(finished)
            except Exception as exc:
                with self.lock:
                    self.jobs[job_id].update(state='FAILED', finished_at=timestamp(), message=str(exc))
                    response.update(status=502, error='ROS 요청 응답을 처리하지 못했습니다.')
            finally:
                with self.lock:
                    self.pending = False
                done.set()

        def finished(future):
            with self.lock:
                try:
                    wrapped = future.result()
                    state = {GoalStatus.STATUS_SUCCEEDED: 'SUCCEEDED', GoalStatus.STATUS_CANCELED: 'CANCELED'}.get(wrapped.status, 'FAILED')
                    self.jobs[job_id].update(state=state, finished_at=timestamp(), message=wrapped.result.message)
                except Exception as exc:
                    self.jobs[job_id].update(state='FAILED', finished_at=timestamp(), message=str(exc))

        try:
            self.client.send_goal_async(TransportJob.Goal(job_id=job_id, destination=destination)).add_done_callback(admitted)
        except Exception:
            with self.lock:
                self.pending = False
                self.jobs[job_id].update(state='FAILED', finished_at=timestamp(), message='요청 전송 실패')
            raise RequestError(502, 'ROS에 요청을 전송하지 못했습니다.')
        if not done.wait(3.0):
            # Do not claim failure or resubmit while admission remains unknown.
            return 202, {'job_id': job_id, 'pending': True, 'message': 'ROS 접수 응답을 기다리고 있습니다.'}
        status = response.pop('status')
        return status, response

    def cancel(self, payload):
        with self.lock:
            state = self.snapshot()
            if not state['connected']:
                raise RequestError(503, 'ROS 연결이 끊겨 취소를 요청할 수 없습니다.')
            if not state['can_cancel'] or payload.get('job_id') != self.robot['job_id']:
                raise RequestError(409, '현재 실행 중인 작업이 변경되었거나 취소할 작업이 없습니다.')
            if not self.cancel_client.service_is_ready():
                raise RequestError(503, 'ROS 취소 서비스가 준비되지 않았습니다.')
            request = CancelGoal.Request()
            request.goal_info.goal_id.uuid = list(bytes.fromhex(self.robot['goal_uuid']))
            job_id = self.robot['job_id']
            self.cancel_pending = True
        done, response = threading.Event(), {}

        def received(future):
            with self.lock:
                try:
                    accepted = bool(future.result().goals_canceling)
                    response.update(status=202 if accepted else 409, accepted=accepted,
                                    message='취소 요청을 접수했습니다.' if accepted else '이미 종료된 작업이거나 취소가 거절되었습니다.')
                    self.event('{} · {}'.format(job_id, response['message']), 'canceled')
                except Exception:
                    response.update(status=502, error='취소 응답을 처리하지 못했습니다.')
                finally:
                    self.cancel_pending = False
                    done.set()
        try:
            self.cancel_client.call_async(request).add_done_callback(received)
        except Exception:
            with self.lock:
                self.cancel_pending = False
            raise RequestError(502, '취소 요청을 전송하지 못했습니다.')
        if not done.wait(3.0):
            return 202, {'pending': True, 'message': 'ROS 취소 응답을 기다리고 있습니다.'}
        return response.pop('status'), response


def make_handler(bridge):
    assets = Path(__file__).with_name('web')

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def valid_host(self):
            return self.headers.get('Host') in ('localhost:{}'.format(self.server.server_port),
                                                '127.0.0.1:{}'.format(self.server.server_port))

        def reply(self, status, data, content_type='application/json; charset=utf-8'):
            body = json.dumps(data, ensure_ascii=False).encode() if not isinstance(data, bytes) else data
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' http://localhost:8768 http://127.0.0.1:8768; img-src 'self' data: blob:; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            if not self.valid_host():
                return self.reply(403, {'error': '로컬 주소로 접속해 주세요.'})
            path = urlsplit(self.path).path
            if path == '/api/vision/status':
                with bridge.realtime.lock:
                    return self.reply(200,dict(bridge.realtime.vision_status))
            if path == '/api/state':
                return self.reply(200, bridge.snapshot())
            if path == '/api/scene':
                with bridge.lock:
                    robot=bridge.robot
                    if not robot:return self.reply(503,{'error':'로봇 연결 대기'})
                    age=None if bridge.received_at is None else time.monotonic()-bridge.received_at
                    payload=copy.deepcopy(dict(connected=age is not None and age<2,
                        navigation=bridge.navigation.data,
                        scene=dict(pose=[robot['x'],robot['y']],yaw=robot.get('yaw',0),
                            obstacles=robot.get('obstacles',[]),route=robot.get('realtime',{}).get('route',[]))))
                return self.reply(200,payload)
            if path in ('/api/camera.png','/api/overview.png','/api/views'):
                with bridge.lock:
                    robot=bridge.robot
                    if not robot:return self.reply(503,{'error':'로봇 연결 대기'})
                    navigation=bridge.navigation
                    scene=copy.deepcopy(dict(pose=[robot['x'],robot['y']],yaw=robot.get('yaw',0),obstacles=robot.get('obstacles',[]),route=robot.get('realtime',{}).get('route',[])))
                    captured_at=timestamp()
                if path=='/api/views':
                    return self.reply(200,dict(captured_at=captured_at,pose=scene['pose'],yaw=scene['yaw'],
                        camera=base64.b64encode(render_camera(navigation,scene)).decode('ascii'),
                        overview=base64.b64encode(render_overview(navigation,scene)).decode('ascii')))
                renderer=render_camera if path=='/api/camera.png' else render_overview
                return self.reply(200,renderer(navigation,scene),'image/png')
            if path == '/health':
                return self.reply(200, {'ok': True})
            if path == '/api/realtime/observation.png':
                try:
                    identifier=parse_qs(urlsplit(self.path).query).get('id',[''])[0]
                    return self.reply(200, bridge.realtime.image(identifier), 'image/png')
                except PlanError as exc:
                    return self.reply(exc.status, {'error':exc.message})
            if path == '/floorplan.png':
                with bridge.lock:
                    return self.reply(200, bridge.floorplan, 'image/png')
            files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'application/javascript'), '/llm.js': ('llm.js','application/javascript'),
                     '/previous-map.json': ('previous-map.json', 'application/json'),
                     '/editor.js': ('editor.js', 'application/javascript'),
                     '/decisions.js': ('decisions.js', 'application/javascript'),
                     '/realtime.js': ('realtime.js', 'application/javascript'),
                     '/styles.css': ('styles.css', 'text/css'), '/favicon.svg': ('favicon.svg', 'image/svg+xml'),
                     '/floorplan.png': ('floorplan.png', 'image/png')}
            if path not in files:
                return self.reply(404, {'error': '찾을 수 없는 경로입니다.'})
            name, content_type = files[path]
            return self.reply(200, (assets / name).read_bytes(), content_type + '; charset=utf-8')

        def do_POST(self):
            origin = self.headers.get('Origin')
            if (not self.valid_host() or self.headers.get('X-Factory-Control') != '1'
                    or (origin is not None and origin != 'http://' + self.headers.get('Host', ''))):
                return self.reply(403, {'error': '이 화면에서 요청해 주세요.'})
            if self.headers.get_content_type() != 'application/json':
                return self.reply(415, {'error': 'JSON 요청이 필요합니다.'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 16384:
                    raise RequestError(400, '요청 크기를 확인해 주세요.')
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload, dict):
                    raise RequestError(400, '요청 형식을 확인해 주세요.')
                routes = {'/api/jobs': bridge.submit, '/api/cancel': bridge.cancel, '/api/teleop': bridge.teleop,
                          '/api/map': bridge.apply_map, '/api/realtime/control': bridge.realtime.control,
                          '/api/realtime/claim': lambda p: bridge.llm.claim(p,True), '/api/realtime/result': bridge.realtime.result}
                routes.update({'/api/llm/settings':bridge.llm.save,'/api/llm/test':bridge.llm.test})
                routes.update({'/api/vision/claim':bridge.realtime.vision_claim,'/api/vision/result':bridge.realtime.vision_result})
                routes.update({'/api/ai/request': bridge.ai_request, '/api/ai/execute': bridge.ai_execute,
                    '/api/ai/heartbeat': bridge.llm.heartbeat, '/api/ai/claim': bridge.llm.claim,
                    '/api/ai/result': bridge.ai.result})
                handler = routes.get(urlsplit(self.path).path)
                if handler is None:
                    raise RequestError(404, '찾을 수 없는 경로입니다.')
                status, data = handler(payload)
                self.reply(status, data)
            except (RequestError, PlanError) as exc:
                self.reply(exc.status, {'error': exc.message})
            except (ValueError, UnicodeDecodeError):
                self.reply(400, {'error': '올바른 JSON 요청이 필요합니다.'})
            except Exception as exc:
                bridge.get_logger().error('HTTP operation failed: {}'.format(exc))
                self.reply(500, {'error': '요청을 처리하지 못했습니다. 상태를 확인해 주세요.'})
    return Handler


def main(args=None):
    rclpy.init(args=args)
    node = WebBridge()
    executor = MultiThreadedExecutor(num_threads=3)
    executor.add_node(node)
    stop = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_args: stop.set())
    server = ThreadingHTTPServer(('0.0.0.0', 8765), make_handler(node))
    server.daemon_threads = True
    ros_thread = threading.Thread(target=executor.spin, daemon=True)
    http_thread = threading.Thread(target=server.serve_forever, daemon=True)
    ros_thread.start()
    http_thread.start()
    node.get_logger().info('Factory web UI: http://localhost:8765')
    try:
        while not stop.wait(0.5):
            if not ros_thread.is_alive() or not http_thread.is_alive():
                raise RuntimeError('Web or ROS executor stopped unexpectedly')
    finally:
        node.llm.stop.set()
        server.shutdown()
        server.server_close()
        http_thread.join(timeout=3)
        executor.shutdown(timeout_sec=3)
        ros_thread.join(timeout=3)
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
