"""Ideal planar range sensor with occlusion and last-observed obstacle memory.

Only this boundary reads dynamic world truth. Navigation receives detached tracks;
physical collision checking remains independent. No RGB inference is implied.
"""
import copy
import math


def distance_segment(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]
    t=max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy))) if dx or dy else 0.
    return math.dist(p,(a[0]+t*dx,a[1]+t*dy))


class RangeSensor:
    RANGE=2.
    def __init__(self,base):
        self.sight=copy.copy(base)
        self.sight.radius=0
        self.sight.inflated=list(base.walls)
        self.tracks={}
        self.visible=set()
        self.revision=0
    def clear_line(self,pose,point,world,ignore=None):
        if math.dist(pose,point)>self.RANGE or not self.sight.segment_free(pose,point):return False
        return not any(o['id']!=ignore and distance_segment((o['x'],o['y']),pose,point)<o['radius']-.002 for o in world.values())
    def scan(self,pose,world,now):
        visible=set();new=[];cleared=[]
        for key,o in world.items():
            dx,dy=o['x']-pose[0],o['y']-pose[1];d=math.hypot(dx,dy)
            if d-o['radius']>self.RANGE:continue
            # Center and two edge returns approximate finite-width detection.
            points=[[o['x']-dx/max(d,1e-9)*o['radius'],o['y']-dy/max(d,1e-9)*o['radius']]]
            points += [[o['x']+sign*dy/max(d,1e-9)*o['radius']*.8,o['y']-sign*dx/max(d,1e-9)*o['radius']*.8] for sign in (-1,1)]
            if not any(self.clear_line(pose,p,world,key) for p in points):continue
            visible.add(key);old=self.tracks.get(key)
            if old is None:new.append(key)
            speed=math.dist((o['x'],o['y']),(old['x'],old['y']))/max(.001,now-old['last_seen']) if old else 0.
            moving=speed>.025 or bool(old and old.get('moving_until',0)>now)
            self.tracks[key]=dict(id=key,x=o['x'],y=o['y'],radius=o['radius'],last_seen=now,moving=moving,moving_until=now+.4 if speed>.025 else old.get('moving_until',0) if old else 0.)
        for key,old in list(self.tracks.items()):
            if key in visible:continue
            point=[old['x'],old['y']]
            # Forget only when the old occupied location has been observed free.
            if self.clear_line(pose,point,world):
                del self.tracks[key];cleared.append(key)
        if new or cleared:self.revision+=1
        self.visible=visible
        return new,cleared
    def snapshot(self,now):
        return dict(type='simulated_360_range',range_m=self.RANGE,fov_deg=360,
                    tracks=[dict(o,visible=k in self.visible,age_seconds=round(max(0,now-o['last_seen']),2)) for k,o in self.tracks.items()],visible_ids=sorted(self.visible))
