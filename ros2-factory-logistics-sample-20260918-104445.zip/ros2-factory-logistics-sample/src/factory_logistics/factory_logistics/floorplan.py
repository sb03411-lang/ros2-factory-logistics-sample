"""Render the authoritative ROS map for the vision worker and web preview."""
import io
from PIL import Image, ImageDraw, ImageFont


def render_floorplan(navigation, stations, scene=None):
    image = Image.new('RGB', (1040, 900), '#edf3fa')
    draw = ImageDraw.Draw(image)
    def font(size):
        for name in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                     '/System/Library/Fonts/Supplemental/Arial.ttf'):
            try:
                return ImageFont.truetype(name, size)
            except OSError:
                pass
        return ImageFont.load_default()
    draw.text((50, 25), 'FACTORY FLOOR / EDITABLE MAP', fill='#172b49', font=font(30))
    draw.text((50, 72), 'Meters | White: valid center area | Gray border: no entry | Dark: wall', fill='#405a78', font=font(20))
    x0, y0, x1, y1 = navigation.outer
    scale = min(840/(x1-x0), 600/(y1-y0))
    left, bottom = (1040-(x1-x0)*scale)/2, 760
    def point(x, y):
        return (left+(x-x0)*scale, bottom-(y-y0)*scale)
    def rectangle(box, **kwargs):
        a,b,c,d = box
        draw.rectangle([point(a,d), point(c,b)], **kwargs)
    rectangle(navigation.outer, fill='#b7bec8', outline='#7289a5', width=3)
    rectangle(navigation.bounds, fill='#fff', outline='#c44747', width=2)
    for x in range(int(navigation.bounds[2])+1):
        draw.line([point(x,y0), point(x,y1)], fill='#dce5ef')
        draw.text(point(x,y0-.05), str(x), fill='#405a78', font=font(16), anchor='mt')
    for y in range(int(navigation.bounds[3])+1):
        draw.line([point(x0,y), point(x1,y)], fill='#dce5ef')
        draw.text(point(x0-.04,y), str(y), fill='#405a78', font=font(16), anchor='rm')
    for box in navigation.inflated:
        rectangle(box, fill='#d0d9e7')
    for box in navigation.walls:
        rectangle(box, fill='#243650', outline='#12233b', width=2)
    names = {'warehouse':'WAREHOUSE', 'line_a':'LINE A', 'line_b':'LINE B'}
    for station in stations:
        x,y = point(station['x'],station['y'])
        draw.ellipse((x-9,y-9,x+9,y+9), fill='#3269e8', outline='white', width=2)
        label = '{} ({:g}, {:g})'.format(names[station['id']],station['x'],station['y'])
        box = draw.textbbox((x,y-18), label, font=font(18), anchor='ms')
        draw.rectangle((box[0]-4,box[1]-3,box[2]+4,box[3]+3), fill='#edf3fa')
        draw.text((x,y-18), label, font=font(18), fill='#173568', anchor='ms')
    if scene:
        route=[scene['pose']]+scene.get('route',[])
        if len(route)>1:draw.line([point(*p) for p in route],fill='#24a07a',width=4)
        for obstacle in scene['obstacles']:
            x,y=point(obstacle['x'],obstacle['y']);r=obstacle['radius']*scale
            draw.ellipse((x-r,y-r,x+r,y+r),fill='#f19a35',outline='#9a5112',width=2)
            draw.text((x,y+r+5),obstacle['id'],font=font(14),anchor='mt',fill='#8e4812')
            if obstacle['mode']=='patrol':
                target=obstacle['b'] if obstacle['direction']==1 else obstacle['a']
                dx,dy=target[0]-obstacle['x'],target[1]-obstacle['y'];d=(dx*dx+dy*dy)**.5
                if d:draw.line([(x,y),point(obstacle['x']+dx/d*.35,obstacle['y']+dy/d*.35)],fill='#d9791f',width=4)
        x,y=point(*scene['target']);r=16
        draw.ellipse((x-r,y-r,x+r,y+r),outline='#24a07a',width=4)
        x,y=point(*scene['pose']);r=navigation.body_radius*scale
        draw.ellipse((x-r,y-r,x+r,y+r),fill='#3269e8',outline='white',width=3)
        draw.text((50,108),'ROBOT ({:.2f}, {:.2f}) | GOAL {} | OBSERVATION {}'.format(*scene['pose'],scene['destination'],scene['cycle']),font=font(19),fill='#173568')
        draw.text((50,792),'Blue: robot | Green ring: goal | Orange: moving obstacle | Arrow: motion direction',font=font(16),fill='#405a78')
    draw.text((50,830), '{} | Body radius {:.2f}m + clearance {:.2f}m | {} obstacles'.format(navigation.data['id'],navigation.body_radius,navigation.clearance,len(navigation.walls)), font=font(18), fill='#405a78')
    output = io.BytesIO()
    image.save(output, format='PNG')
    return output.getvalue()
