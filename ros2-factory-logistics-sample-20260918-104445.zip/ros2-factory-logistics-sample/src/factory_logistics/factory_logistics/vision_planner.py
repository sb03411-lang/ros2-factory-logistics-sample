"""Bounded image-to-station planning queue. Model output never executes code."""
import copy
import collections
import hashlib
import math
import secrets
import threading
import time
from factory_logistics.navigation import NavigationMap


class PlanError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)


class VisionPlanner:
    def __init__(self, stations, image):
        self.lock = threading.RLock()
        self.stations = {s['id']: s for s in stations}
        self.navigation = NavigationMap()
        self.map_hash = hashlib.sha256(image).hexdigest()
        self.worker_seen = 0.
        self.plan = None
        self.token = None
        self.started = 0.
        self.ready_at = 0.
        self.logs = collections.deque(maxlen=200)
        self.log_sequence = 0

    def record(self, source, stage, message, details=None, level='INFO'):
        """Store explicit model output and system decisions, never worker credentials."""
        self.log_sequence += 1
        self.logs.appendleft({'id': self.log_sequence, 'stamp': time.time(),
            'request_id': self.plan['id'] if self.plan else '',
            'map_id': self.navigation.data['id'], 'source': source, 'stage': stage,
            'level': level, 'message': str(message)[:2000], 'details': copy.deepcopy(details or {})})

    def update_map(self, navigation, image):
        with self.lock:
            self.navigation = navigation
            self.map_hash = hashlib.sha256(image).hexdigest()
            if self.plan:
                self.plan.update(state='EXPIRED', result=None, message='도면이 변경되었습니다. 새 도면을 다시 읽어 주세요.')
                self.record('VALIDATOR', '계획 만료', self.plan['message'], level='WARN')
            self.token = None
            self.record('SYSTEM', '도면 갱신', 'ROS 지도와 LLM 입력 이미지가 갱신되었습니다.',
                        {'map_hash': self.map_hash, 'obstacles': len(navigation.walls)})

    def snapshot(self):
        with self.lock:
            if self.plan and self.plan['state'] in ('QUEUED', 'READING') and time.monotonic() - self.started > 210:
                self.plan.update(state='FAILED', message='도면 해석 시간이 초과되었습니다. 다시 요청해 주세요.')
                self.record('SYSTEM', '응답 시간 초과', self.plan['message'], level='ERROR')
            return {'worker_connected': time.monotonic() - self.worker_seen < 8,
                    'map_hash': self.map_hash, 'plan': copy.deepcopy(self.plan),
                    'logs': copy.deepcopy(list(self.logs))}

    def heartbeat(self, _payload):
        with self.lock:
            self.worker_seen = time.monotonic()
        return 200, {'ok': True}

    def request(self, payload, origin):
        prompt = payload.get('prompt')
        if not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 1000:
            raise PlanError(400, '목표를 1~1000자로 입력해 주세요.')
        with self.lock:
            current = self.snapshot()
            if not current['worker_connected']:
                raise PlanError(503, 'LLM 연결기가 실행 중이지 않습니다. ros2.sh web을 다시 실행해 주세요.')
            if self.plan and self.plan['state'] in ('QUEUED', 'READING', 'EXECUTING'):
                raise PlanError(409, '진행 중인 AI 작업이 있습니다.')
            self.started = time.monotonic()
            self.token = secrets.token_hex(24)
            self.plan = {'id': 'AI-' + secrets.token_hex(6).upper(), 'state': 'QUEUED',
                         'prompt': prompt.strip(), 'origin': list(origin), 'map_hash': self.map_hash,
                         'message': 'LLM에 도면 해석을 요청했습니다.', 'result': None}
            self.record('SYSTEM', '요청 접수', prompt.strip(), {'origin': list(origin), 'map_hash': self.map_hash})
            return 202, copy.deepcopy(self.plan)

    def claim(self, _payload):
        with self.lock:
            self.snapshot()
            if not self.plan or self.plan['state'] != 'QUEUED':
                return 200, {'job': None}
            self.plan.update(state='READING', message='LLM가 도면을 읽고 있습니다.')
            self.record('SYSTEM', 'LLM 해석 시작', '현재 도면 이미지와 사용자 요청을 LLM에 전달합니다.')
            return 200, {'job': dict(copy.deepcopy(self.plan), token=self.token)}

    def result(self, payload):
        with self.lock:
            self.snapshot()
            if (not self.plan or self.plan['state'] != 'READING' or payload.get('id') != self.plan['id']
                    or not secrets.compare_digest(str(payload.get('token', '')), self.token)):
                raise PlanError(409, '만료되었거나 일치하지 않는 AI 응답입니다.')
            if payload.get('map_hash') != self.map_hash:
                self.plan.update(state='FAILED', message='해석한 도면이 현재 도면과 일치하지 않습니다.')
                self.record('VALIDATOR', '도면 검증 실패', self.plan['message'], level='ERROR')
                return 200, {'ok': False}
            if payload.get('error'):
                self.plan.update(state='FAILED', message=str(payload['error'])[:500])
                self.record('SYSTEM', 'LLM 실행 오류', self.plan['message'], level='ERROR')
                return 200, {'ok': False}
            result = payload.get('result')
            try:
                if not isinstance(result, dict) or result.get('status') not in ('ready', 'needs_clarification'):
                    raise ValueError('응답 형식을 확인할 수 없습니다.')
                if not isinstance(result.get('explanation'), str) or not isinstance(result.get('observed_label'), str):
                    raise ValueError('도면 해석 설명이 없습니다.')
                # Only schema fields intended for display; do not expose raw CLI output.
                visible = {key: result.get(key) for key in ('status', 'destination', 'target_x', 'target_y')
                           if isinstance(result.get(key), (str, int, float)) and not isinstance(result.get(key), bool)}
                visible = {key: (value[:200] if isinstance(value,str) else value)
                           for key,value in visible.items() if not isinstance(value,(int,float)) or math.isfinite(value)}
                visible['observed_label'] = result['observed_label'][:200]
                self.record('LLM', '도면 판단 결과', result['explanation'], visible,
                            level='WARN' if result['status']=='needs_clarification' else 'INFO')
                if result['status'] == 'needs_clarification':
                    self.plan.update(state='CLARIFY', message=result['explanation'][:2000], result=None)
                    self.record('VALIDATOR', '실행 보류', '모델이 목표를 확정하지 못했습니다. 요청을 구체적으로 입력해 주세요.', level='WARN')
                    return 200, {'ok': True}
                station = self.stations.get(result.get('destination'))
                x, y = result.get('target_x'), result.get('target_y')
                if not station or any(type(v) not in (int, float) or not math.isfinite(v) for v in (x, y)):
                    raise ValueError('등록된 목표와 유효한 좌표가 필요합니다.')
                if math.hypot(x - station['x'], y - station['y']) > .15:
                    raise ValueError('도면에서 읽은 좌표가 등록된 목표와 일치하지 않습니다.')
                self.record('VALIDATOR', '목표 좌표 검증 통과', '등록된 목적지와 좌표 오차를 확인했습니다. 실행에는 등록 좌표를 사용합니다.',
                            {'destination': station['id'], 'model_coordinates': [x,y],
                             'registered_coordinates': [station['x'],station['y']],
                             'error_m': round(math.hypot(x-station['x'],y-station['y']),4), 'tolerance_m': .15})
                # Use independently configured station coordinates, never raw model coordinates.
                validated = {'destination': station['id'], 'label': station['label'],
                             'x': station['x'], 'y': station['y'],
                             'observed_label': result['observed_label'][:200],
                             'explanation': result['explanation'][:2000]}
                route = self.navigation.plan(self.plan['origin'], (station['x'],station['y']))
                validated.update(route=route, route_length=self.navigation.length(route), map_id=self.navigation.data['id'])
                self.record('VALIDATOR', '통로 경로 검증 통과', 'A* 경로와 로봇 반경을 반영한 벽 충돌 검사를 통과했습니다.',
                            {'route': route, 'length_m': round(validated['route_length'],3), 'robot_radius_m': self.navigation.radius})
                self.ready_at = time.monotonic()
                self.plan.update(state='READY', result=validated, message='도면 목표와 벽을 피하는 통로 경로를 검증했습니다.')
                self.record('SYSTEM', '실행 대기', '목표까지 이동 버튼을 누르면 ROS 운반 작업을 요청합니다.')
            except (ValueError, TypeError) as exc:
                self.plan.update(state='FAILED', message=str(exc), result=None)
                self.record('VALIDATOR', '검증 실패 · 실행 차단', str(exc), level='ERROR')
            return 200, {'ok': self.plan['state'] == 'READY'}

    def prepare_execution(self, payload, origin):
        with self.lock:
            if not self.plan or self.plan['id'] != payload.get('id') or self.plan['state'] != 'READY':
                self.record('VALIDATOR', '실행 요청 거절', '실행 준비가 된 현재 AI 계획과 일치하지 않습니다.', level='WARN')
                raise PlanError(409, '실행할 준비가 된 AI 계획이 없습니다.')
            if time.monotonic() - self.ready_at > 300:
                self.plan.update(state='EXPIRED', message='계획이 만료되었습니다. 도면을 다시 읽어 주세요.')
                self.record('VALIDATOR', '계획 만료', self.plan['message'], level='WARN')
                raise PlanError(409, self.plan['message'])
            if math.dist(origin, self.plan['origin']) > .15:
                self.plan.update(state='EXPIRED', message='로봇 위치가 변경되었습니다. 도면을 다시 읽어 주세요.')
                self.record('VALIDATOR', '위치 검증 실패', self.plan['message'],
                            {'planned_origin': self.plan['origin'], 'current_origin': list(origin)}, level='WARN')
                raise PlanError(409, self.plan['message'])
            self.plan.update(state='EXECUTING', message='ROS 운반 작업을 실행하고 있습니다.')
            self.record('ROS', '이동 요청', '사용자가 승인한 목표를 ROS Action으로 전송합니다.',
                        {'job_id': self.plan['id'], 'destination': self.plan['result']['destination']})
            return {'job_id': self.plan['id'], 'destination': self.plan['result']['destination']}

    def execution_state(self, state, message):
        with self.lock:
            if self.plan and self.plan['state'] == 'EXECUTING':
                self.plan.update(state=state, message=message)
                self.record('ROS', '이동 결과', message, {'state': state},
                            level='INFO' if state=='SUCCEEDED' else 'WARN' if state=='CANCELED' else 'ERROR')
