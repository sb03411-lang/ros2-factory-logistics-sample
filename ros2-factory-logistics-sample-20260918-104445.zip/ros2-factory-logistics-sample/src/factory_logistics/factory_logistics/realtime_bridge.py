"""HTTP-facing observation queue; every action is checked by the ROS world owner."""
import base64
import time
import collections
import copy
import hashlib
import json
import secrets
import threading
from factory_interfaces.srv import WorldControl
from factory_logistics.camera import render_camera
from factory_logistics.navigation import NavigationMap
from factory_logistics.vision_planner import PlanError


class RealtimeBridge:
    def __init__(self,owner):
        self.owner=owner
        self.client=owner.create_client(WorldControl,'/factory/world_control')
        self.lock=threading.RLock()
        self.pending=False
        self.claiming=False
        self.job=None
        self.images=collections.OrderedDict()
        self.recent=collections.deque(maxlen=3)
        self.vision_frames=collections.OrderedDict()
        self.vision_status={}
        self.vision_claiming=False
        self.vision_next=0
    def call(self,payload):
        if not self.client.service_is_ready():raise PlanError(503,'실시간 ROS 서비스가 준비되지 않았습니다.')
        done=threading.Event();result={}
        def received(future):
            try:
                response=future.result();result.update(success=response.success,message=response.message,state=json.loads(response.state_json))
            except Exception as exc:result.update(success=False,message=str(exc))
            finally:done.set()
        self.client.call_async(WorldControl.Request(command_json=json.dumps(payload))).add_done_callback(received)
        if not done.wait(3):raise PlanError(504,'ROS 응답이 지연됩니다. 현재 상태를 확인해 주세요.')
        if not result['success']:raise PlanError(409,result['message'])
        return result['state']
    def control(self,payload):
        op=payload.get('operation')
        if op not in ('start','stop','obstacle'):raise PlanError(400,'지원하지 않는 명령입니다.')
        with self.owner.lock:
            if op=='start':
                state=self.owner.snapshot()
                if not state['can_submit']:raise PlanError(409,'로봇과 Codex가 연결된 정지 상태에서 시작해 주세요.')
                plan=state['ai']['plan']
                if plan and plan['state'] in ('QUEUED','READING','EXECUTING'):raise PlanError(409,'단발 Codex 요청을 먼저 완료해 주세요.')
        with self.lock:
            if self.pending and op!='stop':raise PlanError(409,'이전 변경을 적용하고 있습니다.')
            self.pending=True
            if op in ('start','stop'):self.job=None;self.recent.clear()
        try:
            state=self.call(payload)
            return 200,state
        finally:
            with self.lock:self.pending=False
    def claim(self,_payload):
        with self.owner.lock:
            robot=self.owner.robot or {}
            rt=robot.get('realtime',{})
            if not rt.get('active') or (rt.get('mode')!='global' and rt.get('phase')!='OBSERVING') or (rt.get('mode')=='global' and rt.get('review_pending')):return 200,{'job':None}
        with self.lock:
            if self.claiming or self.pending:return 200,{'job':None}
            self.claiming=True
        try:
            state=self.call({'operation':'observe'})
            observation=state['realtime']['observation']
            image=render_camera(NavigationMap(observation['navigation']),observation)
            with self.lock:
                job=dict(kind='realtime',id=observation['id'],token=secrets.token_hex(24),session=observation['session'],observation=observation,image_hash=hashlib.sha256(image).hexdigest(),recent=list(self.recent))
                self.recent.append({'pose':observation['pose'],'obstacles':observation['obstacles'],'stamp':observation['stamp']})
                self.images[job['id']]=image
                while len(self.images)>5:self.images.popitem(last=False)
                self.job=job
                return 200,{'job':copy.deepcopy(job)}
        except PlanError as exc:
            if exc.status==409:return 200,{'job':None}
            raise
        finally:
            with self.lock:self.claiming=False
    def result(self,payload):
        with self.lock:
            job=self.job
            if not job or payload.get('id')!=job['id'] or not secrets.compare_digest(str(payload.get('token','')),job['token']):raise PlanError(409,'만료된 관측 응답입니다.')
            self.job=None
        message={'operation':'action','session':job['session'],'observation_id':job['id']}
        if payload.get('image_hash')!=job['image_hash']:message['error']='관측 이미지 해시가 다릅니다.'
        elif payload.get('error'):message['error']=str(payload['error'])[:500]
        else:message['action']=payload.get('result')
        return 200,self.call(message)
    def image(self,identifier):
        with self.lock:
            if identifier not in self.images:raise PlanError(404,'관측 이미지가 아직 준비되지 않았거나 보관 기간이 지났습니다.')
            return self.images[identifier]

    def vision_claim(self,_payload):
        with self.lock:
            if self.vision_claiming or time.monotonic()<self.vision_next:return 200,{'id':None}
            self.vision_claiming=True
            self.vision_next=time.monotonic()+.2
        try:
            frame=self.call({'operation':'camera_capture'})['camera_frame']
            image=render_camera(NavigationMap(frame['navigation']),frame)
            with self.lock:
                self.vision_frames[frame['id']]=dict(image=image,pose=frame['pose'],yaw=frame['yaw'],stamp=time.time()-(time.monotonic()-frame['captured']))
                while len(self.vision_frames)>6:self.vision_frames.popitem(last=False)
            return 200,dict(id=frame['id'],image=base64.b64encode(image).decode('ascii'))
        finally:
            with self.lock:self.vision_claiming=False

    def vision_result(self,payload):
        with self.lock:
            frame=self.vision_frames.get(payload.get('id'))
            if not frame:raise PlanError(409,'만료된 카메라 이미지')
        state=self.call(dict(payload,operation='camera_result'))
        with self.lock:
            self.vision_status=dict(id=payload['id'],pose=frame['pose'],yaw=frame['yaw'],stamp=frame['stamp'],
                detections=payload.get('detections',[]),model=payload.get('model'),inference_ms=payload.get('inference_ms'),
                image=base64.b64encode(frame['image']).decode('ascii'))
        return 200,{'accepted':True}
