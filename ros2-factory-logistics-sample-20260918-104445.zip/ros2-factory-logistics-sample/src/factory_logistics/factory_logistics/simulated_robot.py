"""ROS 2 adapter for a small, non-physical movement simulation."""
import json
import threading
import time
import math
from geometry_msgs.msg import TwistStamped

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

from factory_interfaces.action import TransportJob
from factory_interfaces.srv import ApplyMap, WorldControl
from factory_logistics.core import TransportCore
from factory_logistics.realtime_world import RealtimeWorld
from factory_logistics.map_store import load_map, validate_map, save_map


class SimulatedRobot(Node):
    PERIOD = 0.1

    def __init__(self):
        super().__init__('simulated_robot')
        speed = self.declare_parameter('speed', 1.0).value
        self._core = TransportCore(speed=speed, navigation=load_map())
        initial_pose=json.loads(self.declare_parameter('initial_pose','[]').value)
        if initial_pose:
            if not isinstance(initial_pose,list) or len(initial_pose)!=2 or any(type(v) not in (int,float) for v in initial_pose) or not self._core.navigation.point_free(initial_pose):
                raise ValueError('초기 시뮬레이션 위치가 이동 가능 영역 밖입니다.')
            self._core._x,self._core._y=initial_pose
            self._core.begin_external_motion()
        self._world = RealtimeWorld(self._core,camera_only=True)
        self._world_log_seq = 0
        self._was_blocked = False
        self._condition = threading.Condition()
        # Reservation spans goal admission through the action's terminal transition.
        self._reserved = False
        self._handle = None
        self._stopping = False
        self._manual_until = 0.
        self._velocity = (0., 0.)
        self._last_motion_log = 0.
        self._teleop = self.create_subscription(TwistStamped, '/factory/cmd_vel', self._manual, 1)
        self._state_pub = self.create_publisher(String, '/factory/robot_state', 10)
        self._server = ActionServer(
            self, TransportJob, '/factory/transport',
            execute_callback=self._execute,
            goal_callback=self._goal,
            cancel_callback=self._cancel,
            callback_group=ReentrantCallbackGroup())
        self._timer = self.create_timer(self.PERIOD, self._tick)
        self._map_service = self.create_service(ApplyMap, '/factory/apply_map', self._apply_map)
        self._world_service = self.create_service(WorldControl, '/factory/world_control', self._world_control)
        self.get_logger().info('Ready: /factory/transport (simulation only)')

    def _world_control(self, request, response):
        with self._condition:
            try:
                payload=json.loads(request.command_json)
                extra={}
                op=payload.get('operation')
                if op=='start':
                    if self._reserved or time.monotonic()<self._manual_until:raise ValueError('운반·수동 이동을 먼저 정지해 주세요.')
                    self._world.start(payload.get('destination'),payload.get('mode','global'),payload.get('speed',.5))
                elif op=='stop':
                    if self._world.rt['active']:self._world.stop()
                elif op=='observe':self._world.observe()
                elif op=='camera_capture':extra['camera_frame']=self._world.camera_capture()
                elif op=='camera_result':self._world.camera_result(payload)
                elif op=='action':self._world.action(payload)
                elif op=='obstacle':self._world.obstacle(payload.get('obstacle',{}))
                else:raise ValueError('지원하지 않는 실시간 명령입니다.')
                response.success=True
                response.message='적용 완료'
            except (ValueError,TypeError,KeyError,AttributeError) as exc:
                response.success=False;response.message=str(exc)
            response.state_json=json.dumps(dict(self._world.snapshot(),**(extra if response.success else {})),ensure_ascii=False)
        return response

    def _apply_map(self, request, response):
        with self._condition:
            try:
                if self._reserved or self._world.rt['active'] or self._world.obstacles or self._stopping or time.monotonic() < self._manual_until:
                    raise ValueError('로봇과 실시간 판단을 정지하고 동적 장애물을 모두 삭제한 뒤 도면을 적용해 주세요.')
                if request.expected_id != self._core.navigation.data['id']:
                    raise ValueError('다른 화면에서 도면이 변경되었습니다. 현재 도면을 다시 불러오세요.')
                pose = self._core.snapshot()
                navigation = validate_map(json.loads(request.map_json), (pose['x'], pose['y']))
                save_map(navigation)
                self._world.replace_map(navigation)
                response.success = True
                response.message = '도면 저장 및 ROS 적용 완료'
                self.get_logger().info('[도면 적용] {} · 장애물 {}개'.format(navigation.data['id'], len(navigation.walls)))
            except (ValueError, TypeError, OSError) as exc:
                response.success = False
                response.message = str(exc)
            response.map_id = self._core.navigation.data['id']
        return response

    def _goal(self, request):
        with self._condition:
            if self._stopping or self._reserved or self._world.rt['active'] or time.monotonic() < self._manual_until:
                self.get_logger().warning('Rejected: robot busy or stopping')
                return GoalResponse.REJECT
            try:
                self._core.start(request.job_id, request.destination)
            except ValueError as exc:
                self.get_logger().warning('Rejected: {}'.format(exc))
                return GoalResponse.REJECT
            self._reserved = True
            self.get_logger().info('Accepted {} -> {}'.format(request.job_id, request.destination))
            self.get_logger().info('[경로 계획] {}'.format(self._core.navigation_state()['path']))
            return GoalResponse.ACCEPT

    def _manual(self, message):
        with self._condition:
            age = (self.get_clock().now().nanoseconds - (message.header.stamp.sec * 1000000000 + message.header.stamp.nanosec)) / 1e9
            vx, vy = message.twist.linear.x, message.twist.linear.y
            if self._reserved or self._world.rt['active'] or self._stopping or not 0 <= age < .35:
                return
            if not math.isfinite(vx) or not math.isfinite(vy) or math.hypot(vx, vy) > .501:
                return
            active = bool(vx or vy)
            if active and (time.monotonic() >= self._manual_until or (vx, vy) != self._velocity):
                direction = ('오른쪽' if vx > 0 else '왼쪽' if vx < 0 else '') + (' 위' if vy > 0 else ' 아래' if vy < 0 else '')
                self.get_logger().info('Manual control started/changed [수동 방향: {}] vx={:.2f}, vy={:.2f} m/s'.format(direction.strip(), vx, vy))
            self._velocity = (vx, vy)
            self._manual_until = time.monotonic() + .35 if active else 0.

    def _cancel(self, handle):
        with self._condition:
            state = self._core.snapshot()
            if (not self._reserved or state['job_id'] != handle.request.job_id
                    or not self._core.busy):
                return CancelResponse.REJECT
            # Stop simulated movement at admission. execute waits for rclpy's
            # CANCELING transition before marking the action CANCELED.
            self._core.cancel()
            self._condition.notify_all()
            return CancelResponse.ACCEPT

    def _tick(self):
        with self._condition:
            self._world.tick(self.PERIOD)
            if not self._reserved and not self._world.rt['active']:
                velocity = self._velocity if time.monotonic() < self._manual_until else (0., 0.)
                was_manual = self._core.snapshot()['state'] == 'MANUAL'
                self._core.manual_step(*velocity, self.PERIOD)
                if was_manual and not any(velocity):
                    pose = self._core.snapshot()
                    self.get_logger().info('Manual control stopped [수동 정지] x={:.2f}, y={:.2f} (release or watchdog)'.format(pose['x'], pose['y']))
            if self._handle is not None and not self._stopping:
                try:
                    self._core.step(self.PERIOD)
                except Exception as exc:
                    self._core.fail('simulation error: {}'.format(exc))
            state = self._core.snapshot()
            state.update(self._core.navigation_state())
            state['navigation'] = self._core.navigation.data
            state.update(self._world.snapshot())
            if self._world.rt['active']:
                state['state'] = 'REACTIVE'
                state['destination'] = self._world.rt['destination']
                route=self._world.rt.get('route',[])
                state['remaining_distance']=self._world.base.length([self._world.pose()]+route) if route else None
            for entry in reversed(self._world.events):
                number = int(entry['id'].split('-')[1])
                if number > self._world_log_seq:
                    message='[실시간] {}: {}'.format(entry['stage'], entry['message'])
                    if entry.get('level')=='ERROR':self.get_logger().error(message)
                    elif entry.get('level')=='WARN':self.get_logger().warning(message)
                    else:self.get_logger().info(message)
                    self._world_log_seq = number
            if state['collision_blocked'] and not self._was_blocked:
                self.get_logger().warning('[벽 충돌 차단] x={:.2f}, y={:.2f}'.format(state['x'],state['y']))
            self._was_blocked = state['collision_blocked']
            if state['state'] in ('RUNNING', 'MANUAL', 'REACTIVE') and time.monotonic() - self._last_motion_log >= 1.:
                self._last_motion_log = time.monotonic()
                moving=state['state']!='REACTIVE' or self._world.rt.get('actual_speed_mps',0)>0
                remaining=state['remaining_distance']
                self.get_logger().info('[{}] mode={} job={} x={:.2f}, y={:.2f}, remaining={}'.format(
                    '이동 중' if moving else '정지 대기', ('CAMERA_WAIT' if self._world.rt.get('camera_wait') else self._world.rt.get('phase')) if state['state']=='REACTIVE' else state['state'],
                    state['job_id'] or '-', state['x'], state['y'], '경로 미확정' if remaining is None else '{:.2f}m'.format(remaining)))
            state['goal_uuid'] = bytes(self._handle.goal_id.uuid).hex() if self._handle else ''
            self._condition.notify_all()
        self._state_pub.publish(String(data=json.dumps(state, ensure_ascii=False)))

    def _feedback(self, state):
        msg = TransportJob.Feedback()
        msg.state = state['state']
        msg.pose.header.frame_id = 'map'
        msg.pose.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x = float(state['x'])
        msg.pose.pose.position.y = float(state['y'])
        msg.pose.pose.orientation.w = 1.0
        msg.remaining_distance = float(state['remaining_distance'])
        return msg

    def _execute(self, handle):
        result = TransportJob.Result()
        with self._condition:
            self._handle = handle
        try:
            while rclpy.ok():
                with self._condition:
                    if self._stopping:
                        break
                    state = self._core.snapshot()
                    if state['state'] == 'CANCELED':
                        if handle.is_cancel_requested:
                            self.get_logger().info('{} canceled'.format(handle.request.job_id))
                            handle.canceled()
                            result.message = state['message']
                            return result
                        # cancel_callback may have returned just before rclpy
                        # applies its state transition; do not race that transition.
                        self._condition.wait(timeout=0.01)
                        continue
                    if state['state'] == 'SUCCEEDED':
                        self.get_logger().info('{} arrived at {}'.format(handle.request.job_id, handle.request.destination))
                        handle.succeed()
                        result.success = True
                        result.message = state['message']
                        return result
                    if state['state'] == 'FAILED':
                        handle.abort()
                        result.message = state['message']
                        return result
                handle.publish_feedback(self._feedback(state))
                with self._condition:
                    self._condition.wait(timeout=self.PERIOD)
            with self._condition:
                self._core.fail('server shutting down')
            if handle.is_active:
                handle.abort()
            result.message = 'server shutting down'
            return result
        except Exception as exc:
            with self._condition:
                self._core.fail(str(exc))
            if handle.is_active:
                handle.abort()
            self.get_logger().error('Action failed: {}'.format(exc))
            result.message = str(exc)
            return result
        finally:
            with self._condition:
                self._handle = None
                self._reserved = False
                self._condition.notify_all()

    def stop(self):
        with self._condition:
            self._stopping = True
            self._condition.notify_all()

    def destroy_node(self):
        self._server.destroy()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    executor = MultiThreadedExecutor(num_threads=4)
    try:
        node = SimulatedRobot()
        executor.add_node(node)
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.stop()
        executor.shutdown(timeout_sec=3.0)
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
