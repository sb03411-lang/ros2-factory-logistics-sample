"""Factory transport simulation and its ROS 2 adapters."""
